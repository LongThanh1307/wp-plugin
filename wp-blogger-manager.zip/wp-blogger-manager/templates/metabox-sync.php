<?php
/**
 * Post Editor Sync Metabox Template (Multi-Blogger Broadcast Support)
 */

if (!defined('ABSPATH')) {
    exit;
}

$total_blogs_count = is_array($blogs) ? count($blogs) : 0;
?>

<div class="wp-blogger-metabox-content">

    <!-- Status Overview for Synced Blogs -->
    <?php if (!empty($synced_blogs)) : ?>
        <div class="wp-blogger-meta-status" style="margin-bottom: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px;">
            <div style="font-weight: 600; font-size: 12px; margin-bottom: 6px; color: #1e293b;">
                <span class="dashicons dashicons-cloud" style="font-size: 15px; width: 15px; height: 15px; color: #ff5722;"></span> <?php esc_html_e('Trạng thái trên Blogger:', 'wp-blogger-manager'); ?>
            </div>
            <div style="display: flex; flex-direction: column; gap: 6px;">
                <?php foreach ($synced_blogs as $b_id => $sb) : ?>
                    <?php
                    $b_name = isset($blogs[$b_id]['name']) ? $blogs[$b_id]['name'] : $b_id;
                    $is_ok  = (isset($sb['status']) && $sb['status'] === 'synced');
                    ?>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11px; padding: 3px 0; border-bottom: 1px dashed #e2e8f0;">
                        <span style="font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 140px;" title="<?php echo esc_attr($b_name); ?>">
                            <?php echo $is_ok ? '✅' : '❌'; ?> <?php echo esc_html($b_name); ?>
                        </span>
                        <div>
                            <?php if ($is_ok && !empty($sb['url'])) : ?>
                                <a href="<?php echo esc_url($sb['url']); ?>" target="_blank" style="color: #2563eb; text-decoration: none;" title="<?php esc_attr_e('Xem trên Blogger', 'wp-blogger-manager'); ?>">
                                    <span class="dashicons dashicons-external" style="font-size: 13px; width: 13px; height: 13px;"></span> <?php esc_html_e('Xem', 'wp-blogger-manager'); ?>
                                </a>
                            <?php elseif (!$is_ok && !empty($sb['error'])) : ?>
                                <span style="color: #ef4444;" title="<?php echo esc_attr($sb['error']); ?>"><?php esc_html_e('Lỗi', 'wp-blogger-manager'); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Target Selection Mode -->
    <div class="wp-blogger-meta-row" style="margin-bottom: 14px;">
        <label style="font-weight: 600; font-size: 13px; margin-bottom: 8px; display: block; color: #0f172a;">
            <?php esc_html_e('Chọn chế độ đăng bài Blogger:', 'wp-blogger-manager'); ?>
        </label>

        <!-- Option 1: Broadcast to ALL Blogs -->
        <div style="margin-bottom: 8px;">
            <label style="font-weight: normal; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                <input type="radio" name="wp_blogger_sync_mode" value="all" <?php checked($sync_mode, 'all'); ?> class="wp-blogger-sync-mode-radio">
                <span><strong><?php esc_html_e('Đăng qua TẤT CẢ Blogger', 'wp-blogger-manager'); ?></strong> <small style="color: #10b981; font-weight: 600;">(<?php echo intval($total_blogs_count); ?> blog)</small></span>
            </label>
        </div>

        <!-- Option 2: Select Specific Blogs -->
        <div style="margin-bottom: 8px;">
            <label style="font-weight: normal; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                <input type="radio" name="wp_blogger_sync_mode" value="selected" <?php checked($sync_mode, 'selected'); ?> class="wp-blogger-sync-mode-radio">
                <span>
                    <strong><?php esc_html_e('Chỉ đăng qua các Blogger đã chọn', 'wp-blogger-manager'); ?></strong>
                    <?php if (!empty($selected_blogs)) : ?>
                        <small style="color: #2563eb; font-weight: 600;">(Đã nhớ <?php echo count($selected_blogs); ?> blog)</small>
                    <?php endif; ?>
                </span>
            </label>
        </div>

        <!-- Option 3: Do not sync this post -->
        <div>
            <label style="font-weight: normal; cursor: pointer; display: flex; align-items: center; gap: 6px; color: #64748b;">
                <input type="radio" name="wp_blogger_sync_mode" value="none" <?php checked($sync_mode, 'none'); ?> class="wp-blogger-sync-mode-radio">
                <span><?php esc_html_e('Không đồng bộ bài viết này (Mặc định khi tạo mới)', 'wp-blogger-manager'); ?></span>
            </label>
        </div>
    </div>

    <!-- Specific Blogs Checkbox List (Shown when 'selected' is checked) -->
    <div id="wp-blogger-specific-blogs-wrap" style="margin-bottom: 14px; <?php echo ($sync_mode === 'selected') ? '' : 'display: none;'; ?> padding: 10px; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; max-height: 180px; overflow-y: auto;">
        <label style="font-weight: 600; font-size: 11px; text-transform: uppercase; color: #64748b; margin-bottom: 6px; display: block;">
            <?php esc_html_e('Tích chọn Blogger muốn đăng:', 'wp-blogger-manager'); ?>
        </label>

        <?php if (!empty($blogs)) : ?>
            <?php foreach ($blogs as $b_id => $b) : ?>
                <div style="margin-bottom: 6px;">
                    <label style="font-weight: normal; font-size: 12px; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                        <input type="checkbox" name="wp_blogger_selected_blogs[]" value="<?php echo esc_attr($b_id); ?>" <?php checked(in_array((string)$b_id, array_map('strval', (array)$selected_blogs), true)); ?>>
                        <span title="<?php echo esc_attr($b['name']); ?> — <?php echo esc_attr(isset($b['url']) ? $b['url'] : ''); ?>">
                            <?php echo esc_html($b['name']); ?>
                            <?php if (!empty($b['url'])) : ?>
                                <small style="color: #94a3b8; display: block; font-size: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 160px;"><?php echo esc_html(preg_replace('#^https?://(www\.)?#i', '', rtrim($b['url'], '/'))); ?></small>
                            <?php elseif (!empty($b['account_email'])) : ?>
                                <small style="color: #94a3b8;">(<?php echo esc_html($b['account_email']); ?>)</small>
                            <?php endif; ?>
                        </span>
                    </label>
                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <p style="color: #ef4444; font-size: 12px; margin: 0;">
                <?php esc_html_e('Chưa có Blog nào. Vui lòng kết nối tài khoản Google.', 'wp-blogger-manager'); ?>
            </p>
        <?php endif; ?>
    </div>

    <!-- Labels Info: use WP Tags as Blogger Labels -->
    <div class="wp-blogger-meta-row" style="margin-bottom: 12px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 8px 10px;">
        <div style="font-size: 11px; color: #166534; display: flex; align-items: flex-start; gap: 6px;">
            <span class="dashicons dashicons-tag" style="font-size: 14px; width: 14px; height: 14px; flex-shrink: 0; margin-top: 1px;"></span>
            <span>
                <strong><?php esc_html_e('Nhãn Blogger (Labels):', 'wp-blogger-manager'); ?></strong>
                <?php esc_html_e('Dùng phần "Thẻ (Tags)" ở sidebar để gắn nhãn — các Tags sẽ được tự động đồng bộ thành Labels trên Blogger. Categories không được đưa vào.', 'wp-blogger-manager'); ?>
            </span>
        </div>
    </div>

    <!-- 1-Click Sync Button -->
    <?php if ($post->ID > 0 && !empty($blogs)) : ?>
        <div style="margin-top: 14px;">
            <button type="button" id="wp-blogger-metabox-sync-btn" class="button button-primary" data-post-id="<?php echo esc_attr($post->ID); ?>" style="width: 100%; text-align: center; height: 32px; line-height: 30px;">
                <span class="dashicons dashicons-cloud-upload" style="vertical-align: middle; margin-top: -2px;"></span> <?php esc_html_e('Đồng bộ ngay bây giờ', 'wp-blogger-manager'); ?>
            </button>
            <?php if (!empty($synced_blogs)) : ?>
                <button type="button"
                    id="wp-blogger-metabox-delete-btn"
                    class="button"
                    data-post-id="<?php echo esc_attr($post->ID); ?>"
                    style="width: 100%; text-align: center; height: 32px; line-height: 30px; margin-top: 6px; background: #dc2626; color: #fff; border-color: #b91c1c;"
                    title="<?php esc_attr_e('Xóa bài viết này khỏi tất cả Blogger đã đồng bộ (bài trên WP vẫn còn)', 'wp-blogger-manager'); ?>">
                    <span class="dashicons dashicons-trash" style="vertical-align: middle; margin-top: -2px;"></span> <?php esc_html_e('Xóa khỏi Blogger', 'wp-blogger-manager'); ?>
                </button>
            <?php endif; ?>
            <div id="wp-blogger-metabox-status" style="margin-top: 8px;"></div>
        </div>

        <!-- Preview on Blogger -->
        <div style="margin-top: 16px; padding-top: 14px; border-top: 1px dashed #e2e8f0;">
            <label style="font-size: 12px; font-weight: 600; color: #334155; margin-bottom: 6px; display: block;">
                <span class="dashicons dashicons-visibility" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle;"></span>
                <?php esc_html_e('Xem trước trên Blogger:', 'wp-blogger-manager'); ?>
            </label>
            <select id="wp-blogger-preview-blog-select" class="wp-blogger-input" style="width: 100%; font-size: 12px; padding: 4px 8px; margin-bottom: 6px;">
                <option value=""><?php esc_html_e('-- Chọn Blog để preview --', 'wp-blogger-manager'); ?></option>
                <?php foreach ($blogs as $b_id => $b) : ?>
                    <option value="<?php echo esc_attr($b_id); ?>"><?php echo esc_html($b['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="button" id="wp-blogger-metabox-preview-btn" class="button" data-post-id="<?php echo esc_attr($post->ID); ?>" style="width: 100%; height: 30px; line-height: 28px; font-size: 12px;">
                <span class="dashicons dashicons-visibility" style="vertical-align: middle; margin-top: -2px; font-size: 14px;"></span>
                <?php esc_html_e('Tạo bản xem trước (Draft)', 'wp-blogger-manager'); ?>
            </button>
            <div id="wp-blogger-metabox-preview-status" style="margin-top: 6px;"></div>
        </div>

        <!-- Schedule Broadcast -->
        <div style="margin-top: 16px; padding-top: 14px; border-top: 1px dashed #e2e8f0;">
            <label style="font-size: 12px; font-weight: 600; color: #334155; margin-bottom: 6px; display: block;">
                <span class="dashicons dashicons-calendar" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle;"></span>
                <?php esc_html_e('Đặt lịch đồng bộ Blogger:', 'wp-blogger-manager'); ?>
            </label>
            <input type="datetime-local"
                id="wp-blogger-schedule-datetime"
                class="wp-blogger-input"
                style="width: 100%; font-size: 12px; padding: 4px 8px; margin-bottom: 6px;"
                min="<?php echo esc_attr(date('Y-m-d\TH:i', strtotime('+5 minutes'))); ?>">
            <small style="color: #94a3b8; font-size: 10px; display: block; margin-bottom: 6px;"><?php esc_html_e('Đồng bộ theo cấu hình blog đã chọn ở trên.', 'wp-blogger-manager'); ?></small>
            <button type="button" id="wp-blogger-metabox-schedule-btn" class="button" data-post-id="<?php echo esc_attr($post->ID); ?>" style="width: 100%; height: 30px; line-height: 28px; font-size: 12px; background: #7c3aed; color: #fff; border-color: #6d28d9;">
                <span class="dashicons dashicons-clock" style="vertical-align: middle; margin-top: -2px; font-size: 14px;"></span>
                <?php esc_html_e('Thêm vào lịch Queue', 'wp-blogger-manager'); ?>
            </button>
            <div id="wp-blogger-metabox-schedule-status" style="margin-top: 6px;"></div>
        </div>

    <?php endif; ?>

</div>

