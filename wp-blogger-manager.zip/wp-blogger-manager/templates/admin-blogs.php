<?php
/**
 * Multi-Google Accounts & Multi-Blogger Blogs Management Template
 */

if (!defined('ABSPATH')) {
    exit;
}

$accounts_count = is_array($accounts) ? count($accounts) : 0;
$blogs_count    = is_array($blogs) ? count($blogs) : 0;
?>

<div class="wrap wp-blogger-wrap">

    <!-- Header Banner -->
    <div class="wp-blogger-header">
        <div class="wp-blogger-title-group">
            <h1><span class="dashicons dashicons-google"></span> <?php esc_html_e('Quản lý Tài khoản Google & Hệ thống Blogger', 'wp-blogger-manager'); ?></h1>
            <p><?php esc_html_e('Đăng nhập nhiều tài khoản Google, gom toàn bộ Blogspot về một nơi và cấu hình phân phối bài viết.', 'wp-blogger-manager'); ?></p>
        </div>
        <div class="wp-blogger-header-actions">
            <?php if (!empty($auth_url)) : ?>
                <a href="<?php echo esc_url($auth_url); ?>" class="wp-blogger-btn wp-blogger-btn-primary" style="background: #ffffff; color: #ea4335 !important; font-weight: 700;">
                    <span class="dashicons dashicons-plus-alt"></span> <?php esc_html_e('+ Thêm tài khoản Google', 'wp-blogger-manager'); ?>
                </a>
            <?php else : ?>
                <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-settings')); ?>" class="wp-blogger-btn wp-blogger-btn-primary">
                    <span class="dashicons dashicons-admin-settings"></span> <?php esc_html_e('Nhập Client ID/Secret trước', 'wp-blogger-manager'); ?>
                </a>
            <?php endif; ?>

            <?php if ($accounts_count > 0) : ?>
                <button type="button" id="wp-blogger-refresh-blogs-btn" class="wp-blogger-btn wp-blogger-btn-secondary">
                    <span class="dashicons dashicons-update"></span> <?php esc_html_e('Cập nhật lại tất cả Blogs', 'wp-blogger-manager'); ?>
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Alert Notices -->
    <?php if (isset($_GET['auth_success'])) : ?>
        <div class="wp-blogger-alert success">
            <span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Kết nối tài khoản Google thành công và đã tự động nạp danh sách các blog Blogger!', 'wp-blogger-manager'); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['auth_error'])) : ?>
        <div class="wp-blogger-alert error">
            <span class="dashicons dashicons-warning"></span> <?php echo esc_html(sprintf(__('Lỗi xác thực Google: %s', 'wp-blogger-manager'), $_GET['auth_error'])); ?>
        </div>
    <?php endif; ?>

    <!-- 1. Connected Google Accounts Section -->
    <div class="wp-blogger-card">
        <div class="wp-blogger-card-header">
            <h2><span class="dashicons dashicons-admin-users"></span> <?php esc_html_e('Danh sách Tài khoản Google đã đăng nhập', 'wp-blogger-manager'); ?> (<?php echo intval($accounts_count); ?>)</h2>
            <?php if (!empty($auth_url)) : ?>
                <a href="<?php echo esc_url($auth_url); ?>" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm">
                    <span class="dashicons dashicons-plus"></span> <?php esc_html_e('Đăng nhập thêm tài khoản khác', 'wp-blogger-manager'); ?>
                </a>
            <?php endif; ?>
        </div>
        <div class="wp-blogger-card-body">
            <?php if (!empty($accounts)) : ?>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px;">
                    <?php foreach ($accounts as $acc_id => $acc) : ?>
                        <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; display: flex; gap: 14px; align-items: center; background: #f8fafc;">
                            <div style="flex-shrink: 0;">
                                <?php if (!empty($acc['user_avatar'])) : ?>
                                    <img src="<?php echo esc_url($acc['user_avatar']); ?>" alt="" style="width: 48px; height: 48px; border-radius: 50%; border: 2px solid #ff5722;">
                                <?php else : ?>
                                    <div style="width: 48px; height: 48px; border-radius: 50%; background: #ff5722; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: bold;">
                                        <?php echo esc_html(strtoupper(substr($acc['user_email'], 0, 1))); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div style="flex: 1; min-width: 0;">
                                <strong style="display: block; font-size: 14px; color: #0f172a; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <?php echo esc_html($acc['user_name']); ?>
                                </strong>
                                <span style="font-size: 12px; color: #64748b; display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <?php echo esc_html($acc['user_email']); ?>
                                </span>
                                <small style="font-size: 11px; color: #10b981; font-weight: 500;">
                                    <span class="dashicons dashicons-yes" style="font-size: 13px; width: 13px; height: 13px;"></span> <?php esc_html_e('Đang hoạt động', 'wp-blogger-manager'); ?>
                                </small>
                            </div>
                            <div>
                                <button type="button" class="wp-blogger-btn wp-blogger-btn-danger wp-blogger-btn-sm wp-blogger-disconnect-acc-btn" data-account-id="<?php echo esc_attr($acc['account_id']); ?>" title="<?php esc_attr_e('Ngắt kết nối tài khoản này', 'wp-blogger-manager'); ?>">
                                    <span class="dashicons dashicons-dismiss"></span>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <div style="text-align: center; padding: 24px; color: #64748b;">
                    <p style="margin: 0 0 12px 0;"><?php esc_html_e('Bạn chưa kết nối tài khoản Google nào. Hãy bấm nút bên dưới để bắt đầu đăng nhập.', 'wp-blogger-manager'); ?></p>
                    <?php if (!empty($auth_url)) : ?>
                        <a href="<?php echo esc_url($auth_url); ?>" class="wp-blogger-btn wp-blogger-btn-primary">
                            <span class="dashicons dashicons-google" style="color: #ea4335;"></span> <?php esc_html_e('Đăng nhập tài khoản Google đầu tiên', 'wp-blogger-manager'); ?>
                        </a>
                    <?php else : ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-settings')); ?>" class="wp-blogger-btn wp-blogger-btn-primary">
                            <?php esc_html_e('Cấu hình Client ID & Secret trước', 'wp-blogger-manager'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- 2. Blogger Blogs Pool Section -->
    <?php if (!empty($accounts)) : ?>
        <div class="wp-blogger-card">
            <div class="wp-blogger-card-header">
                <h2><span class="dashicons dashicons-admin-site-alt3"></span> <?php esc_html_e('Toàn bộ Blogger Blogs được tổng hợp từ các tài khoản Google', 'wp-blogger-manager'); ?> (<?php echo intval($blogs_count); ?>)</h2>
                <div style="font-size: 13px; color: #64748b;">
                    <?php esc_html_e('Tất cả blog này sẵn sàng nhận bài viết khi chọn "Đăng qua TẤT CẢ Blogger".', 'wp-blogger-manager'); ?>
                </div>
            </div>
            <div class="wp-blogger-card-body" style="padding: 0;">
                <?php if (!empty($blogs)) : ?>
                    <table class="wp-blogger-table">
                        <thead>
                            <tr>
                                <th style="width: 50px; text-align: center;"><?php esc_html_e('Bật/Tắt', 'wp-blogger-manager'); ?></th>
                                <th><?php esc_html_e('Tên Blogspot', 'wp-blogger-manager'); ?></th>
                                <th><?php esc_html_e('Tài khoản Google chủ quản', 'wp-blogger-manager'); ?></th>
                                <th><?php esc_html_e('Blog ID', 'wp-blogger-manager'); ?></th>
                                <th><?php esc_html_e('Số bài', 'wp-blogger-manager'); ?></th>
                                <th><?php esc_html_e('Thao tác', 'wp-blogger-manager'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($blogs as $b_id => $b) : ?>
                                <?php $is_act = (!isset($b['is_active']) || !empty($b['is_active'])); ?>
                                <tr>
                                    <td style="text-align: center;">
                                        <input type="checkbox" class="wp-blogger-toggle-active-btn" data-blog-id="<?php echo esc_attr($b_id); ?>" <?php checked($is_act); ?> title="<?php esc_attr_e('Bật hoặc Tắt blog này khỏi nhóm đăng bài tất cả', 'wp-blogger-manager'); ?>">
                                    </td>
                                    <td>
                                        <strong style="font-size: 14px;"><?php echo esc_html($b['name']); ?></strong>
                                        <?php if (!empty($b['url'])) : ?>
                                            <div style="font-size: 12px; margin-top: 2px;">
                                                <a href="<?php echo esc_url($b['url']); ?>" target="_blank" style="color: #2563eb; text-decoration: none;">
                                                    <?php echo esc_html($b['url']); ?> <span class="dashicons dashicons-external" style="font-size: 12px; width: 12px; height: 12px;"></span>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="wp-blogger-badge muted">
                                            <span class="dashicons dashicons-email"></span> <?php echo esc_html(!empty($b['account_email']) ? $b['account_email'] : 'N/A'); ?>
                                        </span>
                                    </td>
                                    <?php $synced_count = WP_Blogger_Sync::get_synced_post_count_for_blog($b_id); ?>
                                    <td>
                                        <div><strong><?php echo intval($b['posts_count']); ?></strong> <small style="color:#64748b;"><?php esc_html_e('trên Blogger', 'wp-blogger-manager'); ?></small></div>
                                        <div style="font-size: 12px; color: #10b981; margin-top: 3px;">
                                            <span class="dashicons dashicons-yes-alt" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle;"></span>
                                            <strong><?php echo intval($synced_count); ?></strong> <?php esc_html_e('bài từ WP', 'wp-blogger-manager'); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                                            <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-sync-hub&blogger_blog=' . urlencode($b_id))); ?>" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm" title="<?php esc_attr_e('Xem và lọc danh sách bài viết đã đồng bộ lên blog này', 'wp-blogger-manager'); ?>">
                                                <span class="dashicons dashicons-filter"></span> <?php esc_html_e('Lọc bài viết', 'wp-blogger-manager'); ?>
                                            </a>
                                            <a href="<?php echo esc_url(admin_url('post-new.php?post_type=blogger_post')); ?>" class="wp-blogger-btn wp-blogger-btn-primary wp-blogger-btn-sm">
                                                <span class="dashicons dashicons-edit"></span> <?php esc_html_e('Đăng bài mới', 'wp-blogger-manager'); ?>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <div style="text-align: center; padding: 30px; color: #64748b;">
                        <p><?php esc_html_e('Chưa tìm thấy blog nào trong các tài khoản Google trên. Hãy nhấn nút "Cập nhật lại tất cả Blogs".', 'wp-blogger-manager'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

</div>
