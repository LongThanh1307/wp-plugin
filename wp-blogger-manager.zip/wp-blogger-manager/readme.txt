=== WP Blogger Manager & Sync Hub ===
Contributors: antigravity
Tags: blogger, blogspot, sync, cdn, google api, auto publish, multi blog, queue, schedule
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin WordPress chuyên dụng giúp quản trị hệ thống bài viết Blogger (Blogspot), đồng bộ tự động 2 chiều, xử lý hình ảnh CDN, hàng đợi nền WP Cron với Auto-Retry và đặt lịch đăng bài.

== Description ==

**WP Blogger Manager & Sync Hub** là giải pháp toàn diện cho những ai muốn quản lý mạng lưới website Blogger (Blogspot) thông qua một bảng điều khiển WordPress tập trung duy nhất.

### Tính năng nổi bật:
* **Đa tài khoản Google (Multi-Account)**: Kết nối không giới hạn tài khoản Google, tự động gom tất cả Blogspot về một bảng quản trị tập trung.
* **Cơ chế Phân phối Đa Kênh (Broadcast)**: Đăng bài đồng loạt lên TẤT CẢ Blogger hoặc chỉ những Blogger được tích chọn.
* **Hàng đợi Đồng bộ Nền (Background Queue)**: Đồng bộ ngầm qua WP Cron với tốc độ 5 bài/phút, không bao giờ lo quá tải hay timeout PHP.
* **Tự động Thử lại Thông minh (Auto-Retry)**: Tự động retry 1-5 lần với khoảng chờ cấp số nhân (5m -> 15m -> 60m) khi gặp lỗi API.
* **Đặt lịch đăng bài Blogger (Schedule Broadcast)**: Đặt ngày giờ đăng bài lên Blogger hoàn toàn độc lập với ngày xuất bản của bài WordPress.
* **Xem trước bản nháp (Draft Preview)**: Tạo bài dạng nháp trên Blogger và lấy link preview trước khi xuất bản chính thức.
* **Xóa bài đồng bộ an toàn (Smart Delete)**: Xóa từng bài hoặc xóa hàng loạt trên Blogger mà vẫn bảo toàn bài viết trên WordPress.
* **Xử lý Hình ảnh & CDN**: Tự động rewrite đường dẫn ảnh sang CDN (Cloudflare R2, BunnyCDN, S3...) và tự động kéo ảnh ngoại vi (Auto-Sideload).
* **Kéo bài viết từ Blogger về WordPress (Import/Pull)**: Kéo bài viết cũ từ bất kỳ Blogspot nào về WordPress.
* **Tương thích toàn diện**: Hỗ trợ cả Block Editor (Gutenberg) và Classic Editor.

== Installation ==

1. Tải thư mục `wp-blogger-manager` lên thư mục `/wp-content/plugins/` (hoặc cài file zip qua **Plugins > Add New**).
2. Kích hoạt plugin thông qua menu **Plugins** trong WordPress.
3. Đi tới **Blogger Manager > Cài đặt & CDN** để cấu hình Google Client ID & Client Secret và bật Queue Mode.
4. Đi tới **Blogger Manager > Tài khoản & Blogs** và nhấn **+ Thêm tài khoản Google** để kết nối.

== Frequently Asked Questions ==

= Làm thế nào để lấy Google Client ID và Client Secret? =
1. Truy cập https://console.cloud.google.com/ và tạo một Project.
2. Bật API: Tìm kiếm "Blogger API v3" và kích hoạt.
3. Cấu hình OAuth Consent Screen (chọn External).
4. Tạo Credentials: Chọn OAuth 2.0 Client ID > Web application, dán Redirect URI được cấp trong trang Cài đặt của plugin vào ô "Authorized redirect URIs".
5. Lấy Client ID và Secret dán vào cài đặt plugin.

= Queue Mode hoạt động như thế nào? =
Khi bật Queue Mode trong Cài đặt, các thao tác đồng bộ bài viết (kể cả bulk sync hàng loạt) sẽ được đưa vào hàng đợi cơ sở dữ liệu. WP Cron sẽ xử lý từng đợt 5 bài/phút trong nền. Nếu gặp sự cố, hệ thống sẽ tự động thử lại theo cơ chế Exponential Backoff.

