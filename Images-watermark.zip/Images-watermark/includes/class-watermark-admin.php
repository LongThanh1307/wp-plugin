<?php
/**
 * IW_Admin – Trang quản trị plugin Images Watermark.
 *
 * @package Images_Watermark
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IW_Admin {

    /** @var IW_Settings */
    private IW_Settings $settings;

    /** Slug trang Settings */
    const PAGE_SLUG = 'images-watermark';

    // ------------------------------------------------------------------ //

    public function __construct( IW_Settings $settings ) {
        $this->settings = $settings;
        $this->register_hooks();
    }

    private function register_hooks(): void {
        add_action( 'admin_menu',            [ $this, 'add_admin_menu'    ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets'    ] );
        add_action( 'admin_post_iw_save_settings', [ $this, 'handle_save' ] );

        // AJAX – áp dụng watermark thủ công
        add_action( 'wp_ajax_iw_apply_single',   [ $this, 'ajax_apply_single'   ] );
        add_action( 'wp_ajax_iw_restore_single', [ $this, 'ajax_restore_single' ] );
        add_action( 'wp_ajax_iw_apply_post',     [ $this, 'ajax_apply_post'     ] );
        add_action( 'wp_ajax_iw_preview',        [ $this, 'ajax_preview'        ] );

        // Thêm cột vào Media Library
        add_filter( 'manage_media_columns',         [ $this, 'add_media_column'        ] );
        add_action( 'manage_media_custom_column',   [ $this, 'render_media_column'     ], 10, 2 );

        // Meta box cho bài viết
        add_action( 'add_meta_boxes', [ $this, 'add_post_meta_box' ] );
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Menu & Assets
    // ─────────────────────────────────────────────────────────────────── //

    public function add_admin_menu(): void {
        add_options_page(
            __( 'Images Watermark', 'images-watermark' ),
            __( 'Images Watermark', 'images-watermark' ),
            'manage_options',
            self::PAGE_SLUG,
            [ $this, 'render_settings_page' ]
        );
    }

    public function enqueue_assets( string $hook ): void {
        // Chỉ load trên trang settings của plugin
        $is_settings = ( 'settings_page_' . self::PAGE_SLUG === $hook );
        $is_post     = in_array( $hook, [ 'post.php', 'post-new.php' ], true );
        $is_media    = ( 'upload.php' === $hook );

        if ( ! $is_settings && ! $is_post && ! $is_media ) {
            return;
        }

        // WordPress media uploader (cho chọn logo)
        if ( $is_settings ) {
            wp_enqueue_media();
        }

        // WordPress color picker
        wp_enqueue_style(  'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );

        // Plugin styles
        wp_enqueue_style(
            'iw-admin-style',
            IW_PLUGIN_URL . 'admin/css/admin-style.css',
            [],
            IW_VERSION
        );

        // Plugin scripts
        wp_enqueue_script(
            'iw-admin-script',
            IW_PLUGIN_URL . 'admin/js/admin-script.js',
            [ 'jquery', 'wp-color-picker' ],
            IW_VERSION,
            true
        );

        wp_localize_script( 'iw-admin-script', 'IW', [
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'iw_nonce' ),
            'strings'   => [
                'applying'   => __( 'Đang áp dụng...', 'images-watermark' ),
                'applied'    => __( 'Đã đóng watermark!', 'images-watermark' ),
                'restoring'  => __( 'Đang khôi phục...', 'images-watermark' ),
                'restored'   => __( 'Đã khôi phục ảnh gốc!', 'images-watermark' ),
                'error'      => __( 'Có lỗi xảy ra!', 'images-watermark' ),
                'selectLogo' => __( 'Chọn Logo Watermark', 'images-watermark' ),
                'useLogo'    => __( 'Sử dụng ảnh này', 'images-watermark' ),
            ],
        ] );
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Settings Page
    // ─────────────────────────────────────────────────────────────────── //

    public function render_settings_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $opts    = $this->settings->all();
        $notice  = '';

        if ( isset( $_GET['iw_saved'] ) ) {
            $notice = '<div class="notice notice-success is-dismissible"><p>' .
                      __( '✅ Cài đặt đã được lưu!', 'images-watermark' ) .
                      '</p></div>';
        }
        if ( isset( $_GET['iw_error'] ) ) {
            $notice = '<div class="notice notice-error is-dismissible"><p>' .
                      __( '❌ Có lỗi khi lưu cài đặt!', 'images-watermark' ) .
                      '</p></div>';
        }

        // Logo preview URL
        $logo_url = '';
        if ( ! empty( $opts['image_id'] ) ) {
            $logo_url = wp_get_attachment_image_url( (int) $opts['image_id'], 'medium' ) ?: '';
        }

        // Font families list
        $fonts = $this->get_available_fonts();

        // Post types
        $post_types = get_post_types( [ 'public' => true ], 'objects' );

        include IW_PLUGIN_DIR . 'admin/views/settings-page.php';
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Handle Save
    // ─────────────────────────────────────────────────────────────────── //

    public function handle_save(): void {
        check_admin_referer( 'iw_save_settings', 'iw_nonce_field' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Không có quyền truy cập!', 'images-watermark' ) );
        }

        $raw = $_POST['iw'] ?? [];
        $saved = $this->settings->save( $raw );

        $redirect = admin_url( 'options-general.php?page=' . self::PAGE_SLUG );
        wp_safe_redirect( $redirect . ( $saved ? '&iw_saved=1' : '&iw_error=1' ) );
        exit;
    }

    // ─────────────────────────────────────────────────────────────────── //
    // AJAX handlers
    // ─────────────────────────────────────────────────────────────────── //

    public function ajax_apply_single(): void {
        $this->verify_ajax_nonce();

        $attachment_id = (int) ( $_POST['attachment_id'] ?? 0 );
        if ( ! $attachment_id ) {
            wp_send_json_error( 'Invalid attachment ID' );
        }

        $processor = images_watermark()->processor;
        $result    = $processor->process_attachment( $attachment_id );

        if ( $result ) {
            wp_send_json_success( [ 'message' => __( 'Watermark đã được áp dụng!', 'images-watermark' ) ] );
        } else {
            wp_send_json_error( __( 'Không thể áp dụng watermark. Kiểm tra lại ảnh hoặc cài đặt.', 'images-watermark' ) );
        }
    }

    public function ajax_restore_single(): void {
        $this->verify_ajax_nonce();

        $attachment_id = (int) ( $_POST['attachment_id'] ?? 0 );
        if ( ! $attachment_id ) {
            wp_send_json_error( 'Invalid attachment ID' );
        }

        $processor = images_watermark()->processor;
        $result    = $processor->restore_original( $attachment_id );

        if ( $result ) {
            wp_send_json_success( [ 'message' => __( 'Ảnh gốc đã được khôi phục!', 'images-watermark' ) ] );
        } else {
            wp_send_json_error( __( 'Không tìm thấy file backup hoặc không thể khôi phục.', 'images-watermark' ) );
        }
    }

    public function ajax_apply_post(): void {
        $this->verify_ajax_nonce();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) {
            wp_send_json_error( 'Invalid post ID' );
        }

        delete_post_meta( $post_id, '_iw_watermarked' ); // force re-process

        $processor = images_watermark()->processor;
        $processor->process_post( $post_id );

        $count = (int) get_post_meta( $post_id, '_iw_watermarked_count', true );
        wp_send_json_success( [
            'message' => sprintf(
                /* translators: %d: số lượng ảnh */
                __( 'Đã áp dụng watermark cho %d ảnh!', 'images-watermark' ),
                $count
            ),
        ] );
    }

    public function ajax_preview(): void {
        $this->verify_ajax_nonce();

        // Tạo ảnh preview demo (200x150 px)
        $w = 400; $h = 300;
        $image = imagecreatetruecolor( $w, $h );

        // Nền gradient giả
        for ( $y = 0; $y < $h; $y++ ) {
            $shade = (int) ( 50 + ( $y / $h ) * 100 );
            $c = imagecolorallocate( $image, $shade, $shade + 20, $shade + 40 );
            imageline( $image, 0, $y, $w, $y, $c );
        }

        // Đọc cài đặt từ POST
        $raw = $_POST['settings'] ?? [];
        $this->settings->save( $raw );

        // Áp dụng watermark
        $processor = new IW_Processor( $this->settings );

        ob_start();
        imagepng( $image );
        $img_data = ob_get_clean();
        imagedestroy( $image );

        // Trả về base64
        wp_send_json_success( [
            'preview' => 'data:image/png;base64,' . base64_encode( $img_data ),
        ] );
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Media Library Column
    // ─────────────────────────────────────────────────────────────────── //

    public function add_media_column( array $columns ): array {
        $columns['iw_watermark'] = __( 'Watermark', 'images-watermark' );
        return $columns;
    }

    public function render_media_column( string $column, int $post_id ): void {
        if ( 'iw_watermark' !== $column ) {
            return;
        }

        $watermarked = get_post_meta( $post_id, '_iw_watermarked', true );
        $mime        = get_post_mime_type( $post_id );

        if ( ! in_array( $mime, IW_Processor::SUPPORTED_MIMES, true ) ) {
            echo '<span class="iw-badge iw-badge--na">N/A</span>';
            return;
        }

        if ( $watermarked ) {
            printf(
                '<span class="iw-badge iw-badge--done" title="%s">✅ %s</span>
                 <br>
                 <button class="button button-small iw-restore-btn" data-id="%d">%s</button>',
                esc_attr( $watermarked ),
                esc_html__( 'Đã WM', 'images-watermark' ),
                (int) $post_id,
                esc_html__( 'Khôi phục', 'images-watermark' )
            );
        } else {
            printf(
                '<span class="iw-badge iw-badge--none">⬜ %s</span>
                 <br>
                 <button class="button button-small iw-apply-btn" data-id="%d">%s</button>',
                esc_html__( 'Chưa WM', 'images-watermark' ),
                (int) $post_id,
                esc_html__( 'Áp dụng', 'images-watermark' )
            );
        }
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Post Meta Box
    // ─────────────────────────────────────────────────────────────────── //

    public function add_post_meta_box(): void {
        $post_types = (array) $this->settings->get( 'post_types', [ 'post', 'page' ] );
        foreach ( $post_types as $type ) {
            add_meta_box(
                'iw_post_watermark',
                __( '🖼️ Watermark Ảnh', 'images-watermark' ),
                [ $this, 'render_post_meta_box' ],
                $type,
                'side',
                'default'
            );
        }
    }

    public function render_post_meta_box( WP_Post $post ): void {
        $watermarked = get_post_meta( $post->ID, '_iw_watermarked', true );
        $count       = (int) get_post_meta( $post->ID, '_iw_watermarked_count', true );
        ?>
        <div class="iw-metabox">
            <?php if ( $watermarked ) : ?>
                <p class="iw-status iw-status--done">
                    ✅ <?php esc_html_e( 'Đã đóng watermark', 'images-watermark' ); ?>
                    <?php if ( $count ) : ?>
                        <br><small><?php printf( esc_html__( '%d ảnh đã xử lý', 'images-watermark' ), $count ); ?></small>
                    <?php endif; ?>
                </p>
            <?php else : ?>
                <p class="iw-status iw-status--none">
                    ⬜ <?php esc_html_e( 'Chưa đóng watermark', 'images-watermark' ); ?>
                </p>
            <?php endif; ?>

            <button type="button" class="button button-primary iw-apply-post-btn" data-post-id="<?php echo esc_attr( $post->ID ); ?>">
                🔄 <?php esc_html_e( 'Áp dụng Watermark ngay', 'images-watermark' ); ?>
            </button>
            <div class="iw-metabox-msg" style="display:none;margin-top:8px;"></div>
        </div>
        <?php
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Helpers
    // ─────────────────────────────────────────────────────────────────── //

    private function verify_ajax_nonce(): void {
        if ( ! check_ajax_referer( 'iw_nonce', 'nonce', false ) || ! current_user_can( 'upload_files' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }
    }

    private function get_available_fonts(): array {
        $font_dir = IW_PLUGIN_DIR . 'assets/fonts/';
        $fonts    = [];

        if ( is_dir( $font_dir ) ) {
            foreach ( glob( $font_dir . '*.ttf' ) ?: [] as $font_file ) {
                $name          = pathinfo( $font_file, PATHINFO_FILENAME );
                $fonts[ $name ] = $name;
            }
        }

        if ( empty( $fonts ) ) {
            $fonts = [ 'OpenSans' => 'Open Sans (mặc định)' ];
        }

        return $fonts;
    }
}
