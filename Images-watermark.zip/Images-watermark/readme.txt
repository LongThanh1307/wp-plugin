=== Images Watermark ===
Contributors:      yourname
Tags:              watermark, image, photo, copyright, post
Requires at least: 5.6
Tested up to:      6.7
Requires PHP:      7.4
Stable tag:        1.0.0
License:           GPLv2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Tự động đóng watermark cho hình ảnh khi đăng bài viết WordPress.

== Description ==

**Images Watermark** là plugin WordPress giúp bạn tự động bảo vệ bản quyền hình ảnh bằng cách đóng watermark khi đăng bài viết.

= Tính năng chính =

* **Watermark văn bản** – Hiển thị tên website, copyright hoặc bất kỳ văn bản nào
* **Watermark logo/hình ảnh** – Upload logo PNG trong suốt để đóng lên ảnh
* **9 vị trí đặt watermark** – Góc trái/phải trên/dưới, giữa hoặc tùy chỉnh
* **Tùy chỉnh opacity** – Điều chỉnh độ trong suốt từ 0–100%
* **Tự động khi publish** – Watermark được đóng tự động khi bài viết được xuất bản
* **Watermark khi upload** – Tùy chọn watermark ngay khi tải ảnh lên
* **Backup ảnh gốc** – Lưu bản sao ảnh gốc trước khi đóng watermark
* **Khôi phục ảnh gốc** – Khôi phục ảnh về trạng thái ban đầu bất kỳ lúc nào
* **Cột Media Library** – Xem và quản lý trạng thái watermark trong thư viện media
* **Meta box bài viết** – Áp dụng watermark thủ công từ trang soạn thảo bài viết
* **Hỗ trợ JPEG, PNG, GIF, WebP**

= Yêu cầu hệ thống =

* PHP 7.4+
* GD Library (hầu hết hosting đã có sẵn)
* WordPress 5.6+

== Installation ==

1. Tải file ZIP của plugin
2. Vào **Plugins > Add New > Upload Plugin** trong WordPress Admin
3. Upload file ZIP và kích hoạt plugin
4. Vào **Settings > Images Watermark** để cấu hình

= Cài đặt thủ công =

1. Giải nén và upload thư mục `images-watermark/` vào `/wp-content/plugins/`
2. Kích hoạt plugin trong **Plugins > Installed Plugins**
3. Vào **Settings > Images Watermark** để cấu hình

== Frequently Asked Questions ==

= Plugin có ảnh hưởng đến hiệu suất website không? =

Plugin chỉ chạy khi bài viết được publish/update, không ảnh hưởng đến tốc độ tải trang.

= Tôi có thể khôi phục ảnh gốc không? =

Có! Nếu bật tùy chọn "Lưu backup ảnh gốc", bạn có thể khôi phục ảnh gốc bất kỳ lúc nào từ Media Library.

= Plugin hỗ trợ những định dạng ảnh nào? =

JPEG, PNG, GIF và WebP (WebP cần PHP hỗ trợ).

= Watermark font chữ nào được hỗ trợ? =

Plugin sử dụng font TTF. Bạn có thể thêm font TTF vào thư mục `assets/fonts/` của plugin.

= Làm sao để thêm font chữ tùy chỉnh? =

Chép file `.ttf` vào thư mục `wp-content/plugins/images-watermark/assets/fonts/` và chọn trong phần Cài đặt.

== Changelog ==

= 1.0.0 =
* Phát hành lần đầu
* Watermark văn bản và logo/hình ảnh
* 9 vị trí đặt watermark
* Tùy chỉnh opacity, font, màu sắc
* Backup và khôi phục ảnh gốc
* Cột trong Media Library
* Meta box trong trang soạn thảo bài viết
* Trang cài đặt với giao diện hiện đại
