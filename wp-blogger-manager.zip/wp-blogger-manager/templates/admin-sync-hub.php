<?php
/**
 * Admin Sync Hub - Import Posts FROM Blogger TO WordPress
 * Pull posts from connected Blogger blogs into a staging area, then import to WP.
 */

if (!defined('ABSPATH')) {
    exit;
}

$current_url = admin_url('admin.php?page=wp-blogger-sync-hub');
?>
<div class="wrap wp-blogger-wrap">

    <div class="wp-blogger-header">
        <div class="wp-blogger-title-group">
            <h1><span class="dashicons dashicons-download" style="color:#3b82f6;"></span> <?php esc_html_e('Lấy bài viết từ Blogger về WP', 'wp-blogger-manager'); ?></h1>
            <p><?php esc_html_e('Chọn trang Blogger, danh mục (nhãn) và số lượng bài cần lấy về. Bài viết sẽ được lưu vào vùng chờ bên dưới. Sau đó chọn bài để đưa vào WP Posts (trạng thái nháp, chưa đồng bộ).', 'wp-blogger-manager'); ?></p>
        </div>
    </div>

    <?php if (empty($blogs)) : ?>
    <div class="wp-blogger-alert" style="border-left:4px solid #f59e0b; background:#fef3c7;">
        <span class="dashicons dashicons-warning" style="color:#f59e0b;"></span>
        <?php esc_html_e('Bạn chưa kết nối tài khoản Google / trang Blogger nào.', 'wp-blogger-manager'); ?>
        <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-blogs')); ?>" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm" style="margin-left:10px;">
            <?php esc_html_e('Kết nối ngay', 'wp-blogger-manager'); ?>
        </a>
    </div>
    <?php else : ?>

    <!-- ====================== PULL FROM BLOGGER PANEL ====================== -->
    <div class="wp-blogger-card" style="margin-bottom:20px; border-top:3px solid #3b82f6;">
        <div class="wp-blogger-card-header">
            <h2><span class="dashicons dashicons-cloud-saved" style="color:#3b82f6;"></span> <?php esc_html_e('1. Lấy bài viết từ Blogger', 'wp-blogger-manager'); ?></h2>
        </div>
        <div class="wp-blogger-card-body">
            <div style="display:grid; grid-template-columns:1fr 1fr 1fr auto; gap:16px; align-items:end; flex-wrap:wrap;">

                <!-- Blog Select -->
                <div>
                    <label class="wp-blogger-label" for="wp-blogger-import-blog" style="display:block; margin-bottom:6px; font-weight:600;">
                        <span class="dashicons dashicons-admin-site-alt3" style="color:#3b82f6;vertical-align:middle;"></span>
                        <?php esc_html_e('Chọn trang Blogger:', 'wp-blogger-manager'); ?>
                    </label>
                    <select id="wp-blogger-import-blog" class="wp-blogger-input" style="width:100%;">
                        <option value=""><?php esc_html_e('-- Chọn blog --', 'wp-blogger-manager'); ?></option>
                        <?php foreach ($blogs as $b_id => $b) :
                            if (isset($b['is_active']) && !$b['is_active']) { continue; }
                            $domain = parse_url($b['url'], PHP_URL_HOST) ?: $b['name'];
                        ?>
                            <option value="<?php echo esc_attr($b_id); ?>" data-url="<?php echo esc_attr($b['url']); ?>">
                                <?php echo esc_html($domain); ?>
                                <?php if (!empty($b['posts_count'])) : ?> (<?php echo intval($b['posts_count']); ?> bài)<?php endif; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Label Select -->
                <div>
                    <label class="wp-blogger-label" for="wp-blogger-import-label" style="display:block; margin-bottom:6px; font-weight:600;">
                        <span class="dashicons dashicons-tag" style="color:#8b5cf6;vertical-align:middle;"></span>
                        <?php esc_html_e('Danh mục (Nhãn):', 'wp-blogger-manager'); ?>
                        <button type="button" id="wp-blogger-load-labels-btn" class="wp-blogger-btn wp-blogger-btn-sm wp-blogger-btn-secondary" style="margin-left:6px; padding:2px 8px; font-size:11px;">
                            <span class="dashicons dashicons-update" style="font-size:12px;width:12px;height:12px;"></span> <?php esc_html_e('Tải nhãn', 'wp-blogger-manager'); ?>
                        </button>
                    </label>
                    <select id="wp-blogger-import-label" class="wp-blogger-input" style="width:100%;">
                        <option value=""><?php esc_html_e('-- Tất cả nhãn --', 'wp-blogger-manager'); ?></option>
                    </select>
                    <div id="wp-blogger-label-loading" style="display:none; font-size:12px; color:#64748b; margin-top:4px;">
                        <span class="dashicons dashicons-update wp-blogger-spin" style="font-size:14px;width:14px;height:14px;"></span>
                        <?php esc_html_e('Đang tải danh sách nhãn...', 'wp-blogger-manager'); ?>
                    </div>
                </div>

                <!-- Count -->
                <div>
                    <label class="wp-blogger-label" for="wp-blogger-import-count" style="display:block; margin-bottom:6px; font-weight:600;">
                        <span class="dashicons dashicons-list-view" style="color:#10b981;vertical-align:middle;"></span>
                        <?php esc_html_e('Số lượng bài:', 'wp-blogger-manager'); ?>
                    </label>
                    <div style="display:flex; align-items:center; gap:8px;">
                        <select id="wp-blogger-import-count" class="wp-blogger-input" style="width:130px;">
                            <option value="5">5 bài</option>
                            <option value="10" selected>10 bài</option>
                            <option value="15">15 bài</option>
                            <option value="20">20 bài</option>
                            <option value="0"><?php esc_html_e('Lấy tất cả (≤500)', 'wp-blogger-manager'); ?></option>
                        </select>
                    </div>
                </div>

                <!-- Fetch Button -->
                <div>
                    <button type="button" id="wp-blogger-fetch-btn" class="wp-blogger-btn wp-blogger-btn-primary" style="white-space:nowrap; height:38px;">
                        <span class="dashicons dashicons-download" style="vertical-align:middle;"></span>
                        <?php esc_html_e('Lấy bài về', 'wp-blogger-manager'); ?>
                    </button>
                </div>
            </div>

            <div id="wp-blogger-fetch-result" style="margin-top:14px;"></div>
        </div>
    </div>

    <!-- ====================== STAGING TABLE ====================== -->
    <div class="wp-blogger-card">
        <div class="wp-blogger-card-header" style="flex-wrap:wrap; gap:12px;">
            <h2>
                <span class="dashicons dashicons-archive" style="color:#8b5cf6;"></span>
                <?php esc_html_e('2. Vùng chờ — Bài viết từ Blogger', 'wp-blogger-manager'); ?>
                <span style="background:#8b5cf6;color:#fff;padding:2px 10px;border-radius:10px;font-size:12px;margin-left:8px;"><?php echo intval($total_items); ?></span>
            </h2>
            <div style="display:flex; gap:10px; align-items:center; margin-left:auto;">
                <button type="button" id="wp-blogger-import-wp-btn" class="wp-blogger-btn wp-blogger-btn-primary" style="background:#10b981; border-color:#10b981;" disabled>
                    <span class="dashicons dashicons-migrate"></span>
                    <?php esc_html_e('Đưa vào WP Posts', 'wp-blogger-manager'); ?>
                    <span id="wp-blogger-selected-count" style="background:rgba(255,255,255,0.25);padding:0 6px;border-radius:8px;margin-left:4px;">0</span>
                </button>
                <button type="button" id="wp-blogger-delete-staging-btn" class="wp-blogger-btn" style="background:#dc2626;color:#fff;border-color:#dc2626;" disabled>
                    <span class="dashicons dashicons-trash"></span>
                    <?php esc_html_e('Xóa khỏi vùng chờ', 'wp-blogger-manager'); ?>
                </button>
            </div>
        </div>

        <!-- Filter bar -->
        <div style="padding:12px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0;">
            <form method="get" style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                <input type="hidden" name="page" value="wp-blogger-sync-hub">

                <!-- Filter by Blog -->
                <select name="filter_blog" class="wp-blogger-input" style="max-width:210px; padding:6px 10px;" onchange="this.form.submit()">
                    <option value=""><?php esc_html_e('Tất cả Blogger', 'wp-blogger-manager'); ?></option>
                    <?php
                    // Get unique blog_ids in staging
                    global $wpdb;
                    $table = $wpdb->prefix . 'blogger_import_staging';
                    $staging_blogs = $wpdb->get_results("SELECT DISTINCT blog_id, blog_name FROM {$table}");
                    if (!empty($staging_blogs)) :
                        foreach ($staging_blogs as $sb) : ?>
                            <option value="<?php echo esc_attr($sb->blog_id); ?>" <?php selected($filter_blog, $sb->blog_id); ?>>
                                <?php echo esc_html($sb->blog_name ?: $sb->blog_id); ?>
                            </option>
                    <?php endforeach; endif; ?>
                </select>

                <!-- Filter by Label -->
                <?php if (!empty($all_labels_for_filter)) : ?>
                <select name="filter_label" class="wp-blogger-input" style="max-width:200px; padding:6px 10px;" onchange="this.form.submit()">
                    <option value=""><?php esc_html_e('Tất cả nhãn', 'wp-blogger-manager'); ?></option>
                    <?php foreach ($all_labels_for_filter as $lbl) : ?>
                        <option value="<?php echo esc_attr($lbl); ?>" <?php selected($filter_label, $lbl); ?>>
                            <?php echo esc_html($lbl); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php endif; ?>

                <!-- Filter by Status -->
                <select name="filter_status" class="wp-blogger-input" style="max-width:160px; padding:6px 10px;" onchange="this.form.submit()">
                    <option value=""><?php esc_html_e('Tất cả trạng thái', 'wp-blogger-manager'); ?></option>
                    <option value="pending" <?php selected($filter_status, 'pending'); ?>><?php esc_html_e('Chờ import', 'wp-blogger-manager'); ?></option>
                    <option value="imported" <?php selected($filter_status, 'imported'); ?>><?php esc_html_e('Đã import WP', 'wp-blogger-manager'); ?></option>
                </select>

                <?php if (!empty($filter_blog) || !empty($filter_label) || !empty($filter_status)) : ?>
                    <a href="<?php echo esc_url($current_url); ?>" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm" style="color:#ef4444;" title="Xóa bộ lọc">
                        <span class="dashicons dashicons-dismiss"></span> <?php esc_html_e('Xóa lọc', 'wp-blogger-manager'); ?>
                    </a>
                <?php endif; ?>
            </form>
        </div>

        <div id="wp-blogger-import-result" style="padding:0 20px;"></div>

        <div class="wp-blogger-card-body" style="padding:0;">
            <?php if (!empty($staging_posts)) : ?>
            <table class="wp-blogger-table">
                <thead>
                    <tr>
                        <th style="width:40px; text-align:center;"><input type="checkbox" id="wp-blogger-staging-select-all" title="<?php esc_attr_e('Chọn tất cả', 'wp-blogger-manager'); ?>"></th>
                        <th><?php esc_html_e('Tiêu đề bài viết Blogger', 'wp-blogger-manager'); ?></th>
                        <th style="width:160px;"><?php esc_html_e('Nguồn Blog', 'wp-blogger-manager'); ?></th>
                        <th style="width:150px;"><?php esc_html_e('Nhãn / Danh mục', 'wp-blogger-manager'); ?></th>
                        <th style="width:120px;"><?php esc_html_e('Ngày đăng', 'wp-blogger-manager'); ?></th>
                        <th style="width:130px;"><?php esc_html_e('Trạng thái', 'wp-blogger-manager'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($staging_posts as $row) :
                        $labels_arr = json_decode($row->labels, true);
                        if (!is_array($labels_arr)) { $labels_arr = array(); }
                        $is_imported = $row->imported_wp_id > 0;
                        $wp_post     = $is_imported ? get_post($row->imported_wp_id) : null;
                        $blog_domain = '';
                        if (!empty($blogs[$row->blog_id]['url'])) {
                            $blog_domain = parse_url($blogs[$row->blog_id]['url'], PHP_URL_HOST) ?: $row->blog_name;
                        } else {
                            $blog_domain = $row->blog_name ?: $row->blog_id;
                        }
                    ?>
                    <tr style="<?php echo $is_imported ? 'opacity:0.65;' : ''; ?>">
                        <td style="text-align:center;">
                            <?php if (!$is_imported) : ?>
                            <input type="checkbox" class="wp-blogger-staging-checkbox" value="<?php echo intval($row->id); ?>">
                            <?php else : ?>
                            <span class="dashicons dashicons-yes-alt" style="color:#10b981;" title="Đã import"></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong style="display:block; line-height:1.3;"><?php echo esc_html($row->title); ?></strong>
                            <div style="display:flex; gap:8px; align-items:center; margin-top:4px; flex-wrap:wrap;">
                                <?php if (!empty($row->url)) : ?>
                                <a href="<?php echo esc_url($row->url); ?>" target="_blank" rel="noopener noreferrer" style="font-size:11px; color:#3b82f6; display:inline-flex; align-items:center; gap:2px;">
                                    <span class="dashicons dashicons-external" style="font-size:12px;width:12px;height:12px;"></span>
                                    <?php esc_html_e('Xem trên Blogger', 'wp-blogger-manager'); ?>
                                </a>
                                <?php endif; ?>
                                <?php if ($wp_post) : ?>
                                <a href="<?php echo esc_url(get_edit_post_link($row->imported_wp_id)); ?>" style="font-size:11px; color:#10b981; display:inline-flex; align-items:center; gap:2px;">
                                    <span class="dashicons dashicons-edit" style="font-size:12px;width:12px;height:12px;"></span>
                                    <?php printf(esc_html__('WP #%d', 'wp-blogger-manager'), $row->imported_wp_id); ?>
                                </a>
                                <?php endif; ?>
                                <?php if (!empty($row->thumbnail)) : ?>
                                <img src="<?php echo esc_url($row->thumbnail); ?>" alt="" style="height:28px; width:44px; object-fit:cover; border-radius:3px; border:1px solid #e2e8f0;" onerror="this.style.display='none'">
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($row->excerpt)) : ?>
                            <div style="font-size:11px; color:#94a3b8; margin-top:3px; line-height:1.4;">
                                <?php echo esc_html(wp_trim_words($row->excerpt, 12)); ?>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span style="font-size:12px; color:#475569;">
                                <?php echo esc_html($blog_domain); ?>
                            </span>
                        </td>
                        <td>
                            <?php if (!empty($labels_arr)) : ?>
                            <div style="display:flex; flex-wrap:wrap; gap:4px;">
                                <?php foreach ($labels_arr as $lbl) : ?>
                                <span style="background:#ede9fe; color:#7c3aed; font-size:10px; padding:1px 7px; border-radius:8px; white-space:nowrap;">
                                    <?php echo esc_html($lbl); ?>
                                </span>
                                <?php endforeach; ?>
                            </div>
                            <?php else : ?>
                            <span style="color:#cbd5e1; font-size:12px;">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span style="font-size:12px; color:#64748b;">
                                <?php echo $row->published_at ? esc_html(date_i18n('d/m/Y', strtotime($row->published_at))) : '—'; ?>
                            </span>
                            <div style="font-size:10px; color:#94a3b8; margin-top:2px;">
                                <?php esc_html_e('Lấy về:', 'wp-blogger-manager'); ?> <?php echo esc_html(date_i18n('d/m H:i', strtotime($row->fetched_at))); ?>
                            </div>
                        </td>
                        <td>
                            <?php if ($is_imported && $wp_post) : ?>
                                <span class="wp-blogger-badge success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Đã import', 'wp-blogger-manager'); ?></span>
                            <?php elseif ($is_imported) : ?>
                                <span class="wp-blogger-badge warning"><span class="dashicons dashicons-warning"></span> <?php esc_html_e('WP bị xóa', 'wp-blogger-manager'); ?></span>
                            <?php else : ?>
                                <span class="wp-blogger-badge muted"><span class="dashicons dashicons-clock"></span> <?php esc_html_e('Chờ import', 'wp-blogger-manager'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php if ($total_pages > 1) :
                $paginate_args = array(
                    'base'      => add_query_arg(array('paged' => '%#%', 'filter_blog' => $filter_blog, 'filter_label' => $filter_label, 'filter_status' => $filter_status), $current_url),
                    'format'    => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total'     => $total_pages,
                    'current'   => $paged,
                    'type'      => 'plain',
                );
            ?>
            <div class="tablenav" style="padding:12px 20px;">
                <div class="tablenav-pages"><?php echo paginate_links($paginate_args); ?></div>
            </div>
            <?php endif; ?>

            <?php else : ?>
            <div style="padding:60px 20px; text-align:center; color:#94a3b8;">
                <span class="dashicons dashicons-cloud-saved" style="font-size:48px; width:48px; height:48px; color:#e2e8f0; display:block; margin:0 auto 16px;"></span>
                <p style="font-size:15px; margin:0 0 8px; color:#64748b;">
                    <?php esc_html_e('Vùng chờ trống. Hãy chọn blog Blogger và nhấn "Lấy bài về" ở trên.', 'wp-blogger-manager'); ?>
                </p>
                <p style="font-size:12px; color:#94a3b8; margin:0;">
                    <?php esc_html_e('Bài viết sau khi lấy về sẽ hiển thị ở đây để bạn xem xét trước khi đưa vào WP.', 'wp-blogger-manager'); ?>
                </p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php endif; // end if !empty($blogs) ?>
</div>

<!-- Modal: Confirm Import to WP -->
<div id="wp-blogger-import-modal" class="wp-blogger-modal-overlay" style="display:none;">
    <div class="wp-blogger-modal" style="max-width:480px;">
        <div class="wp-blogger-modal-header" style="border-bottom:2px solid #10b981;">
            <h3><span class="dashicons dashicons-migrate" style="color:#10b981;"></span> <?php esc_html_e('Xác nhận đưa vào WP Posts', 'wp-blogger-manager'); ?></h3>
            <button type="button" class="wp-blogger-modal-close" onclick="document.getElementById('wp-blogger-import-modal').style.display='none'">&times;</button>
        </div>
        <div class="wp-blogger-modal-body">
            <div class="wp-blogger-alert" style="background:#f0fdf4; border-left:4px solid #10b981; color:#166534; padding:12px 16px; border-radius:6px; margin-bottom:14px;">
                <strong><?php esc_html_e('Lưu ý:', 'wp-blogger-manager'); ?></strong>
                <?php esc_html_e('Bài viết sẽ được tạo trong WP với trạng thái "Nháp", chưa đồng bộ lên bất kỳ Blogger nào. Nhãn Blogger sẽ được gán tự động.', 'wp-blogger-manager'); ?>
            </div>
            <p id="wp-blogger-import-confirm-msg" style="font-size:14px; color:#374151;"></p>
            <div id="wp-blogger-import-modal-result"></div>
        </div>
        <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px; padding-top:14px; border-top:1px solid #e2e8f0;">
            <button type="button" class="wp-blogger-btn wp-blogger-btn-secondary" onclick="document.getElementById('wp-blogger-import-modal').style.display='none'"><?php esc_html_e('Hủy', 'wp-blogger-manager'); ?></button>
            <button type="button" id="wp-blogger-confirm-import-btn" class="wp-blogger-btn" style="background:#10b981;color:#fff;border-color:#10b981;">
                <span class="dashicons dashicons-migrate"></span> <?php esc_html_e('Xác nhận Import', 'wp-blogger-manager'); ?>
            </button>
        </div>
    </div>
</div>

<script>
(function($) {
    'use strict';

    var selectedStagingIds = [];

    // ===== Checkbox management =====
    function updateSelectionState() {
        var count = $('.wp-blogger-staging-checkbox:checked').length;
        selectedStagingIds = [];
        $('.wp-blogger-staging-checkbox:checked').each(function() {
            selectedStagingIds.push($(this).val());
        });
        $('#wp-blogger-selected-count').text(count);
        $('#wp-blogger-import-wp-btn, #wp-blogger-delete-staging-btn').prop('disabled', count === 0);
    }

    $('#wp-blogger-staging-select-all').on('change', function() {
        $('.wp-blogger-staging-checkbox').prop('checked', this.checked);
        updateSelectionState();
    });
    $(document).on('change', '.wp-blogger-staging-checkbox', updateSelectionState);

    // ===== Load Labels =====
    $('#wp-blogger-load-labels-btn').on('click', function() {
        var blogId = $('#wp-blogger-import-blog').val();
        if (!blogId) {
            alert('<?php echo esc_js(__('Vui lòng chọn blog Blogger trước.', 'wp-blogger-manager')); ?>');
            return;
        }
        var $btn = $(this).prop('disabled', true);
        $('#wp-blogger-label-loading').show();
        $('#wp-blogger-import-label').prop('disabled', true);

        $.post(wpBloggerData.ajaxUrl, {
            action:  'wp_blogger_get_labels',
            nonce:   wpBloggerData.nonce,
            blog_id: blogId,
        }, function(res) {
            $('#wp-blogger-import-label').html('<option value=""><?php echo esc_js(__('-- Tất cả nhãn --', 'wp-blogger-manager')); ?></option>');
            if (res.success && res.data.labels.length > 0) {
                $.each(res.data.labels, function(i, label) {
                    $('#wp-blogger-import-label').append('<option value="' + $('<span>').text(label).html() + '">' + $('<span>').text(label).html() + '</option>');
                });
            } else {
                $('#wp-blogger-import-label').append('<option value="" disabled><?php echo esc_js(__('Không có nhãn nào', 'wp-blogger-manager')); ?></option>');
            }
        }).fail(function() {
            $('#wp-blogger-import-label').append('<option value="" disabled><?php echo esc_js(__('Lỗi tải nhãn', 'wp-blogger-manager')); ?></option>');
        }).always(function() {
            $btn.prop('disabled', false);
            $('#wp-blogger-label-loading').hide();
            $('#wp-blogger-import-label').prop('disabled', false);
        });
    });

    // Auto-load labels when blog changes
    $('#wp-blogger-import-blog').on('change', function() {
        var blogId = $(this).val();
        $('#wp-blogger-import-label').html('<option value=""><?php echo esc_js(__('-- Tất cả nhãn --', 'wp-blogger-manager')); ?></option>');
        if (!blogId) return;
        // Auto-trigger label load
        $('#wp-blogger-load-labels-btn').trigger('click');
    });

    // ===== Fetch from Blogger =====
    $('#wp-blogger-fetch-btn').on('click', function() {
        var blogId  = $('#wp-blogger-import-blog').val();
        var label   = $('#wp-blogger-import-label').val();
        var count   = $('#wp-blogger-import-count').val();

        if (!blogId) {
            $('#wp-blogger-fetch-result').html('<div class="wp-blogger-alert error"><?php echo esc_js(__('Vui lòng chọn trang Blogger.', 'wp-blogger-manager')); ?></div>');
            return;
        }

        var fetchAll = (count === '0') ? 1 : 0;
        var $btn     = $(this).prop('disabled', true);
        var labelText = label || '<?php echo esc_js(__('tất cả nhãn', 'wp-blogger-manager')); ?>';

        $('#wp-blogger-fetch-result').html(
            '<div class="wp-blogger-alert" style="background:#eff6ff;border-left:4px solid #3b82f6;">' +
            '<span class="dashicons dashicons-update wp-blogger-spin"></span> ' +
            '<?php echo esc_js(__('Đang lấy bài viết từ Blogger', 'wp-blogger-manager')); ?> [' + labelText + ']...</div>'
        );

        $.post(wpBloggerData.ajaxUrl, {
            action:      'wp_blogger_fetch_from_blogger',
            nonce:       wpBloggerData.nonce,
            blog_id:     blogId,
            label:       label,
            max_results: count,
            fetch_all:   fetchAll,
        }, function(res) {
            if (res.success) {
                $('#wp-blogger-fetch-result').html(
                    '<div class="wp-blogger-alert success">' +
                    '<span class="dashicons dashicons-yes-alt"></span> <strong><?php echo esc_js(__('Thành công!', 'wp-blogger-manager')); ?></strong> ' +
                    res.data.message +
                    ' <a href="" style="margin-left:10px; font-size:12px;" onclick="location.reload(); return false;"><?php echo esc_js(__('Làm mới trang', 'wp-blogger-manager')); ?> &rarr;</a>' +
                    '</div>'
                );
                // Auto reload after 1.5s
                setTimeout(function() { location.reload(); }, 1800);
            } else {
                $('#wp-blogger-fetch-result').html('<div class="wp-blogger-alert error"><span class="dashicons dashicons-warning"></span> ' + res.data.message + '</div>');
            }
        }).fail(function() {
            $('#wp-blogger-fetch-result').html('<div class="wp-blogger-alert error"><?php echo esc_js(__('Lỗi kết nối. Vui lòng thử lại.', 'wp-blogger-manager')); ?></div>');
        }).always(function() {
            $btn.prop('disabled', false);
        });
    });

    // ===== Import to WP =====
    $('#wp-blogger-import-wp-btn').on('click', function() {
        if (selectedStagingIds.length === 0) return;
        $('#wp-blogger-import-confirm-msg').text(
            selectedStagingIds.length + ' <?php echo esc_js(__('bài viết sẽ được tạo trong WP Posts (trạng thái Nháp, chưa đồng bộ).', 'wp-blogger-manager')); ?>'
        );
        $('#wp-blogger-import-modal-result').html('');
        $('#wp-blogger-import-modal').css('display', 'flex');
    });

    $('#wp-blogger-confirm-import-btn').on('click', function() {
        var $btn = $(this).prop('disabled', true);
        $('#wp-blogger-import-modal-result').html(
            '<div style="text-align:center; padding:10px;"><span class="dashicons dashicons-update wp-blogger-spin" style="font-size:24px;width:24px;height:24px;color:#10b981;"></span></div>'
        );

        $.post(wpBloggerData.ajaxUrl, {
            action:      'wp_blogger_import_to_wp',
            nonce:       wpBloggerData.nonce,
            staging_ids: selectedStagingIds,
        }, function(res) {
            if (res.success) {
                $('#wp-blogger-import-modal-result').html(
                    '<div class="wp-blogger-alert success"><span class="dashicons dashicons-yes-alt"></span> ' + res.data.message + '</div>'
                );
                $('#wp-blogger-import-result').html(
                    '<div class="wp-blogger-alert success" style="margin:10px 0;"><span class="dashicons dashicons-yes-alt"></span> ' + res.data.message +
                    ' <a href="' + wpBloggerData.ajaxUrl.replace('admin-ajax.php', 'edit.php') + '" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm" style="margin-left:8px;"><?php echo esc_js(__('Xem WP Posts', 'wp-blogger-manager')); ?> &rarr;</a>' +
                    '</div>'
                );
                setTimeout(function() {
                    $('#wp-blogger-import-modal').hide();
                    location.reload();
                }, 2000);
            } else {
                $('#wp-blogger-import-modal-result').html('<div class="wp-blogger-alert error">' + res.data.message + '</div>');
                $btn.prop('disabled', false);
            }
        }).fail(function() {
            $('#wp-blogger-import-modal-result').html('<div class="wp-blogger-alert error"><?php echo esc_js(__('Lỗi kết nối.', 'wp-blogger-manager')); ?></div>');
            $btn.prop('disabled', false);
        });
    });

    // ===== Delete from staging =====
    $('#wp-blogger-delete-staging-btn').on('click', function() {
        if (selectedStagingIds.length === 0) return;
        if (!confirm(selectedStagingIds.length + ' <?php echo esc_js(__('bài sẽ bị xóa khỏi vùng chờ (không ảnh hưởng đến WP Posts đã import). Tiếp tục?', 'wp-blogger-manager')); ?>')) {
            return;
        }
        var $btn = $(this).prop('disabled', true);

        $.post(wpBloggerData.ajaxUrl, {
            action:      'wp_blogger_delete_staging',
            nonce:       wpBloggerData.nonce,
            staging_ids: selectedStagingIds,
        }, function(res) {
            if (res.success) {
                $('#wp-blogger-import-result').html('<div class="wp-blogger-alert success" style="margin:10px 0;"><span class="dashicons dashicons-yes-alt"></span> ' + res.data.message + '</div>');
                setTimeout(function() { location.reload(); }, 1200);
            } else {
                $('#wp-blogger-import-result').html('<div class="wp-blogger-alert error" style="margin:10px 0;">' + res.data.message + '</div>');
                $btn.prop('disabled', false);
            }
        });
    });

    // Close modal on overlay click
    $('#wp-blogger-import-modal').on('click', function(e) {
        if ($(e.target).is('#wp-blogger-import-modal')) {
            $(this).hide();
        }
    });

})(jQuery);
</script>
