<?php
/**
 * Blogger Admin Enhancements for WP Native Post Type
 * Adds Blogger sync metabox, columns, views, and filters to the native 'post' type.
 * The blogger_post CPT has been removed — all management is done via standard WP posts.
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Blogger_CPT {

    public function __construct() {
        add_action('init', array($this, 'register_taxonomies'));
        add_action('add_meta_boxes', array($this, 'add_sync_metabox'));
        add_action('save_post', array($this, 'save_metabox_data'), 10, 2);
        // Custom columns for native WP posts
        add_filter('manage_post_posts_columns', array($this, 'add_blogger_columns'));
        add_action('manage_post_posts_custom_column', array($this, 'render_blogger_columns'), 10, 2);
        // Status views above the post list table
        add_filter('views_edit-post', array($this, 'add_blogger_views'));
        // Filter dropdowns and query filtering on edit.php
        add_action('restrict_manage_posts', array($this, 'add_admin_filters'));
        add_action('pre_get_posts', array($this, 'filter_admin_posts_query'));
        add_action('wp_insert_post', array($this, 'set_default_sync_mode_on_create'), 5, 3);
        // Background one-time backfill
        add_action('admin_init', array('WP_Blogger_Sync', 'backfill_synced_blog_meta'));
    }

    /**
     * Register Blogger Label taxonomy — now attached to native 'post' type
     */
    public function register_taxonomies() {
        // Blogger Labels taxonomy — attached to native WP posts
        register_taxonomy('blogger_label', array('post'), array(
            'hierarchical'      => false,
            'labels'            => array(
                'name'          => __('Nhãn Blogger', 'wp-blogger-manager'),
                'singular_name' => __('Nhãn Blogger', 'wp-blogger-manager'),
                'search_items'  => __('Tìm nhãn', 'wp-blogger-manager'),
                'all_items'     => __('Tất cả nhãn', 'wp-blogger-manager'),
                'edit_item'     => __('Sửa nhãn', 'wp-blogger-manager'),
                'update_item'   => __('Cập nhật nhãn', 'wp-blogger-manager'),
                'add_new_item'  => __('Thêm nhãn mới', 'wp-blogger-manager'),
                'new_item_name' => __('Tên nhãn mới', 'wp-blogger-manager'),
                'menu_name'     => __('Nhãn Blogger', 'wp-blogger-manager'),
            ),
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'blogger-label'),
            'show_in_rest'      => true,
        ));
    }

    /**
     * Add sync metabox to native WP post editor.
     */
    public function add_sync_metabox() {
        add_meta_box(
            'wp_blogger_sync_metabox',
            '<span class="dashicons dashicons-cloud" style="color: #ff6600; margin-right: 5px;"></span> ' . __('Đồng bộ Google Blogger', 'wp-blogger-manager'),
            array($this, 'render_sync_metabox'),
            'post',
            'side',
            'high'
        );
    }

    public function render_sync_metabox($post) {
        wp_nonce_field('wp_blogger_metabox_save', 'wp_blogger_metabox_nonce');
        $all_blogs = get_option('wp_blogger_blogs', array());
        $blogs = array();
        foreach ($all_blogs as $b_id => $b_data) {
            if (!isset($b_data['is_active']) || !empty($b_data['is_active'])) {
                $blogs[$b_id] = $b_data;
            }
        }
        $sync_mode      = get_post_meta($post->ID, '_blogger_sync_mode', true);
        $synced_blogs   = get_post_meta($post->ID, '_blogger_synced_blogs', true);
        if (!is_array($synced_blogs)) { $synced_blogs = array(); }

        $selected_blogs = get_post_meta($post->ID, '_blogger_selected_blogs', true);
        if (!is_array($selected_blogs)) { $selected_blogs = array(); }

        // If post has already been synced, remember the synced blogs!
        if (!empty($synced_blogs)) {
            $synced_ids = array();
            foreach ($synced_blogs as $b_id => $sb_item) {
                if (isset($sb_item['status']) && $sb_item['status'] === 'synced') {
                    $synced_ids[] = (string) $b_id;
                }
            }
            if (!empty($synced_ids)) {
                $selected_blogs = array_unique(array_merge($selected_blogs, $synced_ids));
            }
            if (empty($sync_mode)) {
                $sync_mode = 'selected';
            }
        } else {
            // New post or not synced yet: DEFAULT TO 'none' (Không đồng bộ)
            if (empty($sync_mode)) {
                $sync_mode = 'none';
            }
        }

        include WP_BLOGGER_PLUGIN_DIR . 'templates/metabox-sync.php';
    }

    /**
     * Ensure newly created posts default to mode 'none' (Do not sync)
     */
    public function set_default_sync_mode_on_create($post_id, $post, $update) {
        if ($post->post_type !== 'post') {
            return;
        }
        if (!$update) {
            $existing_mode = get_post_meta($post_id, '_blogger_sync_mode', true);
            if (empty($existing_mode)) {
                update_post_meta($post_id, '_blogger_sync_mode', 'none');
                update_post_meta($post_id, '_blogger_selected_blogs', array());
            }
        }
    }

    public function save_metabox_data($post_id, $post) {
        if (!isset($_POST['wp_blogger_metabox_nonce']) || !wp_verify_nonce($_POST['wp_blogger_metabox_nonce'], 'wp_blogger_metabox_save')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
        if (!current_user_can('edit_post', $post_id)) { return; }
        // Only save for native post type
        if ($post->post_type !== 'post') { return; }
        $sync_mode = isset($_POST['wp_blogger_sync_mode']) ? sanitize_text_field($_POST['wp_blogger_sync_mode']) : 'none';
        if (!in_array($sync_mode, array('all', 'selected', 'none'), true)) { $sync_mode = 'none'; }
        update_post_meta($post_id, '_blogger_sync_mode', $sync_mode);

        $selected_blogs = array();
        if (isset($_POST['wp_blogger_selected_blogs']) && is_array($_POST['wp_blogger_selected_blogs'])) {
            $selected_blogs = array_map('sanitize_text_field', $_POST['wp_blogger_selected_blogs']);
        }

        if (!empty($selected_blogs)) {
            update_post_meta($post_id, '_blogger_selected_blogs', $selected_blogs);
        } elseif ($sync_mode === 'selected') {
            // If mode is 'selected' but no checkboxes were ticked in this request, fallback to previously synced blogs
            $synced_blogs = get_post_meta($post_id, '_blogger_synced_blogs', true);
            if (!empty($synced_blogs) && is_array($synced_blogs)) {
                $synced_ids = array();
                foreach ($synced_blogs as $b_id => $sb_item) {
                    if (isset($sb_item['status']) && $sb_item['status'] === 'synced') {
                        $synced_ids[] = (string) $b_id;
                    }
                }
                if (!empty($synced_ids)) {
                    update_post_meta($post_id, '_blogger_selected_blogs', $synced_ids);
                }
            }
        }
    }

    /**
     * Add Blogger views ("phân mục") above the post list table
     * e.g. Đã đăng Blogger (X) | Chưa đăng (Y) | Lỗi sync (Z) | danang247.blogspot.com (A)
     *
     * @param array $views Existing views array
     * @return array Modified views array
     */
    public function add_blogger_views($views) {
        global $wpdb;

        $base_url  = admin_url('edit.php');
        $filter_blog   = isset($_GET['blogger_blog']) ? sanitize_text_field($_GET['blogger_blog']) : '';
        $filter_status = isset($_GET['blogger_sync_status']) ? sanitize_text_field($_GET['blogger_sync_status']) : '';

        // If filtering by blogger, remove active 'current' class from 'all'
        if (!empty($filter_blog) || !empty($filter_status)) {
            if (isset($views['all'])) {
                $views['all'] = str_replace('class="current"', '', $views['all']);
            }
        }

        // Only count valid human-visible post statuses (exclude auto-draft, inherit, trash)
        $status_sql = "'publish','draft','pending','future','private'";

        // Count synced (Đã đăng Blogger)
        $count_synced = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE p.post_type = 'post' AND p.post_status IN ({$status_sql})
             AND ((pm.meta_key = '_blogger_sync_status' AND pm.meta_value IN ('synced', 'partial')) OR pm.meta_key = '_blogger_synced_blog_id')"
        );

        // Count not synced (Chưa đăng Blogger)
        $count_not_synced = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
             WHERE p.post_type = 'post' AND p.post_status IN ({$status_sql})
             AND p.ID NOT IN (
                 SELECT DISTINCT post_id FROM {$wpdb->postmeta}
                 WHERE (meta_key = '_blogger_sync_status' AND meta_value IN ('synced', 'partial'))
                    OR meta_key = '_blogger_synced_blog_id'
             )"
        );

        // Count error (Lỗi sync)
        $count_error = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE p.post_type = 'post' AND p.post_status IN ({$status_sql})
             AND pm.meta_key = '_blogger_sync_status' AND pm.meta_value = 'error'"
        );

        // View: Đã đăng Blogger
        $is_synced_active = ($filter_blog === 'synced_any' || $filter_status === 'synced');
        $synced_url = add_query_arg(array('blogger_blog' => 'synced_any', 'blogger_sync_status' => false, 'paged' => false), $base_url);
        $views['blogger_synced'] = sprintf(
            '<a href="%s"%s>%s <span class="count">(%d)</span></a>',
            esc_url($synced_url),
            $is_synced_active ? ' class="current"' : '',
            __('Đã đăng Blogger', 'wp-blogger-manager'),
            $count_synced
        );

        // View: Chưa đăng
        $is_not_synced_active = ($filter_blog === 'not_synced' || $filter_status === 'not_synced');
        $not_synced_url = add_query_arg(array('blogger_blog' => 'not_synced', 'blogger_sync_status' => false, 'paged' => false), $base_url);
        $views['blogger_not_synced'] = sprintf(
            '<a href="%s"%s>%s <span class="count">(%d)</span></a>',
            esc_url($not_synced_url),
            $is_not_synced_active ? ' class="current"' : '',
            __('Chưa đăng Blogger', 'wp-blogger-manager'),
            $count_not_synced
        );

        // View: Lỗi sync (ONLY display if count > 0 or actively filtering by error)
        if ($count_error > 0 || $filter_status === 'error') {
            $is_error_active = ($filter_status === 'error');
            $error_url = add_query_arg(array('blogger_sync_status' => 'error', 'blogger_blog' => false, 'paged' => false), $base_url);
            $views['blogger_error'] = sprintf(
                '<a href="%s"%s style="color:#ef4444;">%s <span class="count">(%d)</span></a>',
                esc_url($error_url),
                $is_error_active ? ' class="current"' : '',
                __('Lỗi sync', 'wp-blogger-manager'),
                $count_error
            );
        }

        return $views;
    }

    /**
     * Add filter dropdowns for Blogger blogs & Sync Status above the post table
     */
    public function add_admin_filters($post_type, $which = 'top') {
        global $typenow;
        if ($typenow !== 'post') {
            return;
        }

        $all_blogs     = get_option('wp_blogger_blogs', array());
        $filter_blog   = isset($_GET['blogger_blog']) ? sanitize_text_field($_GET['blogger_blog']) : '';
        $filter_status = isset($_GET['blogger_sync_status']) ? sanitize_text_field($_GET['blogger_sync_status']) : '';
        ?>
        <!-- Filter by Blogger Destination -->
        <select name="blogger_blog" id="filter-by-blogger-blog">
            <option value=""><?php esc_html_e('Tất cả Blogger (Blogspot)', 'wp-blogger-manager'); ?></option>
            <option value="synced_any" <?php selected($filter_blog, 'synced_any'); ?>><?php esc_html_e('★ Đã đăng lên Blogger (Bất kỳ)', 'wp-blogger-manager'); ?></option>
            <option value="not_synced" <?php selected($filter_blog, 'not_synced'); ?>><?php esc_html_e('Chưa đăng lên Blogger nào', 'wp-blogger-manager'); ?></option>
            <?php if (!empty($all_blogs)) : ?>
                <optgroup label="<?php esc_attr_e('Lọc theo từng Blogger:', 'wp-blogger-manager'); ?>">
                    <?php foreach ($all_blogs as $b_id => $b) : ?>
                        <?php
                        $count  = WP_Blogger_Sync::get_synced_post_count_for_blog($b_id, 'post');
                        $domain = WP_Blogger_Sync::get_blog_domain($b);
                        ?>
                        <option value="<?php echo esc_attr($b_id); ?>" <?php selected($filter_blog, $b_id); ?> title="<?php echo esc_attr($b['name']); ?>">
                            <?php echo esc_html($domain); ?> (<?php echo intval($count); ?> bài)
                        </option>
                    <?php endforeach; ?>
                </optgroup>
            <?php endif; ?>
        </select>

        <!-- Filter by Sync Status -->
        <select name="blogger_sync_status" id="filter-by-blogger-status">
            <option value=""><?php esc_html_e('Tất cả trạng thái Sync', 'wp-blogger-manager'); ?></option>
            <option value="synced" <?php selected($filter_status, 'synced'); ?>><?php esc_html_e('Đã đồng bộ', 'wp-blogger-manager'); ?></option>
            <option value="partial" <?php selected($filter_status, 'partial'); ?>><?php esc_html_e('Đồng bộ một phần', 'wp-blogger-manager'); ?></option>
            <option value="error" <?php selected($filter_status, 'error'); ?>><?php esc_html_e('Lỗi đồng bộ', 'wp-blogger-manager'); ?></option>
            <option value="not_synced" <?php selected($filter_status, 'not_synced'); ?>><?php esc_html_e('Chưa đồng bộ', 'wp-blogger-manager'); ?></option>
        </select>
        <?php
    }

    /**
     * Filter posts query on edit.php for native WP post type
     */
    public function filter_admin_posts_query($query) {
        global $pagenow, $typenow;
        if (!is_admin() || !$query->is_main_query() || $pagenow !== 'edit.php' || $typenow !== 'post') {
            return;
        }

        $filter_blog   = isset($_GET['blogger_blog']) ? sanitize_text_field($_GET['blogger_blog']) : '';
        $filter_status = isset($_GET['blogger_sync_status']) ? sanitize_text_field($_GET['blogger_sync_status']) : '';

        if (empty($filter_blog) && empty($filter_status)) {
            return;
        }

        $meta_query = $query->get('meta_query');
        if (!is_array($meta_query)) {
            $meta_query = array();
        }

        // 1. Filter by Blogger Destination
        if ($filter_blog === 'synced_any') {
            $meta_query[] = array(
                'relation' => 'OR',
                array('key' => '_blogger_sync_status', 'value' => array('synced', 'partial'), 'compare' => 'IN'),
                array('key' => '_blogger_synced_blog_id', 'compare' => 'EXISTS'),
            );
        } elseif ($filter_blog === 'not_synced') {
            $meta_query[] = array(
                'relation' => 'OR',
                array('key' => '_blogger_sync_status', 'compare' => 'NOT EXISTS'),
                array('key' => '_blogger_sync_status', 'value' => array('', 'error', 'deleted'), 'compare' => 'IN'),
            );
        } elseif (!empty($filter_blog)) {
            $meta_query[] = array(
                'relation' => 'OR',
                array(
                    'key'     => '_blogger_synced_blog_id',
                    'value'   => $filter_blog,
                    'compare' => '=',
                ),
                array(
                    'key'     => '_blogger_synced_blogs',
                    'value'   => '"' . $filter_blog . '"',
                    'compare' => 'LIKE',
                ),
                array(
                    'key'     => '_blogger_blog_id',
                    'value'   => $filter_blog,
                    'compare' => '=',
                ),
            );
        }

        // 2. Filter by Sync Status
        if ($filter_status === 'synced') {
            $meta_query[] = array('key' => '_blogger_sync_status', 'value' => 'synced', 'compare' => '=');
        } elseif ($filter_status === 'partial') {
            $meta_query[] = array('key' => '_blogger_sync_status', 'value' => 'partial', 'compare' => '=');
        } elseif ($filter_status === 'error') {
            $meta_query[] = array('key' => '_blogger_sync_status', 'value' => 'error', 'compare' => '=');
        } elseif ($filter_status === 'not_synced') {
            $meta_query[] = array(
                'relation' => 'OR',
                array('key' => '_blogger_sync_status', 'compare' => 'NOT EXISTS'),
                array('key' => '_blogger_sync_status', 'value' => '', 'compare' => '='),
            );
        }

        if (!empty($meta_query)) {
            $query->set('meta_query', $meta_query);
        }
    }

    public function add_blogger_columns($columns) {
        $new_columns = array();
        foreach ($columns as $key => $val) {
            $new_columns[$key] = $val;
            if ($key === 'title') {
                $new_columns['blogger_destination'] = __('Blogger đã đăng', 'wp-blogger-manager');
                $new_columns['blogger_sync']        = __('Trạng thái Sync', 'wp-blogger-manager');
                $new_columns['blogger_labels']      = __('Nhãn Blogger', 'wp-blogger-manager');
            }
        }
        return $new_columns;
    }

    public function render_blogger_columns($column, $post_id) {
        global $typenow;

        if ($column === 'blogger_destination') {
            $synced_blogs = WP_Blogger_Sync::get_synced_blogs_for_post($post_id);
            $sync_mode    = get_post_meta($post_id, '_blogger_sync_mode', true);
            $selected     = get_post_meta($post_id, '_blogger_selected_blogs', true);

            // Only show blogs where post was successfully published/synced
            $active_synced_blogs = array();
            if (!empty($synced_blogs) && is_array($synced_blogs)) {
                foreach ($synced_blogs as $b_id => $sb) {
                    if (isset($sb['status']) && $sb['status'] === 'synced') {
                        $active_synced_blogs[$b_id] = $sb;
                    }
                }
            }

            if (!empty($active_synced_blogs)) {
                echo '<div class="wp-blogger-blog-pill-list">';
                foreach ($active_synced_blogs as $b_id => $sb) {
                    $filter_url   = admin_url('edit.php?blogger_blog=' . urlencode($b_id));
                    $display_name = !empty($sb['domain']) ? $sb['domain'] : $sb['blog_name'];

                    echo '<span class="wp-blogger-blog-pill synced">';
                    echo '<span class="dashicons dashicons-yes"></span> ';
                    echo '<a href="' . esc_url($filter_url) . '" class="blog-name" title="' . esc_attr($sb['blog_name']) . '">';
                    echo esc_html($display_name);
                    echo '</a>';
                    if (!empty($sb['url'])) {
                        echo ' <a href="' . esc_url($sb['url']) . '" target="_blank" rel="noopener noreferrer" class="view-link" title="' . esc_attr__('Mở bài viết trực tiếp trên Blogger', 'wp-blogger-manager') . '">';
                        echo '<span class="dashicons dashicons-external"></span>';
                        echo '</a>';
                    }
                    if (!empty($sb['synced_at'])) {
                        echo '<span class="sync-date">' . esc_html(date_i18n('d/m H:i', strtotime($sb['synced_at']))) . '</span>';
                    }
                    echo '</span>';
                }
                echo '</div>';
            } else {
                $all_blogs = get_option('wp_blogger_blogs', array());
                if ($sync_mode === 'all') {
                    echo '<span class="wp-blogger-badge muted" title="' . esc_attr__('Sẽ đăng qua tất cả Blogger khi bấm Đồng bộ', 'wp-blogger-manager') . '"><span class="dashicons dashicons-cloud"></span> ' . sprintf(__('Mục tiêu: Tất cả (%d blog)', 'wp-blogger-manager'), count($all_blogs)) . '</span>';
                } elseif ($sync_mode === 'selected' && !empty($selected) && is_array($selected)) {
                    $sel_domains = array();
                    foreach ($selected as $s_id) {
                        if (isset($all_blogs[$s_id])) {
                            $sel_domains[] = WP_Blogger_Sync::get_blog_domain($all_blogs[$s_id]);
                        }
                    }
                    echo '<span class="wp-blogger-badge muted" title="' . esc_attr(implode(', ', $sel_domains)) . '"><span class="dashicons dashicons-tag"></span> ' . sprintf(__('Mục tiêu: %d blog', 'wp-blogger-manager'), count($selected)) . '</span>';
                } else {
                    echo '<span style="color:#94a3b8; font-size:12px;"><span class="dashicons dashicons-minus" style="font-size:14px;vertical-align:middle;"></span> ' . esc_html__('Chưa đăng blog nào', 'wp-blogger-manager') . '</span>';
                }
            }
        }

        if ($column === 'blogger_sync') {
            $sync_status  = get_post_meta($post_id, '_blogger_sync_status', true);
            $synced_blogs = get_post_meta($post_id, '_blogger_synced_blogs', true);
            $synced_at    = get_post_meta($post_id, '_blogger_synced_at', true);
            $sync_error   = get_post_meta($post_id, '_blogger_sync_error', true);

            $synced_count = 0;
            if (is_array($synced_blogs)) {
                foreach ($synced_blogs as $sb) {
                    if (isset($sb['status']) && $sb['status'] === 'synced') { $synced_count++; }
                }
            }
            if ($synced_count > 0) {
                echo '<div class="wp-blogger-col-status synced">';
                echo '<span class="wp-blogger-badge success"><span class="dashicons dashicons-yes-alt"></span> ' . sprintf(__('Đã sync (%d blog)', 'wp-blogger-manager'), $synced_count) . '</span>';
                if (!empty($synced_at)) {
                    echo '<br><small class="text-muted">' . esc_html(date_i18n('d/m H:i', strtotime($synced_at))) . '</small>';
                }
                echo '</div>';
            } elseif ($sync_status === 'error') {
                echo '<div class="wp-blogger-col-status is-sync-error">';
                echo '<span class="wp-blogger-badge danger"><span class="dashicons dashicons-warning"></span> Lỗi sync</span>';
                if (!empty($sync_error)) {
                    echo '<br><small class="text-danger" title="' . esc_attr($sync_error) . '">' . esc_html(wp_trim_words($sync_error, 4)) . '</small>';
                }
                echo '</div>';
            } else {
                echo '<span class="wp-blogger-badge muted"><span class="dashicons dashicons-minus"></span> Chưa sync</span>';
            }
            echo '<div class="row-actions"><span class="sync-now"><a href="#" class="wp-blogger-quick-sync-btn" data-post-id="' . intval($post_id) . '"><span class="dashicons dashicons-update"></span> Đồng bộ ngay</a></span></div>';
        }

        if ($column === 'blogger_labels') {
            $terms = get_the_terms($post_id, 'blogger_label');
            if (!empty($terms) && !is_wp_error($terms)) {
                $names = array_map(function($t) { return esc_html($t->name); }, $terms);
                echo '<span style="font-size:12px;color:#64748b;">' . implode(', ', $names) . '</span>';
            } else {
                echo '<span style="color:#cbd5e1;">-</span>';
            }
        }
    }
}
