<?php
/**
 * Post Synchronization Engine (WordPress <-> Google Blogger API v3)
 * Supports Multi-Account & Multi-Blogger Broadcast Sync
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Blogger_Sync {

    /**
     * API Client
     * @var WP_Blogger_API
     */
    private $api;

    /**
     * Media Processor
     * @var WP_Blogger_Media
     */
    private $media;

    /**
     * Recursion prevention flag
     * @var bool
     */
    private static $is_syncing = false;

    /**
     * Constructor
     */
    public function __construct(WP_Blogger_API $api, WP_Blogger_Media $media) {
        $this->api   = $api;
        $this->media = $media;

        $this->init_hooks();
    }

    /**
     * Register WordPress hooks
     */
    private function init_hooks() {
        // Hooks fire for native WP post type — blogger_post CPT has been removed
        add_action('save_post_post', array($this, 'handle_save_post'), 20, 3);
        add_action('wp_trash_post', array($this, 'handle_trash_post'), 10, 1);
        add_action('untrash_post', array($this, 'handle_untrash_post'), 10, 1);
        add_action('before_delete_post', array($this, 'handle_delete_post'), 10, 1);
    }

    /**
     * Create a Blogger DRAFT and return its preview URL
     * Used for "Preview on Blogger" feature — does NOT publish the post.
     *
     * @param int    $post_id  WP post ID
     * @param string $blog_id  Target Blogger blog ID
     * @return array|WP_Error  Array with 'preview_url' and 'blogger_post_id', or WP_Error
     */
    public function preview_on_blogger($post_id, $blog_id) {
        $post = get_post($post_id);
        if (!$post) {
            return new WP_Error('not_found', __('Bai viet khong ton tai.', 'wp-blogger-manager'));
        }

        if (empty($blog_id)) {
            return new WP_Error('no_blog', __('Vui long chon Blog Blogger de tao ban xem truoc.', 'wp-blogger-manager'));
        }

        // Build content
        $content           = apply_filters('the_content', $post->post_content);
        $processed_content = $this->media->process_content_for_blogger($content, $post_id);
        $labels            = $this->get_post_labels($post_id);

        $post_data = array(
            'title'   => html_entity_decode(get_the_title($post_id), ENT_QUOTES, 'UTF-8'),
            'content' => $processed_content,
            'labels'  => $labels,
        );

        // Always create as draft (isDraft = true)
        $res = $this->api->insert_post($blog_id, $post_data, true);

        if (is_wp_error($res)) {
            return $res;
        }

        $blogger_post_id = isset($res['id']) ? sanitize_text_field($res['id']) : '';
        $preview_url     = '';

        // Blogger draft preview URL pattern
        if (!empty($res['url'])) {
            $preview_url = $res['url'];
        } elseif (!empty($blogger_post_id)) {
            $all_blogs = get_option('wp_blogger_blogs', array());
            if (!empty($all_blogs[$blog_id]['url'])) {
                $blog_url    = rtrim($all_blogs[$blog_id]['url'], '/');
                $preview_url = $blog_url . '?zx=' . $blogger_post_id;
            }
        }

        // Store preview meta so user can clean up later
        update_post_meta($post_id, '_blogger_preview_post_id', $blogger_post_id);
        update_post_meta($post_id, '_blogger_preview_blog_id', sanitize_text_field($blog_id));
        update_post_meta($post_id, '_blogger_preview_url', esc_url_raw($preview_url));

        $this->log_action($post_id, $blog_id, $blogger_post_id, 'preview', 'success',
            sprintf(__('Da tao ban xem truoc tren Blogger [%s].', 'wp-blogger-manager'), $blog_id)
        );

        return array(
            'blogger_post_id' => $blogger_post_id,
            'preview_url'     => $preview_url,
            'blog_id'         => $blog_id,
        );
    }

    /**
     * Hook when post is saved/updated in WordPress
     */
    public function handle_save_post($post_id, $post, $update) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }

        if (self::$is_syncing) {
            return;
        }

        // This hook fires for native WP post type only
        if ($post->post_type !== 'post') {
            return;
        }

        $sync_mode    = get_post_meta($post_id, '_blogger_sync_mode', true);
        $synced_blogs = get_post_meta($post_id, '_blogger_synced_blogs', true);
        $has_synced   = (!empty($synced_blogs) && is_array($synced_blogs));

        // If post has no explicit mode:
        // - If it was already synced before, remember as 'selected' mode
        // - If brand new or not synced, default to 'none' (DO NOT sync)
        if (empty($sync_mode)) {
            if ($has_synced) {
                $sync_mode = 'selected';
                update_post_meta($post_id, '_blogger_sync_mode', 'selected');
            } else {
                return;
            }
        }

        if ($sync_mode === 'none') {
            return;
        }

        $settings   = get_option('wp_blogger_settings', array());
        $is_publish = in_array($post->post_status, array('publish', 'future'), true);

        if ($update && empty($settings['auto_sync_on_update'])) {
            return;
        }

        if (!$update && empty($settings['auto_sync_on_publish']) && $is_publish) {
            return;
        }

        $this->sync_post($post_id);
    }

    /**
     * Resolve target blogs for a post
     *
     * @param int $post_id
     * @param array|string|null $explicit_target_blogs
     * @return array List of blog IDs
     */
    public function resolve_target_blogs($post_id, $explicit_target_blogs = null) {
        if (!empty($explicit_target_blogs)) {
            return is_array($explicit_target_blogs) ? $explicit_target_blogs : array($explicit_target_blogs);
        }

        $all_blogs = get_option('wp_blogger_blogs', array());
        if (empty($all_blogs)) {
            return array();
        }

        $sync_mode    = get_post_meta($post_id, '_blogger_sync_mode', true);
        $synced_blogs = get_post_meta($post_id, '_blogger_synced_blogs', true);
        $has_synced   = (!empty($synced_blogs) && is_array($synced_blogs));

        // Default to 'none' for posts that haven't been configured yet, unless previously synced
        if (empty($sync_mode)) {
            $sync_mode = $has_synced ? 'selected' : 'none';
        }

        if ($sync_mode === 'none') {
            return array();
        }

        if ($sync_mode === 'all') {
            $target_ids = array();
            foreach ($all_blogs as $b_id => $b_data) {
                // Check if blog is active
                if (!isset($b_data['is_active']) || !empty($b_data['is_active'])) {
                    $target_ids[] = (string) $b_id;
                }
            }
            return $target_ids;
        }

        if ($sync_mode === 'selected') {
            $selected = get_post_meta($post_id, '_blogger_selected_blogs', true);
            if (is_array($selected) && !empty($selected)) {
                return array_map('strval', $selected);
            }
            // Fallback: If _blogger_selected_blogs is not set yet, use previously synced blogs!
            if ($has_synced) {
                $synced_ids = array();
                foreach ($synced_blogs as $b_id => $sb_item) {
                    if (isset($sb_item['status']) && $sb_item['status'] === 'synced') {
                        $synced_ids[] = (string) $b_id;
                    }
                }
                if (!empty($synced_ids)) {
                    return $synced_ids;
                }
            }
        }

        // Legacy fallback
        $legacy_blog_id = get_post_meta($post_id, '_blogger_blog_id', true);
        if (!empty($legacy_blog_id)) {
            return array((string) $legacy_blog_id);
        }

        return array();
    }

    /**
     * Sync single post to one, multiple, or ALL Blogger blogs
     *
     * @param int $post_id
     * @param array|string|null $target_blogs
     * @param bool $force_publish
     * @return array Sync results summary
     */
    public function sync_post($post_id, $target_blogs = null, $force_publish = false) {
        $post = get_post($post_id);
        if (!$post) {
            return new WP_Error('not_found', __('Bài viết không tồn tại.', 'wp-blogger-manager'));
        }

        $target_blog_ids = $this->resolve_target_blogs($post_id, $target_blogs);

        if (empty($target_blog_ids)) {
            $err = __('Không tìm thấy Blog Blogger nào để đồng bộ. Vui lòng kết nối tài khoản Google hoặc chọn Blog.', 'wp-blogger-manager');
            $this->log_action($post_id, '', '', 'sync', 'error', $err);
            update_post_meta($post_id, '_blogger_sync_status', 'error');
            update_post_meta($post_id, '_blogger_sync_error', $err);
            return new WP_Error('no_target_blogs', $err);
        }

        self::$is_syncing = true;

        // 1. Process Content with Image CDN Engine
        $raw_content = $post->post_content;
        $content = apply_filters('the_content', $raw_content);
        $processed_content = $this->media->process_content_for_blogger($content, $post_id);

        // 2. Extract & Sanitize Labels
        $raw_labels = $this->get_post_labels($post_id);
        $labels     = array();
        if (!empty($raw_labels) && is_array($raw_labels)) {
            foreach ($raw_labels as $lbl) {
                $lbl = trim(strip_tags($lbl));
                // Remove commas, quotes because Blogger uses comma as tag separator
                $lbl = str_replace(array(',', '"', "'"), '', $lbl);
                if (!empty($lbl)) {
                    $labels[] = $lbl;
                }
            }
            $labels = array_values(array_unique($labels));
        }

        // 3. Status determination
        $is_draft = ($post->post_status !== 'publish' && !$force_publish);
        if ($force_publish) {
            $is_draft = false;
        }

        // 4. Calculate published date safely (avoid 1970-01-01 for drafts or empty dates)
        $published_ts = 0;
        if (!empty($post->post_date_gmt) && $post->post_date_gmt !== '0000-00-00 00:00:00') {
            $published_ts = strtotime($post->post_date_gmt);
        } elseif (!empty($post->post_date) && $post->post_date !== '0000-00-00 00:00:00') {
            $published_ts = strtotime($post->post_date);
        }

        // Fallback to current time if timestamp is invalid or <= 0
        if (!$published_ts || $published_ts <= 0) {
            $published_ts = current_time('timestamp', true);
        }

        $published_iso = gmdate('Y-m-d\TH:i:s\Z', $published_ts);

        $post_title = get_the_title($post_id);
        if (empty($post_title)) {
            $post_title = $post->post_title;
        }
        if (empty($post_title)) {
            $post_title = __('Bài viết mới', 'wp-blogger-manager');
        }

        $post_data = array(
            'title'     => html_entity_decode($post_title, ENT_QUOTES, 'UTF-8'),
            'content'   => !empty($processed_content) ? $processed_content : '',
            'labels'    => $labels,
            'published' => $published_iso,
        );

        // Existing synced blogs map
        $synced_blogs = get_post_meta($post_id, '_blogger_synced_blogs', true);
        if (!is_array($synced_blogs)) {
            $synced_blogs = array();
            // Migrate legacy single blog sync data
            $legacy_post_id = get_post_meta($post_id, '_blogger_post_id', true);
            $legacy_blog_id = get_post_meta($post_id, '_blogger_blog_id', true);
            if (!empty($legacy_blog_id) && !empty($legacy_post_id)) {
                $synced_blogs[$legacy_blog_id] = array(
                    'blogger_post_id' => $legacy_post_id,
                    'url'             => get_post_meta($post_id, '_blogger_url', true),
                    'synced_at'       => get_post_meta($post_id, '_blogger_synced_at', true),
                    'status'          => 'synced',
                );
            }
        }

        $results = array(
            'success_count' => 0,
            'error_count'   => 0,
            'details'       => array(),
        );

        $all_blogs = get_option('wp_blogger_blogs', array());

        foreach ($target_blog_ids as $blog_id) {
            $blog_name = isset($all_blogs[$blog_id]['name']) ? $all_blogs[$blog_id]['name'] : $blog_id;
            $existing_blogger_post_id = isset($synced_blogs[$blog_id]['blogger_post_id']) ? $synced_blogs[$blog_id]['blogger_post_id'] : '';

            $action = 'create';
            $res = null;

            if (!empty($existing_blogger_post_id)) {
                $action = 'update';
                $res = $this->api->update_post($blog_id, $existing_blogger_post_id, $post_data, $is_draft);

                // If 404 on Blogger, fallback to recreate
                if (is_wp_error($res) && strpos($res->get_error_message(), '404') !== false) {
                    $action = 'create';
                    $res = $this->api->insert_post($blog_id, $post_data, $is_draft);
                }
            } else {
                $action = 'create';
                $res = $this->api->insert_post($blog_id, $post_data, $is_draft);
            }

            if (is_wp_error($res)) {
                $err_msg = $res->get_error_message();
                $synced_blogs[$blog_id] = array(
                    'status'    => 'error',
                    'error'     => $err_msg,
                    'synced_at' => current_time('mysql'),
                );
                $this->log_action($post_id, $blog_id, $existing_blogger_post_id, $action, 'error', $err_msg);
                $results['error_count']++;
                $results['details'][$blog_id] = array(
                    'blog_name' => $blog_name,
                    'status'    => 'error',
                    'message'   => $err_msg,
                );
            } else {
                $new_id  = isset($res['id']) ? sanitize_text_field($res['id']) : $existing_blogger_post_id;
                $url     = isset($res['url']) ? esc_url_raw($res['url']) : '';
                $msg     = sprintf(__('Đồng bộ thành công (%s) lên Blogger [%s].', 'wp-blogger-manager'), $action === 'create' ? 'Tạo mới' : 'Cập nhật', $blog_name);

                $synced_blogs[$blog_id] = array(
                    'blogger_post_id' => $new_id,
                    'url'             => $url,
                    'status'          => 'synced',
                    'synced_at'       => current_time('mysql'),
                    'action'          => $action,
                );

                $this->log_action($post_id, $blog_id, $new_id, $action, 'success', $msg);
                $results['success_count']++;
                $results['details'][$blog_id] = array(
                    'blog_name'       => $blog_name,
                    'status'          => 'synced',
                    'blogger_post_id' => $new_id,
                    'url'             => $url,
                    'message'         => $msg,
                );
            }
        }

        self::$is_syncing = false;

        // Save multi-blog sync mapping
        update_post_meta($post_id, '_blogger_synced_blogs', $synced_blogs);
        update_post_meta($post_id, '_blogger_synced_at', current_time('mysql'));

        // Maintain indexed _blogger_synced_blog_id postmeta for fast, reliable WP_Query filtering
        delete_post_meta($post_id, '_blogger_synced_blog_id');
        $synced_ids = array();
        foreach ($synced_blogs as $b_id => $sb_item) {
            if (isset($sb_item['status']) && $sb_item['status'] === 'synced') {
                add_post_meta($post_id, '_blogger_synced_blog_id', sanitize_text_field($b_id), false);
                $synced_ids[] = (string) $b_id;
            }
        }

        // Persist remembered blogs so future updates will automatically sync to these picked blogs
        if (!empty($synced_ids)) {
            $currently_selected = get_post_meta($post_id, '_blogger_selected_blogs', true);
            if (!is_array($currently_selected)) {
                $currently_selected = array();
            }
            $remembered_blogs = array_unique(array_merge($currently_selected, $synced_ids));
            update_post_meta($post_id, '_blogger_selected_blogs', array_values($remembered_blogs));

            $current_mode = get_post_meta($post_id, '_blogger_sync_mode', true);
            if (empty($current_mode) || $current_mode === 'none') {
                update_post_meta($post_id, '_blogger_sync_mode', 'selected');
            }
        }

        // Primary status summary
        if ($results['success_count'] > 0 && $results['error_count'] === 0) {
            update_post_meta($post_id, '_blogger_sync_status', 'synced');
            delete_post_meta($post_id, '_blogger_sync_error');
        } elseif ($results['success_count'] > 0 && $results['error_count'] > 0) {
            update_post_meta($post_id, '_blogger_sync_status', 'partial');
            update_post_meta($post_id, '_blogger_sync_error', sprintf(__('Đã đồng bộ %d blog, lỗi %d blog.', 'wp-blogger-manager'), $results['success_count'], $results['error_count']));
        } else {
            update_post_meta($post_id, '_blogger_sync_status', 'error');
            update_post_meta($post_id, '_blogger_sync_error', __('Không thể đồng bộ lên bất kỳ blog nào.', 'wp-blogger-manager'));
        }

        // Set primary link for quick reference
        $first_success = reset($synced_blogs);
        if (!empty($first_success['url'])) {
            update_post_meta($post_id, '_blogger_url', $first_success['url']);
            update_post_meta($post_id, '_blogger_post_id', $first_success['blogger_post_id']);
        }

        $results['message'] = sprintf(__('Đồng bộ hoàn tất: %d blog thành công, %d blog lỗi.', 'wp-blogger-manager'), $results['success_count'], $results['error_count']);
        return $results;
    }

    /**
     * Delete post across all synced Blogger blogs
     *
     * @param int $post_id WordPress post ID
     * @param bool $cleanup_meta Whether to clean up sync meta after deletion
     * @return array|false Result array on success, false if no synced blogs found
     */
    public function delete_blogger_posts($post_id, $cleanup_meta = true) {
        $synced_blogs = get_post_meta($post_id, '_blogger_synced_blogs', true);
        if (empty($synced_blogs) || !is_array($synced_blogs)) {
            // Check legacy single-blog sync data
            $legacy_post_id = get_post_meta($post_id, '_blogger_post_id', true);
            $legacy_blog_id = get_post_meta($post_id, '_blogger_blog_id', true);
            if (!empty($legacy_blog_id) && !empty($legacy_post_id)) {
                $synced_blogs[$legacy_blog_id] = array('blogger_post_id' => $legacy_post_id);
            }
        }

        if (empty($synced_blogs)) {
            return false;
        }

        $all_blogs     = get_option('wp_blogger_blogs', array());
        $success_count = 0;
        $error_count   = 0;
        $details       = array();

        foreach ($synced_blogs as $blog_id => $data) {
            if (empty($data['blogger_post_id'])) {
                continue;
            }

            $blog_name = isset($all_blogs[$blog_id]['name']) ? $all_blogs[$blog_id]['name'] : $blog_id;
            $res = $this->api->delete_post($blog_id, $data['blogger_post_id']);

            if (is_wp_error($res)) {
                $err_msg = $res->get_error_message();
                $this->log_action($post_id, $blog_id, $data['blogger_post_id'], 'delete', 'error', $err_msg);
                $error_count++;
                $details[$blog_id] = array(
                    'blog_name' => $blog_name,
                    'status'    => 'error',
                    'message'   => $err_msg,
                );
            } else {
                $msg = sprintf(__('Đã xoá bài viết trên Blogger [%s].', 'wp-blogger-manager'), $blog_name);
                $this->log_action($post_id, $blog_id, $data['blogger_post_id'], 'delete', 'success', $msg);
                $success_count++;
                $details[$blog_id] = array(
                    'blog_name' => $blog_name,
                    'status'    => 'deleted',
                    'message'   => $msg,
                );
            }
        }

        if ($cleanup_meta) {
            delete_post_meta($post_id, '_blogger_synced_blogs');
            delete_post_meta($post_id, '_blogger_synced_blog_id');
            delete_post_meta($post_id, '_blogger_post_id');
            delete_post_meta($post_id, '_blogger_url');
            update_post_meta($post_id, '_blogger_sync_status', 'deleted');
            delete_post_meta($post_id, '_blogger_sync_error');
        }

        return array(
            'success_count' => $success_count,
            'error_count'   => $error_count,
            'details'       => $details,
            'message'       => sprintf(
                __('Xoá hoàn tất: %d blog thành công, %d blog lỗi.', 'wp-blogger-manager'),
                $success_count,
                $error_count
            ),
        );
    }

    /**
     * Hook when post moved to trash in WP
     */
    public function handle_trash_post($post_id) {
        // Only act on native WP post type
        if (get_post_type($post_id) !== 'post') {
            return;
        }
        $settings = get_option('wp_blogger_settings', array());
        if (!empty($settings['auto_delete_on_trash'])) {
            $this->delete_blogger_posts($post_id);
        }
    }

    /**
     * Hook when blogger_post is restored from trash
     */
    public function handle_untrash_post($post_id) {
        if (get_post_type($post_id) !== 'post') {
            return;
        }
        $this->sync_post($post_id);
    }

    /**
     * Hook when post is permanently deleted
     */
    public function handle_delete_post($post_id) {
        if (get_post_type($post_id) !== 'post') {
            return;
        }
        $this->delete_blogger_posts($post_id);
    }

    /**
     * Extract labels for Blogger from WP Post Tags
     * - WP Tags (post_tag taxonomy) are used as Blogger Labels
     * - Categories are intentionally excluded (use Tags for label distinction)
     * - Legacy _blogger_custom_labels meta is still read as fallback
     * - blogger_label custom taxonomy terms are also merged in
     */
    public function get_post_labels($post_id) {
        $labels = array();

        // 1. Legacy custom labels meta (kept for backward compatibility)
        $custom_labels = get_post_meta($post_id, '_blogger_custom_labels', true);
        if (!empty($custom_labels)) {
            $custom_arr = array_map('trim', explode(',', $custom_labels));
            $labels = array_merge($labels, $custom_arr);
        }

        // 2. WP Post Tags -> Blogger Labels (primary source)
        $tags = get_the_tags($post_id);
        if (!empty($tags) && !is_wp_error($tags)) {
            foreach ($tags as $tag) {
                $labels[] = $tag->name;
            }
        }

        // 3. blogger_label custom taxonomy (CPT posts)
        $cpt_terms = get_the_terms($post_id, 'blogger_label');
        if (!empty($cpt_terms) && !is_wp_error($cpt_terms)) {
            foreach ($cpt_terms as $term) {
                $labels[] = $term->name;
            }
        }

        // Note: WP Categories are intentionally NOT synced to Blogger labels
        // to keep them separate (categories = site structure, tags = Blogger labels)

        return array_values(array_unique(array_filter($labels)));
    }

    /**
     * Migrate legacy blogger_post CPT entries to native WP post type.
     *
     * Copies all posts of type 'blogger_post' to 'post', preserving content,
     * meta (sync state, synced blogs, etc.), featured image, and author.
     * Original blogger_post entries are trashed after successful migration.
     *
     * @return array { migrated: int, skipped: int, ids: int[] }
     */
    public function migrate_blogger_posts_to_wp() {
        $migrated = 0;
        $skipped  = 0;
        $new_ids  = array();

        self::$is_syncing = true;

        $query = new WP_Query(array(
            'post_type'      => 'blogger_post',
            'post_status'    => array('publish', 'draft', 'pending', 'future', 'private'),
            'posts_per_page' => -1,
            'fields'         => 'all',
        ));

        if (!$query->have_posts()) {
            self::$is_syncing = false;
            return array('migrated' => 0, 'skipped' => 0, 'ids' => array());
        }

        foreach ($query->posts as $source) {
            $thumbnail_id = get_post_thumbnail_id($source->ID);

            // Create native WP post
            $new_id = wp_insert_post(array(
                'post_title'   => $source->post_title,
                'post_content' => $source->post_content,
                'post_excerpt' => $source->post_excerpt,
                'post_name'    => $source->post_name,
                'post_status'  => $source->post_status,
                'post_type'    => 'post',
                'post_author'  => $source->post_author,
                'post_date'    => $source->post_date,
                'post_date_gmt'=> $source->post_date_gmt,
            ), true);

            if (is_wp_error($new_id) || !$new_id) {
                $skipped++;
                continue;
            }

            // Copy featured image
            if ($thumbnail_id) {
                set_post_thumbnail($new_id, $thumbnail_id);
            }

            // Copy ALL post meta (sync state, synced blogs, etc.)
            $all_meta = get_post_meta($source->ID);
            if (!empty($all_meta)) {
                foreach ($all_meta as $meta_key => $meta_values) {
                    // Skip internal WP meta
                    if (in_array($meta_key, array('_thumbnail_id', '_edit_lock', '_edit_last'), true)) {
                        continue;
                    }
                    delete_post_meta($new_id, $meta_key);
                    foreach ($meta_values as $meta_value) {
                        add_post_meta($new_id, $meta_key, maybe_unserialize($meta_value));
                    }
                }
            }

            // Copy blogger_label taxonomy terms to new post
            $terms = get_the_terms($source->ID, 'blogger_label');
            if (!empty($terms) && !is_wp_error($terms)) {
                $term_ids = wp_list_pluck($terms, 'term_id');
                wp_set_object_terms($new_id, $term_ids, 'blogger_label');
            }

            // Copy standard tags (post_tag)
            $tags = get_the_terms($source->ID, 'post_tag');
            if (!empty($tags) && !is_wp_error($tags)) {
                $tag_ids = wp_list_pluck($tags, 'term_id');
                wp_set_object_terms($new_id, $tag_ids, 'post_tag');
            }

            // Mark source as migrated and trash it
            update_post_meta($source->ID, '_blogger_migrated_to_wp_id', $new_id);
            wp_trash_post($source->ID);

            // Track migration source on new post
            update_post_meta($new_id, '_blogger_migrated_from_cpt_id', $source->ID);

            $migrated++;
            $new_ids[] = $new_id;
        }

        wp_reset_postdata();
        self::$is_syncing = false;

        return array(
            'migrated' => $migrated,
            'skipped'  => $skipped,
            'ids'      => $new_ids,
        );
    }

    /**
     * Log action to database
     */
    public function log_action($post_id, $blog_id, $blogger_post_id, $action, $status, $message) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'blogger_sync_logs';

        $wpdb->insert(
            $table_name,
            array(
                'post_id'         => intval($post_id),
                'blog_id'         => sanitize_text_field($blog_id),
                'blogger_post_id' => sanitize_text_field($blogger_post_id),
                'action'          => sanitize_text_field($action),
                'status'          => sanitize_text_field($status),
                'message'         => sanitize_textarea_field($message),
                'created_at'      => current_time('mysql'),
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s')
        );
    }

    /**
     * Fetch sync logs
     */
    public function get_logs($limit = 50, $status = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'blogger_sync_logs';

        $where = "1=1";
        $params = array();

        if (!empty($status)) {
            $where .= " AND status = %s";
            $params[] = $status;
        }

        $params[] = intval($limit);
        $sql = "SELECT * FROM {$table_name} WHERE {$where} ORDER BY id DESC LIMIT %d";

        if (!empty($params)) {
            return $wpdb->get_results($wpdb->prepare($sql, $params));
        }

        return $wpdb->get_results($sql);
    }

    /**
     * Clear all sync logs
     */
    public function clear_logs() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'blogger_sync_logs';
        return $wpdb->query("TRUNCATE TABLE {$table_name}");
    }

    /**
     * Get clean domain name from blog data or URL (e.g. hanoi247.blogspot.com)
     *
     * @param array|string $blog_or_url Blog data array or URL string
     * @param string $fallback Fallback string if domain cannot be parsed
     * @return string Clean domain name
     */
    public static function get_blog_domain($blog_or_url, $fallback = '') {
        $url = '';
        if (is_array($blog_or_url)) {
            if (!empty($blog_or_url['url'])) {
                $url = $blog_or_url['url'];
            }
            if (empty($fallback) && !empty($blog_or_url['name'])) {
                $fallback = $blog_or_url['name'];
            }
        } elseif (is_string($blog_or_url)) {
            $url = $blog_or_url;
        }

        if (!empty($url)) {
            $host = parse_url($url, PHP_URL_HOST);
            if (!empty($host)) {
                return preg_replace('#^www\.#i', '', $host);
            }
            $clean = preg_replace('#^https?://(www\.)?#i', '', rtrim($url, '/'));
            $clean = explode('/', $clean)[0];
            if (!empty($clean)) {
                return $clean;
            }
        }

        return !empty($fallback) ? $fallback : 'blogger.com';
    }

    /**
     * Get detailed list of synced Blogger blogs for a post
     *
     * @param int $post_id
     * @return array Array of synced blogs data with blog_id, blog_name, domain, url, status, synced_at
     */
    public static function get_synced_blogs_for_post($post_id) {
        $synced_blogs = get_post_meta($post_id, '_blogger_synced_blogs', true);
        if (!is_array($synced_blogs) || empty($synced_blogs)) {
            // Legacy single blog check
            $legacy_blog_id = get_post_meta($post_id, '_blogger_blog_id', true);
            $legacy_post_id = get_post_meta($post_id, '_blogger_post_id', true);
            $legacy_url     = get_post_meta($post_id, '_blogger_url', true);
            $legacy_status  = get_post_meta($post_id, '_blogger_sync_status', true);
            if (!empty($legacy_blog_id) && !empty($legacy_post_id)) {
                $synced_blogs = array(
                    $legacy_blog_id => array(
                        'blogger_post_id' => $legacy_post_id,
                        'url'             => $legacy_url,
                        'status'          => !empty($legacy_status) ? $legacy_status : 'synced',
                        'synced_at'       => get_post_meta($post_id, '_blogger_synced_at', true),
                    )
                );
            } else {
                return array();
            }
        }

        $all_blogs = get_option('wp_blogger_blogs', array());
        $results   = array();

        foreach ($synced_blogs as $blog_id => $data) {
            $blog_name = isset($all_blogs[$blog_id]['name']) ? $all_blogs[$blog_id]['name'] : sprintf(__('Blogger (%s)', 'wp-blogger-manager'), substr($blog_id, -6));
            $blog_url  = isset($all_blogs[$blog_id]['url']) ? $all_blogs[$blog_id]['url'] : '';
            if (empty($blog_url) && !empty($data['url'])) {
                $blog_url = $data['url'];
            }
            $domain = self::get_blog_domain(!empty($blog_url) ? $blog_url : (isset($all_blogs[$blog_id]) ? $all_blogs[$blog_id] : array()), $blog_name);

            $results[$blog_id] = array(
                'blog_id'         => $blog_id,
                'blog_name'       => $blog_name,
                'domain'          => $domain,
                'blogger_post_id' => isset($data['blogger_post_id']) ? $data['blogger_post_id'] : '',
                'url'             => isset($data['url']) ? $data['url'] : '',
                'status'          => isset($data['status']) ? $data['status'] : 'synced',
                'synced_at'       => isset($data['synced_at']) ? $data['synced_at'] : '',
                'error'           => isset($data['error']) ? $data['error'] : '',
            );
        }

        return $results;
    }

    /**
     * Get count of posts successfully synced to a specific blog
     *
     * @param string $blog_id
     * @return int
     */
    public static function get_synced_post_count_for_blog($blog_id, $post_type = 'post') {
        global $wpdb;
        if (empty($blog_id)) {
            return 0;
        }

        // All posts are now native 'post' type
        $like_pattern = '%"' . $wpdb->esc_like($blog_id) . '"%';

        // 1. Try indexed _blogger_synced_blog_id (fast)
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE p.post_type = 'post' AND p.post_status != 'trash'
             AND pm.meta_key = '_blogger_synced_blog_id' AND pm.meta_value = %s",
            $blog_id
        ));

        if ($count !== null && intval($count) > 0) {
            return intval($count);
        }

        // 2. Fallback to serialized _blogger_synced_blogs or legacy _blogger_blog_id
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE p.post_type = 'post' AND p.post_status != 'trash'
             AND ((pm.meta_key = '_blogger_synced_blogs' AND pm.meta_value LIKE %s)
                  OR (pm.meta_key = '_blogger_blog_id' AND pm.meta_value = %s))",
            $like_pattern,
            $blog_id
        ));

        return intval($count);
    }

    /**
     * One-time background migration to populate _blogger_synced_blog_id for existing posts
     */
    public static function backfill_synced_blog_meta() {
        if (get_option('wp_blogger_synced_meta_backfilled', false)) {
            return;
        }

        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_blogger_synced_blogs'"
        );

        if (!empty($rows)) {
            foreach ($rows as $row) {
                $synced = maybe_unserialize($row->meta_value);
                if (is_array($synced)) {
                    delete_post_meta($row->post_id, '_blogger_synced_blog_id');
                    foreach ($synced as $b_id => $item) {
                        if (isset($item['status']) && $item['status'] === 'synced') {
                            add_post_meta($row->post_id, '_blogger_synced_blog_id', sanitize_text_field($b_id), false);
                        }
                    }
                }
            }
        }

        // Also handle legacy _blogger_blog_id
        $legacy_rows = $wpdb->get_results(
            "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_blogger_blog_id' AND meta_value != ''"
        );
        if (!empty($legacy_rows)) {
            foreach ($legacy_rows as $lrow) {
                $status = get_post_meta($lrow->post_id, '_blogger_sync_status', true);
                if ($status === 'synced') {
                    $existing = get_post_meta($lrow->post_id, '_blogger_synced_blog_id');
                    if (!in_array($lrow->meta_value, (array)$existing, true)) {
                        add_post_meta($lrow->post_id, '_blogger_synced_blog_id', sanitize_text_field($lrow->meta_value), false);
                    }
                }
            }
        }

        update_option('wp_blogger_synced_meta_backfilled', true);
    }
}
