<?php
/**
 * Google Blogger API v3 Client with Multi-Account Support
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Blogger_API {

    const BASE_URL        = 'https://www.googleapis.com/blogger/v3';
    const QUOTA_DAILY_MAX = 10000;  // Google Blogger API v3 daily quota
    const QUOTA_RATE_MAX  = 100;    // Per 100 seconds per IP
    const QUOTA_WARN_PCT  = 70;     // Warn at 70%
    const QUOTA_DANGER_PCT = 90;    // Danger at 90%

    /**
     * Auth instance
     * @var WP_Blogger_Auth
     */
    private $auth;

    /**
     * Constructor
     */
    public function __construct(WP_Blogger_Auth $auth) {
        $this->auth = $auth;
    }

    /**
     * Resolve account ID for a specific blog ID
     */
    public function get_account_for_blog($blog_id) {
        $blogs = get_option('wp_blogger_blogs', array());
        if (isset($blogs[$blog_id]) && !empty($blogs[$blog_id]['account_id'])) {
            return $blogs[$blog_id]['account_id'];
        }

        // Search through array
        foreach ($blogs as $b) {
            if (isset($b['id']) && $b['id'] === $blog_id && !empty($b['account_id'])) {
                return $b['account_id'];
            }
        }

        // Fallback to first connected account
        $accounts = $this->auth->get_accounts();
        if (!empty($accounts)) {
            $first = reset($accounts);
            return $first['account_id'];
        }

        return '';
    }

    /**
     * Make an authenticated HTTP request to Blogger API v3
     */
    private function request($endpoint, $method = 'GET', $body = null, $query_params = array(), $account_id = '') {
        $access_token = $this->auth->get_valid_access_token($account_id);

        if (is_wp_error($access_token)) {
            return $access_token;
        }

        $url = self::BASE_URL . '/' . ltrim($endpoint, '/');

        if (!empty($query_params)) {
            $url = add_query_arg($query_params, $url);
        }

        $headers = array(
            'Authorization' => 'Bearer ' . $access_token,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        );

        $args = array(
            'method'    => strtoupper($method),
            'headers'   => $headers,
            'timeout'   => 45,
            'sslverify' => true,
        );

        if ($body !== null && in_array(strtoupper($method), array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = is_array($body) ? wp_json_encode($body) : $body;
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            $this->track_api_call($method, 0, true);
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $data = json_decode($response_body, true);

        // Track every API call
        $is_rate_error = in_array($code, array(429, 403));
        $this->track_api_call($method, $code, $is_rate_error);

        // Delete returns 204 No Content
        if ($code === 204) {
            return true;
        }

        if ($code >= 400) {
            $error_message = __('Lỗi không xác định từ Blogger API.', 'wp-blogger-manager');
            if (!empty($data['error']['message'])) {
                $error_message = $data['error']['message'];
                if (!empty($data['error']['errors']) && is_array($data['error']['errors'])) {
                    $details = array();
                    foreach ($data['error']['errors'] as $sub_err) {
                        if (!empty($sub_err['reason']) && !empty($sub_err['message']) && $sub_err['message'] !== $data['error']['message']) {
                            $details[] = $sub_err['reason'] . ': ' . $sub_err['message'];
                        }
                    }
                    if (!empty($details)) {
                        $error_message .= ' [' . implode('; ', $details) . ']';
                    }
                }
            } elseif (!empty($data['error_description'])) {
                $error_message = $data['error_description'];
            }
            return new WP_Error('blogger_api_error', sprintf(__('Blogger API Lỗi (%d): %s', 'wp-blogger-manager'), $code, $error_message), $data);
        }

        return $data;
    }

    /**
     * Track a single API call to the daily quota counter
     *
     * @param string $method     HTTP method (GET, POST, PUT, DELETE, PATCH)
     * @param int    $http_code  HTTP response code (0 = network error)
     * @param bool   $is_error   Whether this call produced a rate-limit/quota error
     */
    private function track_api_call($method, $http_code = 200, $is_error = false) {
        $today     = current_time('Y-m-d');
        $option_key = 'wp_blogger_quota_' . $today;

        $quota = get_option($option_key, array(
            'date'        => $today,
            'total'       => 0,
            'get'         => 0,
            'write'       => 0,  // POST + PUT + PATCH + DELETE
            'errors'      => 0,  // 429 / 403 hits
            'last_call'   => '',
        ));

        $quota['total']++;
        $quota['last_call'] = current_time('Y-m-d H:i:s');

        $method_upper = strtoupper($method);
        if ($method_upper === 'GET') {
            $quota['get']++;
        } else {
            $quota['write']++;
        }

        if ($is_error) {
            $quota['errors']++;
        }

        update_option($option_key, $quota, false);

        // Auto-cleanup: remove quota records older than 8 days
        $this->cleanup_old_quota();
    }

    /**
     * Remove quota option keys older than 8 days to keep DB clean
     */
    private function cleanup_old_quota() {
        // Only run cleanup ~1% of the time to avoid overhead
        if (mt_rand(1, 100) !== 1) {
            return;
        }
        for ($i = 8; $i <= 30; $i++) {
            $old_date = date('Y-m-d', strtotime("-{$i} days", current_time('timestamp')));
            delete_option('wp_blogger_quota_' . $old_date);
        }
    }

    /**
     * Get quota usage for today
     *
     * @return array {
     *   total, get, write, errors, last_call, percent, status, limit
     * }
     */
    public function get_quota_today() {
        $today     = current_time('Y-m-d');
        $option_key = 'wp_blogger_quota_' . $today;

        $quota = get_option($option_key, array(
            'date'      => $today,
            'total'     => 0,
            'get'       => 0,
            'write'     => 0,
            'errors'    => 0,
            'last_call' => '',
        ));

        $limit   = self::QUOTA_DAILY_MAX;
        $total   = intval($quota['total']);
        $percent = $limit > 0 ? round(($total / $limit) * 100, 2) : 0;

        if ($percent >= self::QUOTA_DANGER_PCT) {
            $status = 'danger';
        } elseif ($percent >= self::QUOTA_WARN_PCT) {
            $status = 'warning';
        } else {
            $status = 'safe';
        }

        return array(
            'date'      => $today,
            'total'     => $total,
            'get'       => intval($quota['get']),
            'write'     => intval($quota['write']),
            'errors'    => intval($quota['errors']),
            'last_call' => $quota['last_call'],
            'limit'     => $limit,
            'remaining' => max(0, $limit - $total),
            'percent'   => $percent,
            'status'    => $status,
        );
    }

    /**
     * Get quota history for the past N days
     *
     * @param int $days Number of past days to retrieve (default 7)
     * @return array  Array of daily quota records, newest first
     */
    public function get_quota_history($days = 7) {
        $history = array();
        for ($i = 0; $i < $days; $i++) {
            $date       = date('Y-m-d', strtotime("-{$i} days", current_time('timestamp')));
            $option_key = 'wp_blogger_quota_' . $date;
            $record     = get_option($option_key, null);

            $history[] = array(
                'date'   => $date,
                'total'  => $record ? intval($record['total'])  : 0,
                'get'    => $record ? intval($record['get'])    : 0,
                'write'  => $record ? intval($record['write'])  : 0,
                'errors' => $record ? intval($record['errors']) : 0,
            );
        }
        return $history;
    }

    /**
     * Get blogs for a specific Google account
     */
    public function get_user_blogs($account_id = '') {
        $result = $this->request('users/self/blogs', 'GET', null, array(), $account_id);
        if (is_wp_error($result)) {
            return $result;
        }

        $blogs = array();
        if (!empty($result['items']) && is_array($result['items'])) {
            foreach ($result['items'] as $item) {
                $b_id = sanitize_text_field($item['id']);
                $blogs[$b_id] = array(
                    'id'          => $b_id,
                    'account_id'  => $account_id,
                    'name'        => sanitize_text_field($item['name']),
                    'url'         => esc_url_raw($item['url']),
                    'description' => isset($item['description']) ? sanitize_text_field($item['description']) : '',
                    'posts_count' => isset($item['posts']['totalItems']) ? intval($item['posts']['totalItems']) : 0,
                    'updated'     => isset($item['updated']) ? sanitize_text_field($item['updated']) : '',
                    'is_active'   => 1,
                );
            }
        }
        return $blogs;
    }

    /**
     * Refresh and aggregate all blogs across all connected Google accounts
     */
    public function fetch_all_accounts_blogs() {
        $accounts = $this->auth->get_accounts();
        if (empty($accounts)) {
            update_option('wp_blogger_blogs', array());
            return array();
        }

        $existing_blogs = get_option('wp_blogger_blogs', array());
        $all_blogs      = array();

        foreach ($accounts as $acc_id => $acc) {
            $blogs = $this->get_user_blogs($acc_id);
            if (!is_wp_error($blogs) && is_array($blogs)) {
                foreach ($blogs as $b_id => $b_data) {
                    $b_data['account_email'] = $acc['user_email'];
                    $b_data['account_name']  = $acc['user_name'];

                    // Preserve active state if set previously
                    if (isset($existing_blogs[$b_id]['is_active'])) {
                        $b_data['is_active'] = $existing_blogs[$b_id]['is_active'];
                    }

                    $all_blogs[$b_id] = $b_data;
                }
            }
        }

        update_option('wp_blogger_blogs', $all_blogs);
        return $all_blogs;
    }

    /**
     * Get single blog details
     */
    public function get_blog($blog_id) {
        $account_id = $this->get_account_for_blog($blog_id);
        return $this->request('blogs/' . urlencode($blog_id), 'GET', null, array(), $account_id);
    }

    /**
     * Get posts list from a blog
     */
    public function get_posts($blog_id, $max_results = 20, $page_token = '', $status = 'LIVE') {
        $account_id = $this->get_account_for_blog($blog_id);
        $params = array(
            'maxResults'   => intval($max_results),
            'fetchBodies'  => 'true',
            'fetchImages'  => 'true',
            'status'       => $status,
        );

        if (!empty($page_token)) {
            $params['pageToken'] = $page_token;
        }

        return $this->request('blogs/' . urlencode($blog_id) . '/posts', 'GET', null, $params, $account_id);
    }

    /**
     * Get single post from Blogger
     */
    public function get_post($blog_id, $post_id) {
        $account_id = $this->get_account_for_blog($blog_id);
        return $this->request('blogs/' . urlencode($blog_id) . '/posts/' . urlencode($post_id), 'GET', null, array(), $account_id);
    }

    /**
     * Insert a new post to Blogger
     */
    public function insert_post($blog_id, $post_data, $is_draft = false) {
        $account_id = $this->get_account_for_blog($blog_id);
        $payload = array(
            'kind'    => 'blogger#post',
            'title'   => !empty($post_data['title']) ? $post_data['title'] : __('Bài viết mới', 'wp-blogger-manager'),
            'content' => isset($post_data['content']) ? $post_data['content'] : '',
        );

        if (!empty($post_data['labels']) && is_array($post_data['labels'])) {
            $payload['labels'] = array_values(array_filter(array_map('trim', $post_data['labels'])));
        }

        // Only send published date if the post is LIVE (not draft)
        if (!$is_draft && !empty($post_data['published'])) {
            $payload['published'] = $post_data['published'];
        }

        if (!empty($post_data['customMetaData'])) {
            $payload['customMetaData'] = sanitize_text_field($post_data['customMetaData']);
        }

        $query = array(
            'isDraft' => $is_draft ? 'true' : 'false',
        );

        return $this->request('blogs/' . urlencode($blog_id) . '/posts', 'POST', $payload, $query, $account_id);
    }

    /**
     * Update an existing post on Blogger
     */
    public function update_post($blog_id, $blogger_post_id, $post_data, $is_draft = false) {
        $account_id = $this->get_account_for_blog($blog_id);
        $payload = array(
            'kind'    => 'blogger#post',
            'id'      => $blogger_post_id,
            'title'   => !empty($post_data['title']) ? $post_data['title'] : '',
            'content' => isset($post_data['content']) ? $post_data['content'] : '',
        );

        if (isset($post_data['labels']) && is_array($post_data['labels'])) {
            $payload['labels'] = array_values(array_filter(array_map('trim', $post_data['labels'])));
        }

        // Only send published date if the post is LIVE (not draft)
        if (!$is_draft && !empty($post_data['published'])) {
            $payload['published'] = $post_data['published'];
        }

        if (!empty($post_data['customMetaData'])) {
            $payload['customMetaData'] = sanitize_text_field($post_data['customMetaData']);
        }

        $query = array(
            'isDraft' => $is_draft ? 'true' : 'false',
        );

        return $this->request('blogs/' . urlencode($blog_id) . '/posts/' . urlencode($blogger_post_id), 'PUT', $payload, $query, $account_id);
    }

    /**
     * Delete a post from Blogger
     */
    public function delete_post($blog_id, $blogger_post_id) {
        $account_id = $this->get_account_for_blog($blog_id);
        return $this->request('blogs/' . urlencode($blog_id) . '/posts/' . urlencode($blogger_post_id), 'DELETE', null, array(), $account_id);
    }

    /**
     * Get all labels (categories) from a Blogger blog
     * Uses the posts list endpoint and collects unique labels from all posts.
     *
     * @param string $blog_id
     * @return array|WP_Error  Array of label strings, or WP_Error on failure
     */
    public function get_labels($blog_id) {
        $account_id = $this->get_account_for_blog($blog_id);
        $labels     = array();
        $page_token = '';

        // Fetch up to 500 posts to collect labels (max 3 pages × maxResults=500)
        $max_iterations = 3;
        $iteration      = 0;

        do {
            $params = array(
                'maxResults'  => 500,
                'fetchBodies' => 'false',
                'fetchImages' => 'false',
                'status'      => 'LIVE',
                'fields'      => 'nextPageToken,items(labels)',
            );
            if (!empty($page_token)) {
                $params['pageToken'] = $page_token;
            }

            $result = $this->request('blogs/' . urlencode($blog_id) . '/posts', 'GET', null, $params, $account_id);

            if (is_wp_error($result)) {
                // Return what we have so far on error, or the error if empty
                return !empty($labels) ? $labels : $result;
            }

            if (!empty($result['items']) && is_array($result['items'])) {
                foreach ($result['items'] as $item) {
                    if (!empty($item['labels']) && is_array($item['labels'])) {
                        foreach ($item['labels'] as $label) {
                            $label = trim($label);
                            if ($label !== '' && !in_array($label, $labels, true)) {
                                $labels[] = $label;
                            }
                        }
                    }
                }
            }

            $page_token = !empty($result['nextPageToken']) ? $result['nextPageToken'] : '';
            $iteration++;

        } while (!empty($page_token) && $iteration < $max_iterations);

        sort($labels);
        return $labels;
    }

    /**
     * Get posts from a Blogger blog filtered by a specific label
     *
     * @param string $blog_id
     * @param string $label       Label/category name to filter by (empty = all posts)
     * @param int    $max_results Number of posts to fetch (1–20, or 0 = all in that label up to 500)
     * @param string $page_token  Pagination token
     * @return array|WP_Error
     */
    public function get_posts_by_label($blog_id, $label = '', $max_results = 10, $page_token = '') {
        $account_id = $this->get_account_for_blog($blog_id);

        // Fetch all = up to 500 posts in that label
        $fetch_all = ($max_results === 0);
        $limit     = $fetch_all ? 500 : min(20, max(1, intval($max_results)));

        $params = array(
            'maxResults'  => $limit,
            'fetchBodies' => 'true',
            'fetchImages' => 'true',
            'status'      => 'LIVE',
        );

        if (!empty($label)) {
            $params['labels'] = $label;
        }

        if (!empty($page_token)) {
            $params['pageToken'] = $page_token;
        }

        $result = $this->request('blogs/' . urlencode($blog_id) . '/posts', 'GET', null, $params, $account_id);

        if (is_wp_error($result)) {
            return $result;
        }

        // Normalize response
        $posts = array();
        if (!empty($result['items']) && is_array($result['items'])) {
            foreach ($result['items'] as $item) {
                $posts[] = array(
                    'blogger_post_id' => sanitize_text_field($item['id']),
                    'blog_id'         => $blog_id,
                    'title'           => sanitize_text_field($item['title']),
                    'content'         => isset($item['content']) ? wp_kses_post($item['content']) : '',
                    'url'             => esc_url_raw(!empty($item['url']) ? $item['url'] : ''),
                    'published'       => sanitize_text_field(!empty($item['published']) ? $item['published'] : ''),
                    'updated'         => sanitize_text_field(!empty($item['updated']) ? $item['updated'] : ''),
                    'labels'          => !empty($item['labels']) && is_array($item['labels']) ? array_map('sanitize_text_field', $item['labels']) : array(),
                    'author'          => !empty($item['author']['displayName']) ? sanitize_text_field($item['author']['displayName']) : '',
                    'thumbnail'       => !empty($item['images'][0]['url']) ? esc_url_raw($item['images'][0]['url']) : '',
                );
            }
        }

        return array(
            'posts'          => $posts,
            'nextPageToken'  => !empty($result['nextPageToken']) ? $result['nextPageToken'] : '',
            'totalItems'     => !empty($result['totalItems']) ? intval($result['totalItems']) : count($posts),
        );
    }
}
