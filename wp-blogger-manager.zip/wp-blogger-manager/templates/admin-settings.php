<?php
/**
 * Admin Settings Template (Google API & CDN Configuration)
 */

if (!defined('ABSPATH')) {
    exit;
}

$is_connected = !empty($auth_data['connected']);
?>

<div class="wrap wp-blogger-wrap">

    <div class="wp-blogger-header">
        <div class="wp-blogger-title-group">
            <h1><span class="dashicons dashicons-admin-settings"></span> <?php esc_html_e('Cài đặt API & Cấu hình CDN Hình ảnh', 'wp-blogger-manager'); ?></h1>
            <p><?php esc_html_e('Thiết lập kết nối Google Blogger API v3, tùy chỉnh kho lưu trữ ảnh CDN và cơ chế đồng bộ tự động.', 'wp-blogger-manager'); ?></p>
        </div>
    </div>

    <!-- Feedback messages -->
    <?php if (isset($_GET['settings_saved'])) : ?>
        <div class="wp-blogger-alert success">
            <span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Đã lưu các thay đổi cài đặt thành công!', 'wp-blogger-manager'); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['auth_success'])) : ?>
        <div class="wp-blogger-alert success">
            <span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Kết nối tài khoản Google Blogger thành công!', 'wp-blogger-manager'); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['auth_error'])) : ?>
        <div class="wp-blogger-alert error">
            <span class="dashicons dashicons-warning"></span> <?php echo esc_html(sprintf(__('Lỗi xác thực Google: %s', 'wp-blogger-manager'), $_GET['auth_error'])); ?>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-settings')); ?>">
        <?php wp_nonce_field('wp_blogger_save_settings', 'wp_blogger_save_settings_nonce'); ?>

        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">

            <!-- Left Main Column -->
            <div>

                <!-- 1. Google Cloud OAuth 2.0 Credentials Card -->
                <div class="wp-blogger-card">
                    <div class="wp-blogger-card-header">
                        <h2><span class="dashicons dashicons-google"></span> <?php esc_html_e('1. Cấu hình Google Cloud API (OAuth 2.0)', 'wp-blogger-manager'); ?></h2>
                        <?php if ($is_connected) : ?>
                            <span class="wp-blogger-badge success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Đang kết nối', 'wp-blogger-manager'); ?></span>
                        <?php else : ?>
                            <span class="wp-blogger-badge warning"><span class="dashicons dashicons-warning"></span> <?php esc_html_e('Chưa kết nối', 'wp-blogger-manager'); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="wp-blogger-card-body">

                        <!-- Redirect URI -->
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label"><?php esc_html_e('Authorized Redirect URI (Sao chép vào Google Cloud):', 'wp-blogger-manager'); ?></label>
                            <div class="wp-blogger-copy-group">
                                <input type="text" id="wp-blogger-redirect-uri" class="wp-blogger-input" value="<?php echo esc_attr($redirect_uri); ?>" readonly>
                                <button type="button" id="wp-blogger-copy-btn" class="wp-blogger-btn wp-blogger-btn-secondary">
                                    <span class="dashicons dashicons-admin-page"></span> <?php esc_html_e('Sao chép', 'wp-blogger-manager'); ?>
                                </button>
                            </div>
                            <p class="wp-blogger-desc"><?php esc_html_e('Dán URL này vào mục "Authorized redirect URIs" trong Google Cloud Console Credentials.', 'wp-blogger-manager'); ?></p>
                        </div>

                        <!-- Client ID -->
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label" for="client_id"><?php esc_html_e('Google Client ID:', 'wp-blogger-manager'); ?></label>
                            <input type="text" name="client_id" id="client_id" class="wp-blogger-input" value="<?php echo esc_attr(!empty($settings['client_id']) ? $settings['client_id'] : ''); ?>" placeholder="xxxxxx.apps.googleusercontent.com">
                        </div>

                        <!-- Client Secret -->
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label" for="client_secret"><?php esc_html_e('Google Client Secret:', 'wp-blogger-manager'); ?></label>
                            <input type="password" name="client_secret" id="client_secret" class="wp-blogger-input" value="<?php echo esc_attr(!empty($settings['client_secret']) ? $settings['client_secret'] : ''); ?>" placeholder="GOCSPX-xxxxxx">
                        </div>

                        <!-- OAuth Connect / Disconnect Buttons -->
                        <div style="margin-top: 24px; padding-top: 18px; border-top: 1px solid var(--wp-blogger-border); display: flex; gap: 12px; align-items: center;">
                            <?php if ($is_connected) : ?>
                                <div style="flex: 1;">
                                    <span style="font-size: 13px; color: #10b981; font-weight: 600;">
                                        <span class="dashicons dashicons-yes-alt"></span> <?php echo esc_html(sprintf(__('Đã kết nối với: %s', 'wp-blogger-manager'), $auth_data['user_email'])); ?>
                                    </span>
                                </div>
                                <button type="button" id="wp-blogger-disconnect-btn" class="wp-blogger-btn wp-blogger-btn-danger">
                                    <span class="dashicons dashicons-dismiss"></span> <?php esc_html_e('Ngắt kết nối tài khoản', 'wp-blogger-manager'); ?>
                                </button>
                            <?php else : ?>
                                <?php if (!empty($auth_url)) : ?>
                                    <a href="<?php echo esc_url($auth_url); ?>" class="wp-blogger-btn wp-blogger-btn-google">
                                        <span class="dashicons dashicons-google" style="color: #ea4335;"></span> <?php esc_html_e('Đăng nhập & Cấp quyền Google Blogger', 'wp-blogger-manager'); ?>
                                    </a>
                                <?php else : ?>
                                    <span style="font-size: 13px; color: #64748b;">
                                        <em><?php esc_html_e('Nhập Client ID & Secret rồi nhấn "Lưu cài đặt" để hiện nút Đăng nhập Google.', 'wp-blogger-manager'); ?></em>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>

                <!-- 2. Image & CDN Processing Card -->
                <div class="wp-blogger-card" id="media-cdn">
                    <div class="wp-blogger-card-header">
                        <h2><span class="dashicons dashicons-format-image"></span> <?php esc_html_e('2. Xử lý Hình ảnh & Kho lưu trữ CDN', 'wp-blogger-manager'); ?></h2>
                    </div>
                    <div class="wp-blogger-card-body">

                        <!-- CDN Base URL -->
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label" for="cdn_url"><?php esc_html_e('Custom CDN Domain / Base URL (Tùy chọn):', 'wp-blogger-manager'); ?></label>
                            <input type="url" name="cdn_url" id="cdn_url" class="wp-blogger-input" value="<?php echo esc_attr(!empty($settings['cdn_url']) ? $settings['cdn_url'] : ''); ?>" placeholder="https://cdn.yourdomain.com hoặc https://your-r2.b-cdn.net">
                            <p class="wp-blogger-desc">
                                <?php esc_html_e('Nếu bạn dùng BunnyCDN, Cloudflare R2, AWS CloudFront hoặc Jetpack Photon để phân phối ảnh WordPress, hãy nhập domain CDN tại đây. Toàn bộ link ảnh trong bài viết khi gửi sang Blogger sẽ tự động được viết lại dưới domain CDN này.', 'wp-blogger-manager'); ?>
                            </p>
                        </div>

                        <!-- Sideload External Images -->
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label">
                                <input type="checkbox" name="sideload_external_img" value="1" <?php checked(!empty($settings['sideload_external_img'])); ?>>
                                <strong><?php esc_html_e('Tự động tải hình ảnh ngoại vi (External Images) về kho WP Media', 'wp-blogger-manager'); ?></strong>
                            </label>
                            <p class="wp-blogger-desc">
                                <?php esc_html_e('Khi bạn copy bài viết có chứa hình ảnh từ website khác (hotlinks), plugin sẽ tự động tải các ảnh đó về thư viện Media của WordPress và thay thế link sang CDN/WP của bạn trước khi đăng lên Blogger để tránh bị chết ảnh.', 'wp-blogger-manager'); ?>
                            </p>
                        </div>

                        <!-- Auto Featured Image -->
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label">
                                <input type="checkbox" name="auto_featured_image" value="1" <?php checked(!empty($settings['auto_featured_image'])); ?>>
                                <strong><?php esc_html_e('Tự động chèn ảnh đại diện (Featured Image) vào bài viết trên Blogger', 'wp-blogger-manager'); ?></strong>
                            </label>
                            <p class="wp-blogger-desc">
                                <?php esc_html_e('Giúp Blogger tự động nhận diện ảnh đầu bài làm thumbnail và thẻ chia sẻ Open Graph / Rich Snippet.', 'wp-blogger-manager'); ?>
                            </p>
                        </div>

                        <!-- Featured Image Position -->
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label" for="featured_img_position"><?php esc_html_e('Vị trí chèn ảnh đại diện:', 'wp-blogger-manager'); ?></label>
                            <select name="featured_img_position" id="featured_img_position" class="wp-blogger-input" style="max-width: 260px;">
                                <option value="top" <?php selected(!empty($settings['featured_img_position']) ? $settings['featured_img_position'] : 'top', 'top'); ?>><?php esc_html_e('Đầu bài viết (Top - Khuyến nghị)', 'wp-blogger-manager'); ?></option>
                                <option value="bottom" <?php selected(!empty($settings['featured_img_position']) ? $settings['featured_img_position'] : '', 'bottom'); ?>><?php esc_html_e('Cuối bài viết (Bottom)', 'wp-blogger-manager'); ?></option>
                            </select>
                        </div>

                        <!-- Default Featured Image (fallback when post has no thumbnail) -->
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label" for="default_featured_image_url"><?php esc_html_e('URL ảnh đại diện mặc định (Fallback):', 'wp-blogger-manager'); ?></label>
                            <input type="url" name="default_featured_image_url" id="default_featured_image_url" class="wp-blogger-input" value="<?php echo esc_attr(!empty($settings['default_featured_image_url']) ? $settings['default_featured_image_url'] : ''); ?>" placeholder="https://yourdomain.com/wp-content/uploads/default-thumbnail.jpg">
                            <p class="wp-blogger-desc">
                                <?php esc_html_e('Khi bài viết không có ảnh đại diện (Featured Image), plugin sẽ tự động chèn ảnh mặc định này vào đầu bài trên Blogger để đảm bảo luôn có thumbnail. Chỉ áp dụng khi đã bật "Tự động chèn ảnh đại diện" ở trên.', 'wp-blogger-manager'); ?>
                            </p>
                            <?php if (!empty($settings['default_featured_image_url'])) : ?>
                                <div style="margin-top: 8px;">
                                    <img src="<?php echo esc_url($settings['default_featured_image_url']); ?>" alt="Default thumbnail preview" style="max-height: 80px; max-width: 200px; border-radius: 6px; border: 1px solid #e2e8f0; object-fit: cover;">
                                    <small style="display: block; color: #64748b; margin-top: 4px;"><?php esc_html_e('Ảnh mặc định hiện tại', 'wp-blogger-manager'); ?></small>
                                </div>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>

                <!-- 3. Sync Rules & Behavior -->
                <div class="wp-blogger-card">
                    <div class="wp-blogger-card-header">
                        <h2><span class="dashicons dashicons-controls-repeat"></span> <?php esc_html_e('3. Tự động hóa Đồng bộ (Automation Rules)', 'wp-blogger-manager'); ?></h2>
                    </div>
                    <div class="wp-blogger-card-body">

                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label">
                                <input type="checkbox" name="auto_sync_on_publish" value="1" <?php checked(!empty($settings['auto_sync_on_publish'])); ?>>
                                <strong><?php esc_html_e('Tự động đẩy bài viết lên Blogger khi bấm Xuất bản (Publish)', 'wp-blogger-manager'); ?></strong>
                            </label>
                        </div>

                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label">
                                <input type="checkbox" name="auto_sync_on_update" value="1" <?php checked(!empty($settings['auto_sync_on_update'])); ?>>
                                <strong><?php esc_html_e('Tự động cập nhật bài trên Blogger khi Chỉnh sửa (Update) bài viết', 'wp-blogger-manager'); ?></strong>
                            </label>
                        </div>

                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label">
                                <input type="checkbox" name="auto_delete_on_trash" value="1" <?php checked(!empty($settings['auto_delete_on_trash'])); ?>>
                                <strong><?php esc_html_e('Tự động xoà bài trên Blogger khi bỏ bài viết vào Thùng rác (Trash)', 'wp-blogger-manager'); ?></strong>
                            </label>
                        </div>

                    </div>
                </div>

                <!-- Migration Tool -->
                <div class="wp-blogger-card" style="margin-top:20px; border-left:4px solid #8b5cf6;">
                    <div class="wp-blogger-card-header">
                        <h2><span class="dashicons dashicons-migrate"></span> <?php esc_html_e('Migration Tool: Chuyển blogger_post → WP Post', 'wp-blogger-manager'); ?></h2>
                    </div>
                    <div class="wp-blogger-card-body">
                        <p style="font-size:13px; color:#475569; line-height:1.6; margin-bottom:14px;">
                            <?php esc_html_e('Nếu trước đây bạn đã sử dụng phân loại "Blogger Posts" (CPT riêng biệt), công cụ này sẽ tự động chuyển toàn bộ bài đó sang loại bài viết WP thông thường. Dữ liệu đồng bộ Blogger (blog đã đăng, trạng thái, URL) được giữ nguyên 100%.', 'wp-blogger-manager'); ?>
                        </p>
                        <div style="background:#fef3c7; border:1px solid #f59e0b; border-radius:6px; padding:10px 14px; margin-bottom:14px; font-size:12px; color:#92400e;">
                            <strong><?php esc_html_e('Lưu ý:', 'wp-blogger-manager'); ?></strong>
                            <?php esc_html_e('Các bài blogger_post sẽ được chuyển sang WP Post và bị đưa vào Thùng rác (không xóa vĩnh viễn). Bạn có thể kiểm tra kết quả trước khi xóa hẳn.', 'wp-blogger-manager'); ?>
                        </div>
                        <button type="button" id="wp-blogger-migrate-btn" class="wp-blogger-btn" style="background:#7c3aed;color:#fff;border-color:#7c3aed;">
                            <span class="dashicons dashicons-migrate"></span>
                            <?php esc_html_e('Chạy Migration: Chuyển blogger_post → WP Post', 'wp-blogger-manager'); ?>
                        </button>
                        <div id="wp-blogger-migrate-result" style="margin-top:12px;"></div>
                    </div>
                </div>

                <div style="margin-top: 20px;">


                <!-- 4. Queue & Retry Settings -->
                <div class="wp-blogger-card" style="margin-bottom:20px;">
                    <div class="wp-blogger-card-header">
                        <h2><span class="dashicons dashicons-clock"></span> <?php esc_html_e('4. Queue Nền & Retry Tự Động', 'wp-blogger-manager'); ?></h2>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-queue')); ?>" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm">
                            <span class="dashicons dashicons-list-view"></span> <?php esc_html_e('Xem Queue Monitor', 'wp-blogger-manager'); ?>
                        </a>
                    </div>
                    <div class="wp-blogger-card-body">
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label">
                                <input type="checkbox" name="queue_mode" value="1" <?php checked(!empty($settings['queue_mode'])); ?>>
                                <strong><?php esc_html_e('Bật Queue Mode (Đồng bộ nền qua WP Cron)', 'wp-blogger-manager'); ?></strong>
                            </label>
                            <p class="wp-blogger-desc"><?php esc_html_e('Khi bật: bài viết được thêm vào hàng đợi thay vì chạy đồng bộ trực tiếp. WP Cron sẽ xử lý 5 bài/phút. Khuyến nghị bật khi có nhiều blog hoặc thường bulk sync.', 'wp-blogger-manager'); ?></p>
                        </div>
                        <div class="wp-blogger-form-row">
                            <label class="wp-blogger-label" for="max_retries"><?php esc_html_e('Số lần thử lại tối đa khi lỗi:', 'wp-blogger-manager'); ?></label>
                            <div style="display:flex; align-items:center; gap:12px;">
                                <select name="max_retries" id="max_retries" class="wp-blogger-input" style="max-width:120px;">
                                    <?php for ($i = 1; $i <= 5; $i++) : ?>
                                        <option value="<?php echo $i; ?>" <?php selected(isset($settings['max_retries']) ? intval($settings['max_retries']) : 3, $i); ?>>
                                            <?php echo $i; ?> <?php esc_html_e('lần', 'wp-blogger-manager'); ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                                <span style="font-size:12px; color:#64748b;"><?php esc_html_e('Backoff: 5 phút → 15 phút → 60 phút', 'wp-blogger-manager'); ?></span>
                            </div>
                            <p class="wp-blogger-desc"><?php esc_html_e('Khi API lỗi tạm thời, hệ thống tự retry với khoảng chờ tăng dần.', 'wp-blogger-manager'); ?></p>
                        </div>
                    </div>
                </div>

                    <button type="submit" class="wp-blogger-btn wp-blogger-btn-primary" style="padding: 12px 28px; font-size: 15px;">
                        <span class="dashicons dashicons-saved"></span> <?php esc_html_e('Lưu tất cả Cài đặt', 'wp-blogger-manager'); ?>
                    </button>
                </div>


            </div>

            <!-- Right Sidebar: Guide & Instructions -->
            <div>
                <div class="wp-blogger-card">
                    <div class="wp-blogger-card-header">
                        <h2><span class="dashicons dashicons-info"></span> <?php esc_html_e('Hướng dẫn tạo Google API', 'wp-blogger-manager'); ?></h2>
                    </div>
                    <div class="wp-blogger-card-body" style="font-size: 13px; line-height: 1.6;">
                        <ol style="margin-left: 18px; padding-left: 0;">
                            <li>Truy cập <a href="https://console.cloud.google.com/" target="_blank">Google Cloud Console</a> và tạo một Project mới.</li>
                            <li>Vào menu <strong>APIs & Services > Library</strong>, tìm kiếm <strong>Blogger API v3</strong> và nhấn <strong>Enable</strong>.</li>
                            <li>Vào <strong>OAuth consent screen</strong>, chọn <strong>External</strong>, điền tên ứng dụng và email của bạn.</li>
                            <li>Vào mục <strong>Credentials > Create Credentials > OAuth client ID</strong>:
                                <ul>
                                    <li>Application type: <strong>Web application</strong></li>
                                    <li>Authorized redirect URIs: <strong>Dán URL sao chép ở ô bên trái vào</strong></li>
                                </ul>
                            </li>
                            <li>Copy <strong>Client ID</strong> và <strong>Client Secret</strong> dán vào cài đặt plugin và bấm <strong>Lưu cài đặt</strong>.</li>
                            <li>Nhấn nút <strong>Đăng nhập & Cấp quyền Google Blogger</strong> để hoàn tất!</li>
                        </ol>
                    </div>
                </div>

                <!-- Quota & API Limit Info Card -->
                <div class="wp-blogger-card" style="margin-top: 20px;">
                    <div class="wp-blogger-card-header">
                        <h2><span class="dashicons dashicons-chart-bar"></span> <?php esc_html_e('Giới hạn API & Cách tính Query', 'wp-blogger-manager'); ?></h2>
                    </div>
                    <div class="wp-blogger-card-body" style="font-size: 13px; line-height: 1.7;">

                        <!-- Quota per Project -->
                        <div style="background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 12px 14px; margin-bottom: 14px;">
                            <strong style="color: #92400e; display: flex; align-items: center; gap: 6px; margin-bottom: 6px;">
                                <span class="dashicons dashicons-warning" style="color:#f59e0b;"></span>
                                <?php esc_html_e('Quota tính theo Google Cloud Project', 'wp-blogger-manager'); ?>
                            </strong>
                            <p style="margin: 0; color: #78350f; font-size: 12px;">
                                <?php esc_html_e('Quota KHÔNG tính riêng theo từng tài khoản Google hay từng blog. Tất cả tài khoản Google bạn kết nối đều cộng dồn chung quota của 1 Cloud Project.', 'wp-blogger-manager'); ?>
                            </p>
                        </div>

                        <!-- Quota Table -->
                        <table style="width:100%; border-collapse: collapse; font-size: 12px; margin-bottom: 14px;">
                            <thead>
                                <tr style="background: var(--wp-blogger-bg-alt, #f8fafc);">
                                    <th style="text-align:left; padding: 7px 10px; border: 1px solid var(--wp-blogger-border, #e2e8f0); color: #475569;"><?php esc_html_e('Loại giới hạn', 'wp-blogger-manager'); ?></th>
                                    <th style="text-align:center; padding: 7px 10px; border: 1px solid var(--wp-blogger-border, #e2e8f0); color: #475569;"><?php esc_html_e('Mức mặc định', 'wp-blogger-manager'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style="padding: 6px 10px; border: 1px solid var(--wp-blogger-border, #e2e8f0);">📅 <?php esc_html_e('Requests / ngày', 'wp-blogger-manager'); ?></td>
                                    <td style="padding: 6px 10px; border: 1px solid var(--wp-blogger-border, #e2e8f0); text-align:center; font-weight:700; color:#2563eb;">10,000</td>
                                </tr>
                                <tr style="background: var(--wp-blogger-bg-alt, #f8fafc);">
                                    <td style="padding: 6px 10px; border: 1px solid var(--wp-blogger-border, #e2e8f0);">⚡ <?php esc_html_e('Requests / 100 giây', 'wp-blogger-manager'); ?></td>
                                    <td style="padding: 6px 10px; border: 1px solid var(--wp-blogger-border, #e2e8f0); text-align:center; font-weight:700; color:#2563eb;">100</td>
                                </tr>
                                <tr>
                                    <td style="padding: 6px 10px; border: 1px solid var(--wp-blogger-border, #e2e8f0);">🏗️ <?php esc_html_e('Phạm vi tính quota', 'wp-blogger-manager'); ?></td>
                                    <td style="padding: 6px 10px; border: 1px solid var(--wp-blogger-border, #e2e8f0); text-align:center; font-weight:600; color:#059669;"><?php esc_html_e('Per Cloud Project', 'wp-blogger-manager'); ?></td>
                                </tr>
                            </tbody>
                        </table>

                        <!-- Query Cost Calculator -->
                        <strong style="display:block; margin-bottom: 8px; color: var(--wp-blogger-text, #1e293b);">
                            🧮 <?php esc_html_e('Cách tính API call tiêu tốn:', 'wp-blogger-manager'); ?>
                        </strong>
                        <table style="width:100%; border-collapse: collapse; font-size: 12px; margin-bottom: 14px;">
                            <thead>
                                <tr style="background: var(--wp-blogger-bg-alt, #f8fafc);">
                                    <th style="text-align:left; padding: 6px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0); color: #475569;"><?php esc_html_e('Thao tác', 'wp-blogger-manager'); ?></th>
                                    <th style="text-align:center; padding: 6px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0); color: #475569;"><?php esc_html_e('API calls', 'wp-blogger-manager'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0);"><?php esc_html_e('Fetch danh sách blogs', 'wp-blogger-manager'); ?></td>
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0); text-align:center; font-weight:600;">1 × tài khoản</td>
                                </tr>
                                <tr style="background: var(--wp-blogger-bg-alt, #f8fafc);">
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0);"><?php esc_html_e('Sync 1 bài → N blogs', 'wp-blogger-manager'); ?></td>
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0); text-align:center; font-weight:600; color:#dc2626;">N calls</td>
                                </tr>
                                <tr>
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0);"><?php esc_html_e('Bulk sync M bài → N blogs', 'wp-blogger-manager'); ?></td>
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0); text-align:center; font-weight:600; color:#dc2626;">M × N calls</td>
                                </tr>
                                <tr style="background: var(--wp-blogger-bg-alt, #f8fafc);">
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0);"><?php esc_html_e('Pull/Import bài từ 1 blog', 'wp-blogger-manager'); ?></td>
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0); text-align:center; font-weight:600;">1+ calls</td>
                                </tr>
                                <tr>
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0);"><?php esc_html_e('Xoá bài khỏi N blogs', 'wp-blogger-manager'); ?></td>
                                    <td style="padding: 5px 8px; border: 1px solid var(--wp-blogger-border, #e2e8f0); text-align:center; font-weight:600; color:#dc2626;">N calls</td>
                                </tr>
                            </tbody>
                        </table>

                        <!-- Example -->
                        <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 10px 12px; margin-bottom: 12px; font-size: 12px;">
                            <strong style="color:#1d4ed8;">💡 <?php esc_html_e('Ví dụ thực tế:', 'wp-blogger-manager'); ?></strong><br>
                            <span style="color:#1e40af;">
                                <?php esc_html_e('Bulk sync 50 bài → 10 blogs = 500 API calls (5% quota/ngày). Queue Mode giúp trải đều các call, tránh vượt giới hạn 100 req/100s.', 'wp-blogger-manager'); ?>
                            </span>
                        </div>

                        <!-- Link to Cloud Console -->
                        <a href="https://console.cloud.google.com/apis/api/blogger.googleapis.com/quotas" target="_blank" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm" style="display:inline-flex; align-items:center; gap:6px; font-size:12px; text-decoration:none;">
                            <span class="dashicons dashicons-external" style="font-size:14px; width:14px; height:14px;"></span>
                            <?php esc_html_e('Xem & Tăng Quota trên Google Cloud', 'wp-blogger-manager'); ?>
                        </a>

                    </div>
                </div>
            </div>

        </div>

    </form>

</div>

<script>
(function($) {
    'use strict';

    // Migration Tool: blogger_post → WP Post
    $('#wp-blogger-migrate-btn').on('click', function() {
        if (!confirm('Bạn có chắc chắn muốn chuyển toàn bộ bài Blogger Posts sang WP Posts không? Các bài gốc sẽ bị đưa vào Thùng rác.')) {
            return;
        }
        var $btn = $(this).prop('disabled', true);
        var $result = $('#wp-blogger-migrate-result');
        $result.html('<div class="wp-blogger-alert" style="background:#eff6ff;border-left:4px solid #3b82f6;"><span class="dashicons dashicons-update wp-blogger-spin"></span> Đang chạy migration...</div>');

        $.post(wpBloggerData.ajaxUrl, {
            action: 'wp_blogger_migrate_posts',
            nonce:  wpBloggerData.nonce,
        }, function(res) {
            if (res.success) {
                var html = '<div class="wp-blogger-alert success"><span class="dashicons dashicons-yes-alt"></span> <strong>Hoàn tất!</strong> ' + res.data.message + '</div>';
                if (res.data.migrated > 0) {
                    html += '<div style="margin-top:8px;"><a href="' + wpBloggerData.ajaxUrl.replace('admin-ajax.php', 'edit.php') + '" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm">Xem tất cả bài viết &rarr;</a></div>';
                }
                $result.html(html);
            } else {
                $result.html('<div class="wp-blogger-alert error"><span class="dashicons dashicons-warning"></span> ' + res.data.message + '</div>');
            }
        }).fail(function() {
            $result.html('<div class="wp-blogger-alert error">Lỗi kết nối. Vui lòng thử lại.</div>');
        }).always(function() {
            $btn.prop('disabled', false);
        });
    });

})(jQuery);
</script>
