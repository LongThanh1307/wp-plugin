<?php
/**
 * IW_Processor – Xử lý đóng watermark lên ảnh dùng GD Library.
 *
 * @package Images_Watermark
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IW_Processor {

    /** @var IW_Settings */
    private IW_Settings $settings;

    /** Các mime type được hỗ trợ */
    const SUPPORTED_MIMES = [
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/webp',
    ];

    // ------------------------------------------------------------------ //

    public function __construct( IW_Settings $settings ) {
        $this->settings = $settings;
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Public API
    // ─────────────────────────────────────────────────────────────────── //

    /**
     * Xử lý watermark cho toàn bộ ảnh trong một bài viết.
     */
    public function process_post( int $post_id ): void {
        if ( ! $this->settings->get( 'enabled' ) ) {
            return;
        }

        $processed = 0;

        // 1. Ảnh đại diện (featured image)
        if ( $this->settings->get( 'apply_to_featured' ) ) {
            $thumb_id = (int) get_post_thumbnail_id( $post_id );
            if ( $thumb_id > 0 ) {
                $processed += (int) $this->process_attachment( $thumb_id );
            }
        }

        // 2. Tất cả ảnh đính kèm bài viết
        if ( $this->settings->get( 'apply_to_content' ) ) {
            $attachments = get_attached_media( 'image', $post_id );
            foreach ( $attachments as $attachment ) {
                if ( (int) get_post_thumbnail_id( $post_id ) === $attachment->ID ) {
                    continue; // đã xử lý ở trên
                }
                $processed += (int) $this->process_attachment( $attachment->ID );
            }
        }

        if ( $processed > 0 ) {
            update_post_meta( $post_id, '_iw_watermarked', current_time( 'mysql' ) );
            update_post_meta( $post_id, '_iw_watermarked_count', $processed );
        }
    }

    /**
     * Áp dụng watermark lên một attachment.
     *
     * @return bool True nếu thành công.
     */
    public function process_attachment( int $attachment_id ): bool {
        // Bỏ qua nếu đã watermark
        if ( get_post_meta( $attachment_id, '_iw_watermarked', true ) ) {
            return false;
        }

        $file_path = get_attached_file( $attachment_id );
        if ( ! $file_path || ! file_exists( $file_path ) ) {
            return false;
        }

        $mime = get_post_mime_type( $attachment_id );
        if ( ! in_array( $mime, self::SUPPORTED_MIMES, true ) ) {
            return false;
        }

        $result = $this->apply_watermark_to_file( $file_path );
        if ( $result ) {
            update_post_meta( $attachment_id, '_iw_watermarked', current_time( 'mysql' ) );
        }
        return $result;
    }

    /**
     * Áp dụng watermark trực tiếp vào một file ảnh trên đĩa.
     */
    public function apply_watermark_to_file( string $file_path ): bool {
        if ( ! file_exists( $file_path ) || ! is_writable( $file_path ) ) {
            return false;
        }

        // Kiểm tra kích thước tối thiểu
        $size = @getimagesize( $file_path );
        if ( ! $size ) {
            return false;
        }

        $min_w = (int) $this->settings->get( 'min_width', 200 );
        $min_h = (int) $this->settings->get( 'min_height', 200 );

        if ( $size[0] < $min_w || $size[1] < $min_h ) {
            return false;
        }

        // Backup ảnh gốc nếu được bật
        if ( $this->settings->get( 'backup_original' ) ) {
            $this->backup_file( $file_path );
        }

        // Tải ảnh lên GD
        $image = $this->load_image( $file_path, $size['mime'] );
        if ( ! $image ) {
            return false;
        }

        // Áp dụng watermark theo loại
        $type = $this->settings->get( 'watermark_type', 'text' );

        $success = match ( $type ) {
            'image' => $this->apply_image_watermark( $image, $size ),
            default => $this->apply_text_watermark( $image, $size ),
        };

        if ( ! $success ) {
            imagedestroy( $image );
            return false;
        }

        // Lưu lại
        $result = $this->save_image( $image, $file_path, $size['mime'] );
        imagedestroy( $image );

        // Xoá cache thumbnail của WordPress
        if ( $result ) {
            $meta = wp_get_attachment_metadata( $this->get_attachment_id_by_path( $file_path ) );
            if ( $meta ) {
                wp_update_attachment_metadata( $this->get_attachment_id_by_path( $file_path ), $meta );
            }
        }

        return $result;
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Text watermark
    // ─────────────────────────────────────────────────────────────────── //

    private function apply_text_watermark( \GdImage $image, array $size ): bool {
        $text       = $this->settings->get( 'text', '© Copyright' );
        $font_size  = (int) $this->settings->get( 'font_size', 24 );
        $color_hex  = $this->settings->get( 'font_color', '#ffffff' );
        $opacity    = (int) $this->settings->get( 'opacity', 80 );
        $angle      = (int) $this->settings->get( 'text_angle', 0 );
        $font_name  = $this->settings->get( 'font_family', 'OpenSans' );

        // Tìm file font TTF
        $font_path = $this->get_font_path( $font_name );

        // Chuyển hex → RGB
        [ $r, $g, $b ] = $this->hex_to_rgb( $color_hex );

        // GD alpha: 0=không trong suốt, 127=hoàn toàn trong suốt
        $gd_alpha = (int) round( ( 100 - $opacity ) * 127 / 100 );

        if ( $font_path && function_exists( 'imagettftext' ) ) {
            return $this->draw_text_ttf( $image, $size, $text, $font_path, $font_size, $r, $g, $b, $gd_alpha, $angle );
        } else {
            return $this->draw_text_builtin( $image, $size, $text, $r, $g, $b, $gd_alpha );
        }
    }

    private function draw_text_ttf( \GdImage $image, array $size, string $text, string $font_path, int $font_size, int $r, int $g, int $b, int $alpha, int $angle ): bool {
        $color = imagecolorallocatealpha( $image, $r, $g, $b, $alpha );
        if ( false === $color ) {
            return false;
        }

        // Tính toán bounding box của text
        $bbox = imagettfbbox( $font_size, $angle, $font_path, $text );
        if ( ! $bbox ) {
            return false;
        }

        $text_w = abs( $bbox[4] - $bbox[0] );
        $text_h = abs( $bbox[5] - $bbox[1] );

        [ $x, $y ] = $this->calculate_position( $size[0], $size[1], $text_w, $text_h );

        // Điều chỉnh cho TTF (baseline ở dưới)
        $y += $text_h;

        imagettftext( $image, $font_size, $angle, $x, $y, $color, $font_path, $text );
        return true;
    }

    private function draw_text_builtin( \GdImage $image, array $size, string $text, int $r, int $g, int $b, int $alpha ): bool {
        $font      = 5; // built-in GD font (1-5)
        $char_w    = imagefontwidth( $font );
        $char_h    = imagefontheight( $font );
        $text_w    = strlen( $text ) * $char_w;
        $text_h    = $char_h;

        [ $x, $y ] = $this->calculate_position( $size[0], $size[1], $text_w, $text_h );

        $color = imagecolorallocatealpha( $image, $r, $g, $b, $alpha );
        if ( false === $color ) {
            return false;
        }

        imagestring( $image, $font, $x, $y, $text, $color );
        return true;
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Image watermark
    // ─────────────────────────────────────────────────────────────────── //

    private function apply_image_watermark( \GdImage $image, array $size ): bool {
        $image_id = (int) $this->settings->get( 'image_id', 0 );
        if ( ! $image_id ) {
            // fallback sang text nếu không có logo
            return $this->apply_text_watermark( $image, $size );
        }

        $wm_path = get_attached_file( $image_id );
        if ( ! $wm_path || ! file_exists( $wm_path ) ) {
            return $this->apply_text_watermark( $image, $size );
        }

        $wm_size = @getimagesize( $wm_path );
        if ( ! $wm_size ) {
            return false;
        }

        $wm = $this->load_image( $wm_path, $wm_size['mime'] );
        if ( ! $wm ) {
            return false;
        }

        // Tính kích thước watermark theo tỉ lệ % chiều rộng ảnh gốc
        $percent   = (int) $this->settings->get( 'image_width_percent', 20 );
        $wm_target_w = (int) round( $size[0] * $percent / 100 );
        $wm_ratio    = $wm_size[1] / $wm_size[0];
        $wm_target_h = (int) round( $wm_target_w * $wm_ratio );

        // Scale watermark
        $wm_resized = imagecreatetruecolor( $wm_target_w, $wm_target_h );
        imagealphablending( $wm_resized, false );
        imagesavealpha( $wm_resized, true );
        imagecopyresampled( $wm_resized, $wm, 0, 0, 0, 0, $wm_target_w, $wm_target_h, $wm_size[0], $wm_size[1] );
        imagedestroy( $wm );

        // Tính vị trí
        [ $x, $y ] = $this->calculate_position( $size[0], $size[1], $wm_target_w, $wm_target_h );

        // Áp dụng opacity
        $opacity = (int) $this->settings->get( 'opacity', 80 );
        $this->apply_opacity( $wm_resized, $opacity );

        // Merge watermark lên ảnh gốc
        imagecopy( $image, $wm_resized, $x, $y, 0, 0, $wm_target_w, $wm_target_h );
        imagedestroy( $wm_resized );

        return true;
    }

    /**
     * Áp dụng opacity cho toàn bộ ảnh GD (hoạt động với PNG có alpha).
     */
    private function apply_opacity( \GdImage &$image, int $opacity ): void {
        if ( $opacity >= 100 ) {
            return;
        }

        $w = imagesx( $image );
        $h = imagesy( $image );

        for ( $x = 0; $x < $w; $x++ ) {
            for ( $y = 0; $y < $h; $y++ ) {
                $rgba    = imagecolorat( $image, $x, $y );
                $colors  = imagecolorsforindex( $image, $rgba );
                $orig_a  = $colors['alpha']; // 0=opaque, 127=transparent
                // Tính alpha mới: hoà trộn với opacity
                $new_a   = (int) round( $orig_a + ( 127 - $orig_a ) * ( 1 - $opacity / 100 ) );
                $new_color = imagecolorallocatealpha( $image, $colors['red'], $colors['green'], $colors['blue'], $new_a );
                imagesetpixel( $image, $x, $y, $new_color );
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────── //
    // Helpers
    // ─────────────────────────────────────────────────────────────────── //

    /**
     * Tính toán toạ độ (x, y) dựa trên vị trí được chọn.
     *
     * @return array{int, int}
     */
    private function calculate_position( int $img_w, int $img_h, int $wm_w, int $wm_h ): array {
        $position = $this->settings->get( 'position', 'bottom-right' );
        $offset_x = (int) $this->settings->get( 'offset_x', 10 );
        $offset_y = (int) $this->settings->get( 'offset_y', 10 );

        $x = match ( true ) {
            str_contains( $position, 'left'   ) => $offset_x,
            str_contains( $position, 'right'  ) => $img_w - $wm_w - $offset_x,
            default                             => (int) round( ( $img_w - $wm_w ) / 2 ),
        };

        $y = match ( true ) {
            str_contains( $position, 'top'    ) => $offset_y,
            str_contains( $position, 'bottom' ) => $img_h - $wm_h - $offset_y,
            default                             => (int) round( ( $img_h - $wm_h ) / 2 ),
        };

        return [ max( 0, $x ), max( 0, $y ) ];
    }

    /** Load ảnh thành GD resource */
    private function load_image( string $path, string $mime ): \GdImage|false {
        $img = match ( $mime ) {
            'image/jpeg', 'image/jpg' => imagecreatefromjpeg( $path ),
            'image/png'               => imagecreatefrompng( $path ),
            'image/gif'               => imagecreatefromgif( $path ),
            'image/webp'              => function_exists( 'imagecreatefromwebp' ) ? imagecreatefromwebp( $path ) : false,
            default                   => false,
        };

        if ( ! $img ) {
            return false;
        }

        // Đảm bảo alpha channel được bảo tồn
        imagealphablending( $img, true );
        imagesavealpha( $img, true );

        return $img;
    }

    /** Lưu ảnh GD ra file */
    private function save_image( \GdImage $image, string $path, string $mime ): bool {
        return match ( $mime ) {
            'image/jpeg', 'image/jpg' => imagejpeg( $image, $path, 90 ),
            'image/png'               => imagepng( $image, $path, 6 ),
            'image/gif'               => imagegif( $image, $path ),
            'image/webp'              => function_exists( 'imagewebp' ) ? imagewebp( $image, $path, 85 ) : false,
            default                   => false,
        };
    }

    /** Backup ảnh gốc vào thư mục iw-originals */
    private function backup_file( string $file_path ): void {
        $upload_dir = wp_upload_dir();
        $backup_dir = $upload_dir['basedir'] . '/iw-originals';

        if ( ! is_dir( $backup_dir ) ) {
            wp_mkdir_p( $backup_dir );
        }

        $relative = str_replace( $upload_dir['basedir'] . '/', '', $file_path );
        $dest     = $backup_dir . '/' . str_replace( '/', '_', $relative );

        if ( ! file_exists( $dest ) ) {
            @copy( $file_path, $dest );
        }
    }

    /** Chuyển màu hex sang RGB */
    private function hex_to_rgb( string $hex ): array {
        $hex = ltrim( $hex, '#' );
        if ( strlen( $hex ) === 3 ) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        return [
            hexdec( substr( $hex, 0, 2 ) ),
            hexdec( substr( $hex, 2, 2 ) ),
            hexdec( substr( $hex, 4, 2 ) ),
        ];
    }

    /** Lấy đường dẫn file TTF font */
    private function get_font_path( string $font_name ): string|false {
        $font_dir   = IW_PLUGIN_DIR . 'assets/fonts/';
        $font_path  = $font_dir . $font_name . '.ttf';

        if ( file_exists( $font_path ) ) {
            return $font_path;
        }

        // Thử tìm font theo tên chữ thường
        $font_path_lower = $font_dir . strtolower( $font_name ) . '.ttf';
        if ( file_exists( $font_path_lower ) ) {
            return $font_path_lower;
        }

        return false;
    }

    /** Lấy attachment ID theo đường dẫn file */
    private function get_attachment_id_by_path( string $file_path ): int {
        global $wpdb;
        $upload_dir = wp_upload_dir();
        $relative   = str_replace( $upload_dir['basedir'] . '/', '', $file_path );

        $attachment_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value = %s LIMIT 1",
                $relative
            )
        );

        return (int) $attachment_id;
    }

    // ─────────────────────────────────────────────────────────────────── //
    // AJAX: Xử lý watermark thủ công cho ảnh đơn lẻ (dùng trong admin)
    // ─────────────────────────────────────────────────────────────────── //

    /**
     * Gỡ watermark và khôi phục ảnh gốc (nếu có backup).
     */
    public function restore_original( int $attachment_id ): bool {
        $file_path  = get_attached_file( $attachment_id );
        $upload_dir = wp_upload_dir();
        $relative   = str_replace( $upload_dir['basedir'] . '/', '', $file_path );
        $backup     = $upload_dir['basedir'] . '/iw-originals/' . str_replace( '/', '_', $relative );

        if ( ! file_exists( $backup ) ) {
            return false;
        }

        if ( @copy( $backup, $file_path ) ) {
            delete_post_meta( $attachment_id, '_iw_watermarked' );
            return true;
        }

        return false;
    }
}
