
<?php
/**
 * Admin Queue Monitor Template — Background Sync Queue
 */

if (!defined('ABSPATH')) {
    exit;
}

$status_labels = array(
    'pending'    => array('label' => __('Chờ xử lý', 'wp-blogger-manager'),  'class' => 'warning'),
    'processing' => array('label' => __('Đang xử lý', 'wp-blogger-manager'),  'class' => 'info'),
    'scheduled'  => array('label' => __('Đã lên lịch', 'wp-blogger-manager'), 'class' => 'muted'),
    'done'       => array('label' => __('Hoàn tất', 'wp-blogger-manager'),    'class' => 'success'),
    'failed'     => array('label' => __('Thất bại', 'wp-blogger-manager'),    'class' => 'danger'),
    'cancelled'  => array('label' => __('Đã hủy', 'wp-blogger-manager'),      'class' => 'muted'),
);
?>

<div class="wrap wp-blogger-wrap">

    <div class="wp-blogger-header">
        <div class="wp-blogger-title-group">
            <h1><span class="dashicons dashicons-clock"></span> <?php esc_html_e('Hàng đợi Đồng bộ nền', 'wp-blogger-manager'); ?></h1>
            <p><?php esc_html_e('Theo dõi tác vụ đồng bộ WP Cron. Queue xử lý 5 jobs/phút với retry tự động khi thất bại.', 'wp-blogger-manager'); ?></p>
        </div>
        <div class="wp-blogger-header-actions">
            <button type="button" id="wp-blogger-process-now-btn" class="wp-blogger-btn wp-blogger-btn-primary">
                <span class="dashicons dashicons-controls-play"></span> <?php esc_html_e('Chạy Queue ngay', 'wp-blogger-manager'); ?>
            </button>
            <button type="button" id="wp-blogger-clear-done-btn" class="wp-blogger-btn wp-blogger-btn-secondary">
                <span class="dashicons dashicons-trash"></span> <?php esc_html_e('Xóa jobs Hoàn tất', 'wp-blogger-manager'); ?>
            </button>
        </div>
    </div>

    <?php if (empty($settings['queue_mode'])) : ?>
    <div class="wp-blogger-alert" style="background:#fff7ed;border-left:4px solid #f59e0b;color:#92400e;padding:14px 18px;border-radius:8px;margin-bottom:20px;display:flex;align-items:center;gap:12px;">
        <span class="dashicons dashicons-warning" style="font-size:20px;flex-shrink:0;"></span>
        <div>
            <strong><?php esc_html_e('Queue Mode đang TẮT', 'wp-blogger-manager'); ?></strong><br>
            <?php esc_html_e('Đồng bộ vẫn chạy trực tiếp, có thể timeout. Bật Queue Mode trong ', 'wp-blogger-manager'); ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-settings')); ?>" style="font-weight:600;"><?php esc_html_e('Cài đặt &rarr; Queue & Retry', 'wp-blogger-manager'); ?></a>
        </div>
    </div>
    <?php endif; ?>

    <div id="wp-blogger-queue-result" style="margin-bottom:14px;"></div>

    <!-- Stats Cards -->
    <div class="wp-blogger-grid-4" style="margin-bottom:20px;">
        <?php
        $stat_defs = array(
            'pending'    => array('icon' => 'dashicons-clock',    'color' => '#f59e0b', 'bg' => '#fff7ed', 'label' => __('Chờ xử lý', 'wp-blogger-manager')),
            'processing' => array('icon' => 'dashicons-update',   'color' => '#3b82f6', 'bg' => '#eff6ff', 'label' => __('Đang xử lý', 'wp-blogger-manager')),
            'scheduled'  => array('icon' => 'dashicons-calendar', 'color' => '#8b5cf6', 'bg' => '#f5f3ff', 'label' => __('Đã lên lịch', 'wp-blogger-manager')),
            'failed'     => array('icon' => 'dashicons-warning',  'color' => '#dc2626', 'bg' => '#fef2f2', 'label' => __('Thất bại', 'wp-blogger-manager')),
        );
        foreach ($stat_defs as $key => $s) :
            $count = isset($queue_counts[$key]) ? $queue_counts[$key] : 0;
        ?>
        <div class="wp-blogger-stat-card">
            <div class="wp-blogger-stat-icon" style="background:<?php echo esc_attr($s['bg']); ?>;color:<?php echo esc_attr($s['color']); ?>;">
                <span class="dashicons <?php echo esc_attr($s['icon']); ?>"></span>
            </div>
            <div class="wp-blogger-stat-info">
                <h3 id="wp-blogger-stat-<?php echo esc_attr($key); ?>"><?php echo intval($count); ?></h3>
                <span><?php echo esc_html($s['label']); ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Filter Bar -->
    <div class="wp-blogger-card" style="margin-bottom:16px;">
        <div class="wp-blogger-card-body" style="padding:14px 18px;">
            <form method="get" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                <input type="hidden" name="page" value="wp-blogger-queue">
                <label style="font-weight:600;font-size:13px;"><?php esc_html_e('Lọc:', 'wp-blogger-manager'); ?></label>
                <select name="queue_status" class="wp-blogger-input" style="max-width:180px;padding:6px 10px;" onchange="this.form.submit()">
                    <option value=""><?php esc_html_e('Tất cả', 'wp-blogger-manager'); ?></option>
                    <?php foreach ($status_labels as $val => $info) : ?>
                        <option value="<?php echo esc_attr($val); ?>" <?php selected($filter_status, $val); ?>>
                            <?php echo esc_html($info['label']); ?> (<?php echo intval(isset($queue_counts[$val]) ? $queue_counts[$val] : 0); ?>)
                        </option>
                    <?php endforeach; ?>

                </select>
                <button type="submit" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm"><span class="dashicons dashicons-search"></span></button>
                <span style="margin-left:auto;font-size:12px;color:#64748b;"><?php esc_html_e('Tự làm mới mỗi 30 giây', 'wp-blogger-manager'); ?></span>
            </form>
        </div>
    </div>

    <!-- Queue Items Table -->
    <div class="wp-blogger-card">
        <div class="wp-blogger-card-body" style="padding:0;">
            <table class="wp-blogger-table">
                <thead>
                    <tr>
                        <th style="width:50px;">#</th>
                        <th><?php esc_html_e('Bài viết', 'wp-blogger-manager'); ?></th>
                        <th><?php esc_html_e('Hành động', 'wp-blogger-manager'); ?></th>
                        <th><?php esc_html_e('Trạng thái', 'wp-blogger-manager'); ?></th>
                        <th><?php esc_html_e('Retry', 'wp-blogger-manager'); ?></th>
                        <th><?php esc_html_e('Lên lịch', 'wp-blogger-manager'); ?></th>
                        <th><?php esc_html_e('Lỗi cuối', 'wp-blogger-manager'); ?></th>
                        <th><?php esc_html_e('Thao tác', 'wp-blogger-manager'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($queue_items)) : ?>
                        <?php foreach ($queue_items as $job) : ?>
                        <?php
                            $sl         = isset($status_labels[$job->status]) ? $status_labels[$job->status] : array('label' => $job->status, 'class' => 'muted');
                            $post_title = $job->post_id > 0 ? get_the_title($job->post_id) : 'N/A';
                            $edit_link  = $job->post_id > 0 ? get_edit_post_link($job->post_id) : '';
                            $can_cancel = in_array($job->status, array('pending', 'scheduled'), true);
                        ?>
                        <tr id="wp-blogger-job-<?php echo intval($job->id); ?>">
                            <td><code style="font-size:11px;">#<?php echo intval($job->id); ?></code></td>
                            <td>
                                <?php if ($edit_link) : ?>
                                    <a href="<?php echo esc_url($edit_link); ?>" style="font-weight:600;"><?php echo esc_html(wp_trim_words($post_title, 6)); ?></a>
                                    <div style="font-size:11px;color:#64748b;">ID #<?php echo intval($job->post_id); ?></div>
                                <?php else : ?>
                                    <em style="color:#64748b;">ID #<?php echo intval($job->post_id); ?></em>
                                <?php endif; ?>
                            </td>
                            <td><code style="font-size:11px;text-transform:uppercase;"><?php echo esc_html($job->action); ?></code></td>
                            <td><span class="wp-blogger-badge <?php echo esc_attr($sl['class']); ?>"><?php echo esc_html($sl['label']); ?></span></td>
                            <td style="text-align:center;">
                                <?php if ($job->retry_count > 0) : ?>
                                    <span style="color:#dc2626;font-weight:600;"><?php echo intval($job->retry_count); ?>x</span>
                                <?php else : ?>
                                    <span style="color:#94a3b8;">—</span>
                                <?php endif; ?>
                            </td>
                            <td><small style="color:#64748b;"><?php echo !empty($job->scheduled_at) ? esc_html(date_i18n('d/m/Y H:i', strtotime($job->scheduled_at))) : '—'; ?></small></td>
                            <td style="max-width:200px;">
                                <?php if (!empty($job->last_error)) : ?>
                                    <small style="color:#ef4444;" title="<?php echo esc_attr($job->last_error); ?>"><?php echo esc_html(wp_trim_words($job->last_error, 8)); ?></small>
                                <?php else : ?>
                                    <span style="color:#94a3b8;">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($can_cancel) : ?>
                                    <button type="button" class="wp-blogger-btn wp-blogger-btn-sm wp-blogger-cancel-job-btn" data-job-id="<?php echo intval($job->id); ?>" style="background:#dc2626;color:#fff;border-color:#dc2626;">
                                        <span class="dashicons dashicons-no-alt"></span> <?php esc_html_e('Hủy', 'wp-blogger-manager'); ?>
                                    </button>
                                <?php else : ?>
                                    <span style="color:#94a3b8;font-size:12px;">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr><td colspan="8" style="padding:40px;text-align:center;color:#64748b;"><?php esc_html_e('Hàng đợi trống.', 'wp-blogger-manager'); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- WP Cron Status -->
    <div class="wp-blogger-card" style="margin-top:20px;">
        <div class="wp-blogger-card-header">
            <h2><span class="dashicons dashicons-admin-tools"></span> <?php esc_html_e('Thông tin WP Cron', 'wp-blogger-manager'); ?></h2>
        </div>
        <div class="wp-blogger-card-body">
            <?php
            $next_run    = wp_next_scheduled(WP_Blogger_Queue::CRON_PROCESS);
            $cron_off    = defined('DISABLE_WP_CRON') && DISABLE_WP_CRON;
            ?>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;">
                <div style="padding:14px;background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0;">
                    <div style="font-size:12px;font-weight:600;color:#64748b;margin-bottom:6px;"><?php esc_html_e('Lần chạy tiếp theo', 'wp-blogger-manager'); ?></div>
                    <div style="font-size:14px;font-weight:600;">
                        <?php echo $next_run
                            ? esc_html(date_i18n('d/m/Y H:i:s', $next_run))
                            : '<span style="color:#dc2626;">' . esc_html__('Chưa lên lịch', 'wp-blogger-manager') . '</span>'; ?>
                    </div>
                </div>
                <div style="padding:14px;background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0;">
                    <div style="font-size:12px;font-weight:600;color:#64748b;margin-bottom:6px;"><?php esc_html_e('WP Cron', 'wp-blogger-manager'); ?></div>
                    <?php if ($cron_off) : ?>
                        <span class="wp-blogger-badge warning">DISABLE_WP_CRON=true</span>
                    <?php else : ?>
                        <span class="wp-blogger-badge success"><?php esc_html_e('Bình thường', 'wp-blogger-manager'); ?></span>
                    <?php endif; ?>
                </div>
                <div style="padding:14px;background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0;">
                    <div style="font-size:12px;font-weight:600;color:#64748b;margin-bottom:6px;"><?php esc_html_e('Queue Mode / Max Retry', 'wp-blogger-manager'); ?></div>
                    <?php if (!empty($settings['queue_mode'])) : ?>
                        <span class="wp-blogger-badge success"><?php esc_html_e('BẬT', 'wp-blogger-manager'); ?></span>
                    <?php else : ?>
                        <span class="wp-blogger-badge muted"><?php esc_html_e('TẮT', 'wp-blogger-manager'); ?></span>
                    <?php endif; ?>
                    &nbsp;/ <?php echo esc_html(sprintf(__('%d lần', 'wp-blogger-manager'), isset($settings['max_retries']) ? $settings['max_retries'] : 3)); ?>
                </div>
            </div>
            <?php if ($cron_off) : ?>
            <div style="margin-top:14px;padding:12px 16px;background:#eff6ff;border-left:4px solid #3b82f6;border-radius:6px;font-size:13px;color:#1e40af;">
                <strong><?php esc_html_e('Server Cron:', 'wp-blogger-manager'); ?></strong>
                <code style="display:block;margin-top:6px;padding:6px 10px;background:#dbeafe;border-radius:4px;">* * * * * curl -s <?php echo esc_url(site_url('/wp-cron.php?doing_wp_cron')); ?> &gt; /dev/null 2&gt;&amp;1</code>
            </div>
            <?php endif; ?>
        </div>
    </div>

</div>

