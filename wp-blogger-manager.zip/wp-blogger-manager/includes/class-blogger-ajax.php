<?php
/**
 * Admin AJAX Handlers with Multi-Account & Multi-Blog Support
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Blogger_AJAX {

    private $api;
    private $sync;
    private $media;
    private $auth;
    private $queue;

    /**
     * Constructor
     */
    public function __construct(WP_Blogger_API $api, WP_Blogger_Sync $sync, WP_Blogger_Media $media, WP_Blogger_Auth $auth, WP_Blogger_Queue $queue) {
        $this->api   = $api;
        $this->sync  = $sync;
        $this->media = $media;
        $this->auth  = $auth;
        $this->queue = $queue;

        $this->init_hooks();
    }

    /**
     * Register AJAX hooks
     */
    private function init_hooks() {
        add_action('wp_ajax_wp_blogger_test_api', array($this, 'ajax_test_api'));
        add_action('wp_ajax_wp_blogger_fetch_blogs', array($this, 'ajax_fetch_blogs'));
        add_action('wp_ajax_wp_blogger_disconnect', array($this, 'ajax_disconnect'));
        add_action('wp_ajax_wp_blogger_disconnect_account', array($this, 'ajax_disconnect_account'));
        add_action('wp_ajax_wp_blogger_toggle_blog_active', array($this, 'ajax_toggle_blog_active'));
        add_action('wp_ajax_wp_blogger_sync_single', array($this, 'ajax_sync_single'));
        add_action('wp_ajax_wp_blogger_bulk_sync', array($this, 'ajax_bulk_sync'));
        add_action('wp_ajax_wp_blogger_pull_posts', array($this, 'ajax_pull_posts'));
        add_action('wp_ajax_wp_blogger_clear_logs', array($this, 'ajax_clear_logs'));
        add_action('wp_ajax_wp_blogger_save_blogs_config', array($this, 'ajax_save_blogs_config'));
        add_action('wp_ajax_wp_blogger_delete_from_blogger', array($this, 'ajax_delete_from_blogger'));
        // Migrate legacy blogger_post CPT entries to native WP post type
        add_action('wp_ajax_wp_blogger_migrate_posts', array($this, 'ajax_migrate_posts'));
        // Import from Blogger → staging
        add_action('wp_ajax_wp_blogger_get_labels',         array($this, 'ajax_get_blogger_labels'));
        add_action('wp_ajax_wp_blogger_fetch_from_blogger', array($this, 'ajax_fetch_from_blogger'));
        add_action('wp_ajax_wp_blogger_import_to_wp',       array($this, 'ajax_import_staging_to_wp'));
        add_action('wp_ajax_wp_blogger_delete_staging',     array($this, 'ajax_delete_staging_posts'));
        // Queue management
        add_action('wp_ajax_wp_blogger_queue_status', array($this, 'ajax_queue_status'));
        add_action('wp_ajax_wp_blogger_cancel_queue_job', array($this, 'ajax_cancel_queue_job'));
        add_action('wp_ajax_wp_blogger_process_queue_now', array($this, 'ajax_process_queue_now'));
        add_action('wp_ajax_wp_blogger_clear_done_jobs', array($this, 'ajax_clear_done_jobs'));
        // Preview & Schedule
        add_action('wp_ajax_wp_blogger_preview_on_blogger', array($this, 'ajax_preview_on_blogger'));
        add_action('wp_ajax_wp_blogger_schedule_broadcast', array($this, 'ajax_schedule_broadcast'));
        // Quota monitoring
        add_action('wp_ajax_wp_blogger_get_quota', array($this, 'ajax_get_quota'));
    }

    /**
     * Verify AJAX security nonce & capability
     */
    private function verify_request() {
        if (!check_ajax_referer('wp_blogger_admin_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Xác thực bảo mật nonce không hợp lệ.', 'wp-blogger-manager')));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Bạn không có quyền thực hiện thao tác này.', 'wp-blogger-manager')));
        }
    }

    /**
     * Test API connection
     */
    public function ajax_test_api() {
        $this->verify_request();

        if (!$this->auth->is_connected()) {
            wp_send_json_error(array('message' => __('Chưa kết nối tài khoản Google nào.', 'wp-blogger-manager')));
        }

        $all_blogs = $this->api->fetch_all_accounts_blogs();

        if (is_wp_error($all_blogs)) {
            wp_send_json_error(array('message' => $all_blogs->get_error_message()));
        }

        $accounts = $this->auth->get_accounts();

        wp_send_json_success(array(
            'message' => sprintf(__('Kết nối thành công! Đang quản lý %d tài khoản Google và %d blog Blogger.', 'wp-blogger-manager'), count($accounts), count($all_blogs)),
            'blogs'   => $all_blogs,
        ));
    }

    /**
     * Fetch & Refresh blogs from all Google accounts
     */
    public function ajax_fetch_blogs() {
        $this->verify_request();

        $all_blogs = $this->api->fetch_all_accounts_blogs();

        if (is_wp_error($all_blogs)) {
            wp_send_json_error(array('message' => $all_blogs->get_error_message()));
        }

        wp_send_json_success(array(
            'message' => sprintf(__('Đã cập nhật danh sách %d blog từ tất cả các tài khoản Google đã kết nối.', 'wp-blogger-manager'), count($all_blogs)),
            'blogs'   => $all_blogs,
        ));
    }

    /**
     * Disconnect a specific Google Account
     */
    public function ajax_disconnect_account() {
        $this->verify_request();

        $account_id = isset($_POST['account_id']) ? sanitize_text_field($_POST['account_id']) : '';

        if (empty($account_id)) {
            wp_send_json_error(array('message' => __('Không tìm thấy ID tài khoản Google cần ngắt.', 'wp-blogger-manager')));
        }

        $this->auth->remove_account($account_id);

        wp_send_json_success(array('message' => __('Đã ngắt kết nối tài khoản Google thành công.', 'wp-blogger-manager')));
    }

    /**
     * Disconnect all accounts
     */
    public function ajax_disconnect() {
        $this->verify_request();

        delete_option('wp_blogger_accounts');
        delete_option('wp_blogger_auth');
        delete_option('wp_blogger_blogs');

        wp_send_json_success(array('message' => __('Đã ngắt kết nối toàn bộ tài khoản Google.', 'wp-blogger-manager')));
    }

    /**
     * Toggle Blog Active State
     */
    public function ajax_toggle_blog_active() {
        $this->verify_request();

        $blog_id   = isset($_POST['blog_id']) ? sanitize_text_field($_POST['blog_id']) : '';
        $is_active = isset($_POST['is_active']) ? intval($_POST['is_active']) : 1;

        $blogs = get_option('wp_blogger_blogs', array());
        if (isset($blogs[$blog_id])) {
            $blogs[$blog_id]['is_active'] = $is_active;
            update_option('wp_blogger_blogs', $blogs);
            wp_send_json_success(array('message' => __('Đã cập nhật trạng thái Blog.', 'wp-blogger-manager')));
        }

        wp_send_json_error(array('message' => __('Không tìm thấy Blog.', 'wp-blogger-manager')));
    }

    /**
     * Save default blog settings
     */
    public function ajax_save_blogs_config() {
        $this->verify_request();

        $default_blog_id = isset($_POST['default_blog_id']) ? sanitize_text_field($_POST['default_blog_id']) : '';
        $settings = get_option('wp_blogger_settings', array());
        $settings['default_blog_id'] = $default_blog_id;
        update_option('wp_blogger_settings', $settings);

        wp_send_json_success(array('message' => __('Đã lưu cấu hình Blog mặc định thành công.', 'wp-blogger-manager')));
    }

    /**
     * Sync single post via AJAX (Broadcasts to all/selected blogs)
     */
    public function ajax_sync_single() {
        $this->verify_request();

        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $sync_mode = isset($_POST['sync_mode']) ? sanitize_text_field($_POST['sync_mode']) : '';
        $selected_blogs = isset($_POST['selected_blogs']) && is_array($_POST['selected_blogs']) ? array_map('sanitize_text_field', $_POST['selected_blogs']) : null;

        if (!$post_id) {
            wp_send_json_error(array('message' => __('ID bài viết không hợp lệ.', 'wp-blogger-manager')));
        }

        if (!empty($sync_mode)) {
            update_post_meta($post_id, '_blogger_sync_mode', $sync_mode);
        }

        if ($selected_blogs !== null) {
            update_post_meta($post_id, '_blogger_selected_blogs', $selected_blogs);
        }

        $result = $this->sync->sync_post($post_id, null, true);

        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }

        wp_send_json_success($result);
    }

    /**
     * Bulk sync posts
     */
    public function ajax_bulk_sync() {
        $this->verify_request();

        $post_ids     = isset($_POST['post_ids']) && is_array($_POST['post_ids']) ? array_map('intval', $_POST['post_ids']) : array();
        $target_blogs = isset($_POST['target_blogs']) && is_array($_POST['target_blogs']) ? array_map('sanitize_text_field', $_POST['target_blogs']) : null;

        if (empty($post_ids)) {
            wp_send_json_error(array('message' => __('Chưa chọn bài viết nào để đồng bộ.', 'wp-blogger-manager')));
        }

        $total_success = 0;
        $total_error   = 0;
        $errors        = array();

        foreach ($post_ids as $pid) {
            $res = $this->sync->sync_post($pid, $target_blogs, false);
            if (is_wp_error($res)) {
                $total_error++;
                $errors[] = sprintf(__('Bài #%d: %s', 'wp-blogger-manager'), $pid, $res->get_error_message());
            } else {
                $total_success += $res['success_count'];
                $total_error   += $res['error_count'];
            }
        }

        wp_send_json_success(array(
            'message'       => sprintf(__('Hoàn tất đồng bộ: %d lượt đăng thành công, %d lượt lỗi.', 'wp-blogger-manager'), $total_success, $total_error),
            'success_count' => $total_success,
            'error_count'   => $total_error,
            'errors'        => $errors,
        ));
    }

    /**
     * Get labels (categories) from a Blogger blog
     */
    public function ajax_get_blogger_labels() {
        $this->verify_request();

        $blog_id = isset($_POST['blog_id']) ? sanitize_text_field($_POST['blog_id']) : '';
        if (empty($blog_id)) {
            wp_send_json_error(array('message' => __('Vui lòng chọn blog Blogger.', 'wp-blogger-manager')));
        }

        $labels = $this->api->get_labels($blog_id);
        if (is_wp_error($labels)) {
            wp_send_json_error(array('message' => $labels->get_error_message()));
        }

        // Cache labels in transient 1 hour
        set_transient('wp_blogger_labels_' . $blog_id, $labels, HOUR_IN_SECONDS);

        wp_send_json_success(array(
            'labels' => $labels,
            'count'  => count($labels),
        ));
    }

    /**
     * Fetch posts from Blogger blog by label and save to staging table
     */
    public function ajax_fetch_from_blogger() {
        $this->verify_request();

        $blog_id     = isset($_POST['blog_id'])     ? sanitize_text_field($_POST['blog_id'])     : '';
        $label       = isset($_POST['label'])       ? sanitize_text_field($_POST['label'])       : '';
        $max_results = isset($_POST['max_results']) ? intval($_POST['max_results'])               : 10;
        $fetch_all   = isset($_POST['fetch_all'])   ? (bool) $_POST['fetch_all']                 : false;

        if (empty($blog_id)) {
            wp_send_json_error(array('message' => __('Vui lòng chọn blog Blogger.', 'wp-blogger-manager')));
        }

        if ($fetch_all) {
            $max_results = 0; // 0 = fetch all
        } else {
            $max_results = min(20, max(1, $max_results));
        }

        $result = $this->api->get_posts_by_label($blog_id, $label, $max_results);
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }

        $posts = $result['posts'];
        if (empty($posts)) {
            wp_send_json_error(array('message' => __('Không tìm thấy bài viết nào trong danh mục đã chọn.', 'wp-blogger-manager')));
        }

        // Get blog name
        $blogs     = get_option('wp_blogger_blogs', array());
        $blog_name = !empty($blogs[$blog_id]['name']) ? $blogs[$blog_id]['name'] : $blog_id;

        global $wpdb;
        $table = $wpdb->prefix . 'blogger_import_staging';

        // Ensure table exists (in case plugin wasn't deactivated/reactivated)
        WP_Blogger_Activator::create_import_staging_table();

        $inserted = 0;
        $skipped  = 0;
        $updated  = 0;

        foreach ($posts as $post) {
            $labels_json    = wp_json_encode($post['labels']);
            $published_at   = !empty($post['published']) ? date('Y-m-d H:i:s', strtotime($post['published'])) : null;

            // Check if already in staging
            $existing = $wpdb->get_row($wpdb->prepare(
                "SELECT id, imported_wp_id FROM {$table} WHERE blogger_post_id = %s AND blog_id = %s",
                $post['blogger_post_id'],
                $blog_id
            ));

            if ($existing) {
                if ($existing->imported_wp_id > 0) {
                    // Already imported to WP — skip to avoid overwriting
                    $skipped++;
                    continue;
                }
                // Re-fetch: update content
                $wpdb->update(
                    $table,
                    array(
                        'title'        => $post['title'],
                        'content'      => $post['content'],
                        'excerpt'      => wp_trim_words(strip_tags($post['content']), 30),
                        'url'          => $post['url'],
                        'thumbnail'    => $post['thumbnail'],
                        'labels'       => $labels_json,
                        'author'       => $post['author'],
                        'published_at' => $published_at,
                        'fetched_at'   => current_time('mysql'),
                        'blog_name'    => $blog_name,
                    ),
                    array('id' => $existing->id),
                    array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s'),
                    array('%d')
                );
                $updated++;
            } else {
                $wpdb->insert(
                    $table,
                    array(
                        'blogger_post_id' => $post['blogger_post_id'],
                        'blog_id'         => $blog_id,
                        'blog_name'       => $blog_name,
                        'title'           => $post['title'],
                        'content'         => $post['content'],
                        'excerpt'         => wp_trim_words(strip_tags($post['content']), 30),
                        'url'             => $post['url'],
                        'thumbnail'       => $post['thumbnail'],
                        'labels'          => $labels_json,
                        'author'          => $post['author'],
                        'published_at'    => $published_at,
                        'imported_wp_id'  => 0,
                    ),
                    array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d')
                );
                $inserted++;
            }
        }

        wp_send_json_success(array(
            'message' => sprintf(
                __('Hoàn tất! Đã lấy %d bài viết mới, cập nhật %d bài, bỏ qua %d bài đã import.', 'wp-blogger-manager'),
                $inserted, $updated, $skipped
            ),
            'inserted'   => $inserted,
            'updated'    => $updated,
            'skipped'    => $skipped,
            'total'      => count($posts),
        ));
    }

    /**
     * Import selected staged posts to native WP post type
     */
    public function ajax_import_staging_to_wp() {
        $this->verify_request();

        $staging_ids = isset($_POST['staging_ids']) && is_array($_POST['staging_ids'])
            ? array_map('intval', $_POST['staging_ids'])
            : array();

        if (empty($staging_ids)) {
            wp_send_json_error(array('message' => __('Vui lòng chọn ít nhất 1 bài viết.', 'wp-blogger-manager')));
        }

        global $wpdb;
        $table = $wpdb->prefix . 'blogger_import_staging';

        $imported = 0;
        $skipped  = 0;
        $new_ids  = array();

        foreach ($staging_ids as $staging_id) {
            $row = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d",
                $staging_id
            ));

            if (!$row) {
                $skipped++;
                continue;
            }

            // Already imported
            if ($row->imported_wp_id > 0 && get_post($row->imported_wp_id)) {
                $skipped++;
                continue;
            }

            // Decode labels
            $labels = json_decode($row->labels, true);
            if (!is_array($labels)) { $labels = array(); }

            // Create the WP post
            $new_id = wp_insert_post(array(
                'post_title'   => wp_strip_all_tags($row->title),
                'post_content' => $row->content,
                'post_excerpt' => $row->excerpt,
                'post_status'  => 'draft',
                'post_type'    => 'post',
                'post_author'  => get_current_user_id(),
                'post_date'    => !empty($row->published_at) ? $row->published_at : current_time('mysql'),
            ), true);

            if (is_wp_error($new_id) || !$new_id) {
                $skipped++;
                continue;
            }

            // Sync state: not synced, mode: none (default)
            update_post_meta($new_id, '_blogger_sync_mode',    'none');
            update_post_meta($new_id, '_blogger_sync_status',  '');
            update_post_meta($new_id, '_blogger_import_source_blog_id',   $row->blog_id);
            update_post_meta($new_id, '_blogger_import_source_post_id',   $row->blogger_post_id);
            update_post_meta($new_id, '_blogger_import_source_url',        $row->url);
            update_post_meta($new_id, '_blogger_import_source_blog_name',  $row->blog_name);

            // Attach blogger_label taxonomy terms
            if (!empty($labels)) {
                $term_ids = array();
                foreach ($labels as $label_name) {
                    $term = term_exists($label_name, 'blogger_label');
                    if (!$term) {
                        $term = wp_insert_term($label_name, 'blogger_label');
                    }
                    if (!is_wp_error($term)) {
                        $term_ids[] = (int) (is_array($term) ? $term['term_id'] : $term);
                    }
                }
                if (!empty($term_ids)) {
                    wp_set_object_terms($new_id, $term_ids, 'blogger_label');
                }
            }

            // Mark staging row as imported
            $wpdb->update(
                $table,
                array('imported_wp_id' => $new_id),
                array('id' => $staging_id),
                array('%d'),
                array('%d')
            );

            $imported++;
            $new_ids[] = $new_id;
        }

        wp_send_json_success(array(
            'message' => sprintf(
                __('Đã import %d bài viết vào WP (trạng thái Náp). %d bài bỏ qua.', 'wp-blogger-manager'),
                $imported, $skipped
            ),
            'imported' => $imported,
            'skipped'  => $skipped,
            'new_ids'  => $new_ids,
        ));
    }

    /**
     * Delete selected staging posts from the staging table
     */
    public function ajax_delete_staging_posts() {
        $this->verify_request();

        $staging_ids = isset($_POST['staging_ids']) && is_array($_POST['staging_ids'])
            ? array_map('intval', $_POST['staging_ids'])
            : array();

        if (empty($staging_ids)) {
            wp_send_json_error(array('message' => __('Không có bài nào được chọn.', 'wp-blogger-manager')));
        }

        global $wpdb;
        $table       = $wpdb->prefix . 'blogger_import_staging';
        $placeholders = implode(',', array_fill(0, count($staging_ids), '%d'));
        $deleted      = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table} WHERE id IN ({$placeholders})",
            ...$staging_ids
        ));

        wp_send_json_success(array(
            'message' => sprintf(__('Đã xóa %d bài khỏi danh sách chờ.', 'wp-blogger-manager'), $deleted),
            'deleted' => $deleted,
        ));
    }

    /**
     * Migrate legacy blogger_post CPT entries to native WP post type
     */
    public function ajax_migrate_posts() {
        $this->verify_request();

        $result = $this->sync->migrate_blogger_posts_to_wp();

        wp_send_json_success(array(
            'message' => sprintf(
                __('Đã chuyển %d bài viết Blogger Posts sang WP Posts thành công. %d bài bỏ qua.', 'wp-blogger-manager'),
                $result['migrated'],
                $result['skipped']
            ),
            'migrated' => $result['migrated'],
            'skipped'  => $result['skipped'],
            'new_ids'  => $result['ids'],
        ));
    }

    /**
     * Clear all sync logs
     */
    public function ajax_clear_logs() {
        $this->verify_request();

        $this->sync->clear_logs();

        wp_send_json_success(array('message' => __('Đã xoá toàn bộ lịch sử đồng bộ.', 'wp-blogger-manager')));
    }

    /**
     * Delete post(s) from Blogger without removing them from WordPress
     * Supports single post (post_id) or bulk (post_ids[])
     */
    public function ajax_delete_from_blogger() {
        $this->verify_request();

        // Support both single and bulk deletion
        $post_ids = array();

        if (!empty($_POST['post_ids']) && is_array($_POST['post_ids'])) {
            $post_ids = array_map('intval', $_POST['post_ids']);
        } elseif (!empty($_POST['post_id'])) {
            $post_ids = array(intval($_POST['post_id']));
        }

        if (empty($post_ids)) {
            wp_send_json_error(array('message' => __('Không tìm thấy bài viết cần xoá.', 'wp-blogger-manager')));
        }

        $total_success = 0;
        $total_error   = 0;
        $not_synced    = 0;
        $errors        = array();

        foreach ($post_ids as $pid) {
            $result = $this->sync->delete_blogger_posts($pid);

            if ($result === false) {
                // Post was never synced to Blogger
                $not_synced++;
            } elseif (is_array($result)) {
                $total_success += $result['success_count'];
                $total_error   += $result['error_count'];
                if (!empty($result['error_count'])) {
                    foreach ($result['details'] as $detail) {
                        if ($detail['status'] === 'error') {
                            $errors[] = sprintf(
                                __('Bài #%d [%s]: %s', 'wp-blogger-manager'),
                                $pid,
                                $detail['blog_name'],
                                $detail['message']
                            );
                        }
                    }
                }
            }
        }

        $message_parts = array();
        if ($total_success > 0) {
            $message_parts[] = sprintf(__('Đã xoá thành công %d lượt trên Blogger.', 'wp-blogger-manager'), $total_success);
        }
        if ($total_error > 0) {
            $message_parts[] = sprintf(__('%d lượt xoá bị lỗi.', 'wp-blogger-manager'), $total_error);
        }
        if ($not_synced > 0) {
            $message_parts[] = sprintf(__('%d bài chưa được đồng bộ lên Blogger.', 'wp-blogger-manager'), $not_synced);
        }

        $message = !empty($message_parts) ? implode(' ', $message_parts) : __('Hoàn tất xoá bài viết trên Blogger.', 'wp-blogger-manager');

        wp_send_json_success(array(
            'message'       => $message,
            'success_count' => $total_success,
            'error_count'   => $total_error,
            'not_synced'    => $not_synced,
            'errors'        => $errors,
        ));
    }

    // =========================================================================
    // QUEUE MANAGEMENT HANDLERS
    // =========================================================================

    /**
     * Get queue status counts (for dashboard & auto-refresh)
     */
    public function ajax_queue_status() {
        $this->verify_request();

        // Auto-process any due jobs before returning status
        $this->queue->process_queue();

        $status = $this->queue->get_queue_status();

        wp_send_json_success(array(
            'counts'  => $status,
            'total_active' => $status['pending'] + $status['processing'] + $status['scheduled'],
        ));
    }

    /**
     * Cancel a pending/scheduled queue job
     */
    public function ajax_cancel_queue_job() {
        $this->verify_request();

        $job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
        if (!$job_id) {
            wp_send_json_error(array('message' => __('ID công việc không hợp lệ.', 'wp-blogger-manager')));
        }

        $result = $this->queue->cancel_job($job_id);
        if ($result) {
            wp_send_json_success(array('message' => __('Đã hủy công việc trong hàng đợi.', 'wp-blogger-manager')));
        } else {
            wp_send_json_error(array('message' => __('Không thể hủy công việc (đã xử lý hoặc không tồn tại).', 'wp-blogger-manager')));
        }
    }

    /**
     * Trigger queue processing immediately (manual run)
     */
    public function ajax_process_queue_now() {
        $this->verify_request();

        $this->queue->trigger_now();
        $status = $this->queue->get_queue_status();

        wp_send_json_success(array(
            'message' => __('Đã kích hoạt xử lý hàng đợi. Kết quả sẽ cập nhật trong vài giây.', 'wp-blogger-manager'),
            'counts'  => $status,
        ));
    }

    /**
     * Clear done/cancelled queue jobs
     */
    public function ajax_clear_done_jobs() {
        $this->verify_request();

        $this->queue->clear_done_jobs();

        wp_send_json_success(array('message' => __('Đã xóa các công việc đã hoàn tất khỏi hàng đợi.', 'wp-blogger-manager')));
    }

    // =========================================================================
    // PREVIEW & SCHEDULE HANDLERS
    // =========================================================================

    /**
     * Create a Blogger draft and return the preview URL
     */
    public function ajax_preview_on_blogger() {
        $this->verify_request();

        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $blog_id = isset($_POST['blog_id']) ? sanitize_text_field($_POST['blog_id']) : '';

        if (!$post_id) {
            wp_send_json_error(array('message' => __('ID bài viết không hợp lệ.', 'wp-blogger-manager')));
        }

        if (empty($blog_id)) {
            wp_send_json_error(array('message' => __('Vui lòng chọn Blog Blogger để xem trước.', 'wp-blogger-manager')));
        }

        $result = $this->sync->preview_on_blogger($post_id, $blog_id);

        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }

        wp_send_json_success(array(
            'message'         => __('Đã tạo bản xem trước trên Blogger thành công!', 'wp-blogger-manager'),
            'preview_url'     => $result['preview_url'],
            'blogger_post_id' => $result['blogger_post_id'],
        ));
    }

    /**
     * Add a scheduled broadcast job to the queue
     */
    public function ajax_schedule_broadcast() {
        $this->verify_request();

        $post_id      = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $scheduled_at = isset($_POST['scheduled_at']) ? sanitize_text_field($_POST['scheduled_at']) : '';
        $target_blogs = isset($_POST['target_blogs']) && is_array($_POST['target_blogs'])
            ? array_map('sanitize_text_field', $_POST['target_blogs'])
            : null;

        if (!$post_id) {
            wp_send_json_error(array('message' => __('ID bài viết không hợp lệ.', 'wp-blogger-manager')));
        }

        if (empty($scheduled_at)) {
            wp_send_json_error(array('message' => __('Vui lòng chọn thời gian đặt lịch.', 'wp-blogger-manager')));
        }

        // Format from HTML5 datetime-local (e.g. "2026-08-22T22:07")
        $scheduled_clean = str_replace('T', ' ', $scheduled_at);
        $scheduled_ts    = strtotime($scheduled_clean);
        $current_ts      = strtotime(current_time('mysql'));

        if (!$scheduled_ts || $scheduled_ts <= $current_ts) {
            wp_send_json_error(array('message' => __('Thời gian đặt lịch phải ở trong tương lai so với giờ hiện tại của website.', 'wp-blogger-manager')));
        }

        $scheduled_mysql = date('Y-m-d H:i:s', $scheduled_ts);
        $job_id = $this->queue->enqueue_scheduled($post_id, $scheduled_mysql, $target_blogs);

        if (!$job_id) {
            wp_send_json_error(array('message' => __('Không thể thêm vào hàng đợi. Vui lòng thử lại.', 'wp-blogger-manager')));
        }

        // Guarantee cron is actively scheduled
        WP_Blogger_Queue::schedule_cron();

        wp_send_json_success(array(
            'message'      => sprintf(
                __('Đã lên lịch đồng bộ bài viết vào lúc %s. Mã job: #%d', 'wp-blogger-manager'),
                date_i18n('d/m/Y H:i', $scheduled_ts),
                $job_id
            ),
            'job_id'       => $job_id,
            'scheduled_at' => date_i18n('d/m/Y H:i', $scheduled_ts),
        ));
    }

    /**
     * Return live quota data for the dashboard card
     */
    public function ajax_get_quota() {
        $this->verify_request();

        $quota_data    = $this->api->get_quota_today();
        $quota_history = $this->api->get_quota_history(7);

        wp_send_json_success(array(
            'quota'   => $quota_data,
            'history' => $quota_history,
        ));
    }

}
