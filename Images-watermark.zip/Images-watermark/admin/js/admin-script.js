/**
 * Images Watermark – Admin JavaScript
 * Xử lý: tabs, color picker, range sliders, media uploader, AJAX actions.
 */
/* global IW, wp, jQuery */
(function ($) {
    'use strict';

    /* ── DOM ready ─────────────────────────────────────────────────────── */
    $(function () {
        initTabs();
        initColorPickers();
        initRangeSliders();
        initWatermarkType();
        initPositionGrid();
        initLogoUploader();
        initMediaLibraryButtons();
        initMetaBoxButton();
        initToolApplyPost();
    });

    /* ── Tabs ───────────────────────────────────────────────────────────── */
    function initTabs() {
        var $tabs    = $('.iw-tab');
        var $content = $('.iw-tab-content');

        $tabs.on('click', function () {
            var target = $(this).data('tab');

            $tabs.removeClass('active');
            $content.removeClass('active');

            $(this).addClass('active');
            $('#tab-' + target).addClass('active');

            // Persist tab in URL hash
            history.replaceState(null, '', '#iw-tab-' + target);
        });

        // Restore tab from hash
        var hash = window.location.hash;
        if (hash && hash.startsWith('#iw-tab-')) {
            var tabName = hash.replace('#iw-tab-', '');
            var $target = $('[data-tab="' + tabName + '"]');
            if ($target.length) $target.trigger('click');
        }
    }

    /* ── Color Pickers ──────────────────────────────────────────────────── */
    function initColorPickers() {
        $('.iw-color-picker').wpColorPicker();
    }

    /* ── Range Sliders ──────────────────────────────────────────────────── */
    function initRangeSliders() {
        $('.iw-range').each(function () {
            var $range  = $(this);
            var $output = $('output[for="' + $range.attr('id') + '"]');

            $range.on('input change', function () {
                $output.text(this.value + '%');
            });
        });
    }

    /* ── Watermark type toggle ──────────────────────────────────────────── */
    function initWatermarkType() {
        $('input[name="iw[watermark_type]"]').on('change', function () {
            var val = $(this).val();

            // Update active class on type options
            $('.iw-type-option').removeClass('active');
            $(this).closest('.iw-type-option').addClass('active');

            // Show/hide panels
            if (val === 'text') {
                $('.iw-wm-text').removeClass('iw-hidden');
                $('.iw-wm-image').addClass('iw-hidden');
            } else {
                $('.iw-wm-text').addClass('iw-hidden');
                $('.iw-wm-image').removeClass('iw-hidden');
            }
        });
    }

    /* ── Position grid ──────────────────────────────────────────────────── */
    function initPositionGrid() {
        $('.iw-position-cell').on('click', function () {
            $('.iw-position-cell').removeClass('active');
            $(this).addClass('active');
        });
    }

    /* ── Logo Uploader (WordPress Media Library) ────────────────────────── */
    function initLogoUploader() {
        var mediaUploader;

        $('#iw-select-logo').on('click', function (e) {
            e.preventDefault();

            if (mediaUploader) {
                mediaUploader.open();
                return;
            }

            mediaUploader = wp.media({
                title:    IW.strings.selectLogo,
                button:   { text: IW.strings.useLogo },
                library:  { type: 'image' },
                multiple: false,
            });

            mediaUploader.on('select', function () {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                var thumb = attachment.sizes && attachment.sizes.medium
                    ? attachment.sizes.medium.url
                    : attachment.url;

                $('#iw_image_id').val(attachment.id);

                var $preview = $('#iw-logo-preview');
                $preview.html('<img src="' + thumb + '" alt="Logo watermark" style="max-width:100%;max-height:100%;object-fit:contain;">');

                // Show remove button
                if (!$('#iw-remove-logo').length) {
                    $('#iw-select-logo').after(
                        ' <button type="button" class="button" id="iw-remove-logo">🗑️ Xoá</button>'
                    );
                    initRemoveLogo();
                }
            });

            mediaUploader.open();
        });

        initRemoveLogo();
    }

    function initRemoveLogo() {
        $(document).on('click', '#iw-remove-logo', function (e) {
            e.preventDefault();
            $('#iw_image_id').val('');
            $('#iw-logo-preview').html(
                '<span class="iw-logo-placeholder">📁 Chưa chọn logo</span>'
            );
            $(this).remove();
        });
    }

    /* ── Media Library: Apply / Restore buttons ─────────────────────────── */
    function initMediaLibraryButtons() {
        // Apply watermark to single attachment
        $(document).on('click', '.iw-apply-btn', function () {
            var $btn = $(this);
            var id   = $btn.data('id');

            $btn.text(IW.strings.applying).prop('disabled', true);

            $.post(IW.ajaxUrl, {
                action:        'iw_apply_single',
                nonce:         IW.nonce,
                attachment_id: id,
            }, function (res) {
                if (res.success) {
                    $btn.closest('td').html(
                        '<span class="iw-badge iw-badge--done">✅ Đã WM</span><br>' +
                        '<button class="button button-small iw-restore-btn" data-id="' + id + '">Khôi phục</button>'
                    );
                } else {
                    alert(IW.strings.error + ' ' + (res.data || ''));
                    $btn.text('Áp dụng').prop('disabled', false);
                }
            });
        });

        // Restore original
        $(document).on('click', '.iw-restore-btn', function () {
            var $btn = $(this);
            var id   = $btn.data('id');

            if (!confirm('Bạn có chắc muốn khôi phục ảnh gốc? Watermark sẽ bị xóa.')) return;

            $btn.text(IW.strings.restoring).prop('disabled', true);

            $.post(IW.ajaxUrl, {
                action:        'iw_restore_single',
                nonce:         IW.nonce,
                attachment_id: id,
            }, function (res) {
                if (res.success) {
                    $btn.closest('td').html(
                        '<span class="iw-badge iw-badge--none">⬜ Chưa WM</span><br>' +
                        '<button class="button button-small iw-apply-btn" data-id="' + id + '">Áp dụng</button>'
                    );
                } else {
                    alert(IW.strings.error + ' ' + (res.data || ''));
                    $btn.text('Khôi phục').prop('disabled', false);
                }
            });
        });
    }

    /* ── Post Meta Box button ────────────────────────────────────────────── */
    function initMetaBoxButton() {
        $(document).on('click', '.iw-apply-post-btn', function () {
            var $btn = $(this);
            var $msg = $btn.siblings('.iw-metabox-msg');
            var postId = $btn.data('post-id');

            $btn.text(IW.strings.applying).prop('disabled', true);
            $msg.hide().removeClass('success error');

            $.post(IW.ajaxUrl, {
                action:  'iw_apply_post',
                nonce:   IW.nonce,
                post_id: postId,
            }, function (res) {
                $btn.text('🔄 Áp dụng Watermark ngay').prop('disabled', false);

                if (res.success) {
                    $msg.addClass('success').text(res.data.message).show();
                } else {
                    $msg.addClass('error').text(res.data || IW.strings.error).show();
                }
            }).fail(function () {
                $btn.prop('disabled', false);
                $msg.addClass('error').text(IW.strings.error).show();
            });
        });
    }

    /* ── Tools: Apply to post by ID ─────────────────────────────────────── */
    function initToolApplyPost() {
        $('#iw-tool-apply-post').on('click', function () {
            var $btn   = $(this);
            var $input = $('#iw-tool-post-id');
            var $msg   = $('#iw-tool-msg');
            var postId = parseInt($input.val(), 10);

            if (!postId || postId < 1) {
                $msg.removeClass('success').addClass('error iw-tool-msg').text('Vui lòng nhập ID bài viết hợp lệ!').show();
                return;
            }

            $btn.text(IW.strings.applying).prop('disabled', true);
            $msg.hide().removeClass('success error');

            $.post(IW.ajaxUrl, {
                action:  'iw_apply_post',
                nonce:   IW.nonce,
                post_id: postId,
            }, function (res) {
                $btn.text('💧 Áp dụng Watermark').prop('disabled', false);

                if (res.success) {
                    $msg.addClass('success iw-tool-msg').text(res.data.message).show();
                } else {
                    $msg.addClass('error iw-tool-msg').text(res.data || IW.strings.error).show();
                }
            }).fail(function () {
                $btn.prop('disabled', false);
                $msg.addClass('error iw-tool-msg').text(IW.strings.error).show();
            });
        });
    }

}(jQuery));
