<?php
/**
 * Template: Trang cài đặt plugin Images Watermark.
 *
 * Variables available:
 *  $opts      – array  – tất cả settings hiện tại
 *  $logo_url  – string – URL của logo watermark (nếu có)
 *  $fonts     – array  – danh sách font TTF có sẵn
 *  $post_types – WP_Post_Type[] – danh sách post types
 *  $notice    – string – HTML thông báo (nếu có)
 *
 * @package Images_Watermark
 */
defined( 'ABSPATH' ) || exit;

$positions = [
    'top-left'       => __( '↖ Trên – Trái',   'images-watermark' ),
    'top-center'     => __( '↑ Trên – Giữa',   'images-watermark' ),
    'top-right'      => __( '↗ Trên – Phải',   'images-watermark' ),
    'middle-left'    => __( '← Giữa – Trái',   'images-watermark' ),
    'middle-center'  => __( '✚ Chính giữa',    'images-watermark' ),
    'middle-right'   => __( '→ Giữa – Phải',   'images-watermark' ),
    'bottom-left'    => __( '↙ Dưới – Trái',   'images-watermark' ),
    'bottom-center'  => __( '↓ Dưới – Giữa',  'images-watermark' ),
    'bottom-right'   => __( '↘ Dưới – Phải',  'images-watermark' ),
];

function iw_checked( $val, $compare ): string {
    return checked( $val, $compare, false );
}
function iw_selected( $val, $compare ): string {
    return selected( $val, $compare, false );
}
?>
<div class="wrap iw-wrap" id="iw-settings-page">

    <!-- ── Header ───────────────────────────────────────────────────── -->
    <div class="iw-header">
        <div class="iw-header__inner">
            <div class="iw-header__logo">
                <span class="iw-icon">🖼️</span>
                <div>
                    <h1><?php esc_html_e( 'Images Watermark', 'images-watermark' ); ?></h1>
                    <p><?php esc_html_e( 'Tự động đóng watermark cho ảnh khi đăng bài viết', 'images-watermark' ); ?></p>
                </div>
            </div>
            <div class="iw-header__badge">v<?php echo esc_html( IW_VERSION ); ?></div>
        </div>
    </div>

    <?php echo wp_kses_post( $notice ); ?>

    <!-- ── Tabs ─────────────────────────────────────────────────────── -->
    <div class="iw-tabs">
        <button class="iw-tab active" data-tab="general">⚙️ <?php esc_html_e( 'Cài đặt chung', 'images-watermark' ); ?></button>
        <button class="iw-tab" data-tab="watermark">💧 <?php esc_html_e( 'Watermark', 'images-watermark' ); ?></button>
        <button class="iw-tab" data-tab="position">📍 <?php esc_html_e( 'Vị trí', 'images-watermark' ); ?></button>
        <button class="iw-tab" data-tab="tools">🔧 <?php esc_html_e( 'Công cụ', 'images-watermark' ); ?></button>
    </div>

    <!-- ── Form ─────────────────────────────────────────────────────── -->
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="iw-settings-form">
        <input type="hidden" name="action" value="iw_save_settings">
        <?php wp_nonce_field( 'iw_save_settings', 'iw_nonce_field' ); ?>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- TAB: Cài đặt chung                                        -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div class="iw-tab-content active" id="tab-general">
            <div class="iw-card">
                <div class="iw-card__header">⚙️ <?php esc_html_e( 'Cài đặt chung', 'images-watermark' ); ?></div>
                <div class="iw-card__body">

                    <!-- Bật / tắt -->
                    <div class="iw-field iw-field--toggle">
                        <label class="iw-toggle">
                            <input type="checkbox" name="iw[enabled]" value="1" <?php checked( $opts['enabled'] ) ?>>
                            <span class="iw-toggle__slider"></span>
                        </label>
                        <div class="iw-field__info">
                            <strong><?php esc_html_e( 'Kích hoạt plugin', 'images-watermark' ); ?></strong>
                            <p><?php esc_html_e( 'Bật/tắt toàn bộ tính năng watermark.', 'images-watermark' ); ?></p>
                        </div>
                    </div>

                    <hr class="iw-divider">

                    <!-- Watermark khi upload -->
                    <div class="iw-field iw-field--toggle">
                        <label class="iw-toggle">
                            <input type="checkbox" name="iw[watermark_on_upload]" value="1" <?php checked( $opts['watermark_on_upload'] ) ?>>
                            <span class="iw-toggle__slider"></span>
                        </label>
                        <div class="iw-field__info">
                            <strong><?php esc_html_e( 'Watermark ngay khi upload', 'images-watermark' ); ?></strong>
                            <p><?php esc_html_e( 'Áp dụng watermark ngay khi ảnh được tải lên, không cần đợi publish bài.', 'images-watermark' ); ?></p>
                        </div>
                    </div>

                    <hr class="iw-divider">

                    <!-- Backup ảnh gốc -->
                    <div class="iw-field iw-field--toggle">
                        <label class="iw-toggle">
                            <input type="checkbox" name="iw[backup_original]" value="1" <?php checked( $opts['backup_original'] ) ?>>
                            <span class="iw-toggle__slider"></span>
                        </label>
                        <div class="iw-field__info">
                            <strong><?php esc_html_e( 'Lưu backup ảnh gốc', 'images-watermark' ); ?></strong>
                            <p><?php esc_html_e( 'Lưu bản sao ảnh gốc vào thư mục bảo vệ trước khi đóng watermark. Cần thiết để có thể khôi phục ảnh.', 'images-watermark' ); ?></p>
                        </div>
                    </div>

                    <hr class="iw-divider">

                    <!-- Áp dụng cho ảnh nào -->
                    <div class="iw-field">
                        <label class="iw-label"><?php esc_html_e( 'Áp dụng watermark cho', 'images-watermark' ); ?></label>
                        <div class="iw-checkgroup">
                            <label class="iw-check">
                                <input type="checkbox" name="iw[apply_to_featured]" value="1" <?php checked( $opts['apply_to_featured'] ) ?>>
                                <span><?php esc_html_e( 'Ảnh đại diện (Featured Image)', 'images-watermark' ); ?></span>
                            </label>
                            <label class="iw-check">
                                <input type="checkbox" name="iw[apply_to_content]" value="1" <?php checked( $opts['apply_to_content'] ) ?>>
                                <span><?php esc_html_e( 'Tất cả ảnh đính kèm trong bài', 'images-watermark' ); ?></span>
                            </label>
                        </div>
                    </div>

                    <hr class="iw-divider">

                    <!-- Post types -->
                    <div class="iw-field">
                        <label class="iw-label"><?php esc_html_e( 'Post types áp dụng', 'images-watermark' ); ?></label>
                        <div class="iw-checkgroup">
                            <?php foreach ( $post_types as $type ) : ?>
                                <label class="iw-check">
                                    <input type="checkbox"
                                           name="iw[post_types][]"
                                           value="<?php echo esc_attr( $type->name ); ?>"
                                        <?php checked( in_array( $type->name, (array) $opts['post_types'], true ) ); ?>
                                    >
                                    <span><?php echo esc_html( $type->labels->singular_name ); ?> <code><?php echo esc_html( $type->name ); ?></code></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <hr class="iw-divider">

                    <!-- Kích thước tối thiểu -->
                    <div class="iw-field iw-field--row">
                        <div>
                            <label class="iw-label" for="iw_min_width"><?php esc_html_e( 'Chiều rộng tối thiểu (px)', 'images-watermark' ); ?></label>
                            <input type="number" id="iw_min_width" name="iw[min_width]"
                                   value="<?php echo esc_attr( $opts['min_width'] ); ?>" min="0" max="5000" class="small-text">
                        </div>
                        <div>
                            <label class="iw-label" for="iw_min_height"><?php esc_html_e( 'Chiều cao tối thiểu (px)', 'images-watermark' ); ?></label>
                            <input type="number" id="iw_min_height" name="iw[min_height]"
                                   value="<?php echo esc_attr( $opts['min_height'] ); ?>" min="0" max="5000" class="small-text">
                        </div>
                    </div>
                    <p class="iw-hint"><?php esc_html_e( 'Bỏ qua ảnh nhỏ hơn kích thước này (0 = không giới hạn).', 'images-watermark' ); ?></p>

                </div>
            </div>
        </div>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- TAB: Watermark                                            -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div class="iw-tab-content" id="tab-watermark">

            <!-- Kiểu watermark -->
            <div class="iw-card">
                <div class="iw-card__header">💧 <?php esc_html_e( 'Kiểu Watermark', 'images-watermark' ); ?></div>
                <div class="iw-card__body">
                    <div class="iw-type-selector">
                        <label class="iw-type-option <?php echo $opts['watermark_type'] === 'text' ? 'active' : ''; ?>">
                            <input type="radio" name="iw[watermark_type]" value="text" <?php checked( $opts['watermark_type'], 'text' ); ?>>
                            <span class="iw-type-icon">✍️</span>
                            <span><?php esc_html_e( 'Văn bản (Text)', 'images-watermark' ); ?></span>
                        </label>
                        <label class="iw-type-option <?php echo $opts['watermark_type'] === 'image' ? 'active' : ''; ?>">
                            <input type="radio" name="iw[watermark_type]" value="image" <?php checked( $opts['watermark_type'], 'image' ); ?>>
                            <span class="iw-type-icon">🖼️</span>
                            <span><?php esc_html_e( 'Logo / Hình ảnh', 'images-watermark' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Text watermark settings -->
            <div class="iw-card iw-wm-text <?php echo $opts['watermark_type'] !== 'text' ? 'iw-hidden' : ''; ?>">
                <div class="iw-card__header">✍️ <?php esc_html_e( 'Cài đặt Watermark Văn bản', 'images-watermark' ); ?></div>
                <div class="iw-card__body">

                    <div class="iw-field">
                        <label class="iw-label" for="iw_text"><?php esc_html_e( 'Nội dung watermark', 'images-watermark' ); ?></label>
                        <input type="text" id="iw_text" name="iw[text]"
                               value="<?php echo esc_attr( $opts['text'] ); ?>"
                               class="regular-text" placeholder="© YourSite.com">
                    </div>

                    <div class="iw-field iw-field--row">
                        <div>
                            <label class="iw-label" for="iw_font_size"><?php esc_html_e( 'Cỡ chữ (px)', 'images-watermark' ); ?></label>
                            <input type="number" id="iw_font_size" name="iw[font_size]"
                                   value="<?php echo esc_attr( $opts['font_size'] ); ?>"
                                   min="8" max="200" class="small-text">
                        </div>
                        <div>
                            <label class="iw-label" for="iw_text_angle"><?php esc_html_e( 'Góc xoay (độ)', 'images-watermark' ); ?></label>
                            <input type="number" id="iw_text_angle" name="iw[text_angle]"
                                   value="<?php echo esc_attr( $opts['text_angle'] ); ?>"
                                   min="-90" max="90" class="small-text">
                        </div>
                    </div>

                    <div class="iw-field iw-field--row">
                        <div>
                            <label class="iw-label" for="iw_font_color"><?php esc_html_e( 'Màu chữ', 'images-watermark' ); ?></label>
                            <input type="text" id="iw_font_color" name="iw[font_color]"
                                   value="<?php echo esc_attr( $opts['font_color'] ); ?>"
                                   class="iw-color-picker">
                        </div>
                        <div>
                            <label class="iw-label" for="iw_font_family"><?php esc_html_e( 'Font chữ', 'images-watermark' ); ?></label>
                            <select id="iw_font_family" name="iw[font_family]">
                                <?php foreach ( $fonts as $key => $label ) : ?>
                                    <option value="<?php echo esc_attr( $key ); ?>" <?php iw_selected( $opts['font_family'], $key ); ?>>
                                        <?php echo esc_html( $label ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Image watermark settings -->
            <div class="iw-card iw-wm-image <?php echo $opts['watermark_type'] !== 'image' ? 'iw-hidden' : ''; ?>">
                <div class="iw-card__header">🖼️ <?php esc_html_e( 'Cài đặt Watermark Logo', 'images-watermark' ); ?></div>
                <div class="iw-card__body">

                    <div class="iw-field">
                        <label class="iw-label"><?php esc_html_e( 'Ảnh Logo Watermark', 'images-watermark' ); ?></label>
                        <div class="iw-logo-picker">
                            <div class="iw-logo-preview" id="iw-logo-preview">
                                <?php if ( $logo_url ) : ?>
                                    <img src="<?php echo esc_url( $logo_url ); ?>" alt="Logo watermark">
                                <?php else : ?>
                                    <span class="iw-logo-placeholder">📁 <?php esc_html_e( 'Chưa chọn logo', 'images-watermark' ); ?></span>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" name="iw[image_id]" id="iw_image_id" value="<?php echo esc_attr( $opts['image_id'] ); ?>">
                            <div class="iw-logo-btns">
                                <button type="button" class="button button-primary" id="iw-select-logo">
                                    📁 <?php esc_html_e( 'Chọn Logo', 'images-watermark' ); ?>
                                </button>
                                <?php if ( $opts['image_id'] ) : ?>
                                    <button type="button" class="button" id="iw-remove-logo">
                                        🗑️ <?php esc_html_e( 'Xoá', 'images-watermark' ); ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <p class="iw-hint"><?php esc_html_e( 'Khuyến nghị dùng ảnh PNG với nền trong suốt (transparent).', 'images-watermark' ); ?></p>
                    </div>

                    <div class="iw-field">
                        <label class="iw-label" for="iw_image_width_percent">
                            <?php esc_html_e( 'Kích thước logo (% chiều rộng ảnh)', 'images-watermark' ); ?>
                        </label>
                        <div class="iw-range-wrap">
                            <input type="range" id="iw_image_width_percent" name="iw[image_width_percent]"
                                   value="<?php echo esc_attr( $opts['image_width_percent'] ); ?>"
                                   min="5" max="80" step="1" class="iw-range">
                            <output class="iw-range-val" for="iw_image_width_percent"><?php echo esc_html( $opts['image_width_percent'] ); ?>%</output>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Opacity chung -->
            <div class="iw-card">
                <div class="iw-card__header">🔆 <?php esc_html_e( 'Độ đục (Opacity)', 'images-watermark' ); ?></div>
                <div class="iw-card__body">
                    <div class="iw-field">
                        <label class="iw-label" for="iw_opacity">
                            <?php esc_html_e( 'Opacity tổng thể', 'images-watermark' ); ?>
                        </label>
                        <div class="iw-range-wrap">
                            <input type="range" id="iw_opacity" name="iw[opacity]"
                                   value="<?php echo esc_attr( $opts['opacity'] ); ?>"
                                   min="0" max="100" step="5" class="iw-range">
                            <output class="iw-range-val" for="iw_opacity"><?php echo esc_html( $opts['opacity'] ); ?>%</output>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- TAB: Vị trí                                               -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div class="iw-tab-content" id="tab-position">
            <div class="iw-card">
                <div class="iw-card__header">📍 <?php esc_html_e( 'Vị trí Watermark', 'images-watermark' ); ?></div>
                <div class="iw-card__body">

                    <div class="iw-field">
                        <label class="iw-label"><?php esc_html_e( 'Chọn vị trí', 'images-watermark' ); ?></label>
                        <div class="iw-position-grid">
                            <?php foreach ( $positions as $pos_key => $pos_label ) : ?>
                                <label class="iw-position-cell <?php echo $opts['position'] === $pos_key ? 'active' : ''; ?>">
                                    <input type="radio" name="iw[position]" value="<?php echo esc_attr( $pos_key ); ?>"
                                        <?php checked( $opts['position'], $pos_key ); ?>>
                                    <span><?php echo esc_html( $pos_label ); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <hr class="iw-divider">

                    <div class="iw-field iw-field--row">
                        <div>
                            <label class="iw-label" for="iw_offset_x"><?php esc_html_e( 'Khoảng cách ngang (px)', 'images-watermark' ); ?></label>
                            <input type="number" id="iw_offset_x" name="iw[offset_x]"
                                   value="<?php echo esc_attr( $opts['offset_x'] ); ?>"
                                   min="0" max="500" class="small-text">
                        </div>
                        <div>
                            <label class="iw-label" for="iw_offset_y"><?php esc_html_e( 'Khoảng cách dọc (px)', 'images-watermark' ); ?></label>
                            <input type="number" id="iw_offset_y" name="iw[offset_y]"
                                   value="<?php echo esc_attr( $opts['offset_y'] ); ?>"
                                   min="0" max="500" class="small-text">
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- TAB: Công cụ                                              -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div class="iw-tab-content" id="tab-tools">
            <div class="iw-card">
                <div class="iw-card__header">🔧 <?php esc_html_e( 'Công cụ thủ công', 'images-watermark' ); ?></div>
                <div class="iw-card__body">
                    <p><?php esc_html_e( 'Nhập ID bài viết để áp dụng watermark thủ công cho tất cả ảnh trong bài:', 'images-watermark' ); ?></p>
                    <div class="iw-tool-row">
                        <input type="number" id="iw-tool-post-id" placeholder="ID bài viết..." class="regular-text" min="1">
                        <button type="button" class="button button-primary" id="iw-tool-apply-post">
                            💧 <?php esc_html_e( 'Áp dụng Watermark', 'images-watermark' ); ?>
                        </button>
                    </div>
                    <div id="iw-tool-msg" class="iw-tool-msg" style="display:none;"></div>
                </div>
            </div>

            <div class="iw-card iw-card--info">
                <div class="iw-card__header">ℹ️ <?php esc_html_e( 'Thông tin hệ thống', 'images-watermark' ); ?></div>
                <div class="iw-card__body">
                    <table class="iw-info-table">
                        <tr>
                            <th><?php esc_html_e( 'PHP Version', 'images-watermark' ); ?></th>
                            <td><?php echo esc_html( PHP_VERSION ); ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'GD Library', 'images-watermark' ); ?></th>
                            <td>
                                <?php if ( extension_loaded( 'gd' ) ) :
                                    $gd = gd_info();
                                    echo '<span class="iw-ok">✅ ' . esc_html( $gd['GD Version'] ?? 'Có' ) . '</span>';
                                else : ?>
                                    <span class="iw-err">❌ <?php esc_html_e( 'Không tìm thấy! Plugin cần GD Library.', 'images-watermark' ); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'FreeType (TTF fonts)', 'images-watermark' ); ?></th>
                            <td>
                                <?php if ( function_exists( 'imagettftext' ) ) : ?>
                                    <span class="iw-ok">✅ <?php esc_html_e( 'Hỗ trợ', 'images-watermark' ); ?></span>
                                <?php else : ?>
                                    <span class="iw-warn">⚠️ <?php esc_html_e( 'Không hỗ trợ – sẽ dùng font built-in', 'images-watermark' ); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'WebP Support', 'images-watermark' ); ?></th>
                            <td>
                                <?php if ( function_exists( 'imagecreatefromwebp' ) ) : ?>
                                    <span class="iw-ok">✅ <?php esc_html_e( 'Hỗ trợ', 'images-watermark' ); ?></span>
                                <?php else : ?>
                                    <span class="iw-warn">⚠️ <?php esc_html_e( 'Không hỗ trợ', 'images-watermark' ); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Backup Directory', 'images-watermark' ); ?></th>
                            <td>
                                <?php
                                $upload_dir = wp_upload_dir();
                                $backup_dir = $upload_dir['basedir'] . '/iw-originals';
                                if ( is_dir( $backup_dir ) && is_writable( $backup_dir ) ) {
                                    echo '<span class="iw-ok">✅ ' . esc_html( $backup_dir ) . '</span>';
                                } else {
                                    echo '<span class="iw-warn">⚠️ ' . esc_html( $backup_dir ) . ' – ' . esc_html__( 'Chưa tồn tại hoặc không thể ghi', 'images-watermark' ) . '</span>';
                                }
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <!-- ── Submit ────────────────────────────────────────────── -->
        <div class="iw-submit-bar">
            <?php submit_button( __( '💾 Lưu cài đặt', 'images-watermark' ), 'primary large', 'submit', false ); ?>
        </div>

    </form>
</div>
