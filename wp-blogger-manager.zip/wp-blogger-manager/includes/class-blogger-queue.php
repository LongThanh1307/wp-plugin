<?php
/**
 * Background Sync Queue Engine with Auto-Retry & Schedule Broadcast
 * Processes sync jobs via WP Cron to prevent PHP timeout on bulk operations.
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Blogger_Queue {

    /** Queue table suffix */
    const TABLE_SUFFIX = 'blogger_sync_queue';

    /** Cron hook names */
    const CRON_PROCESS = 'wp_blogger_process_queue';
    const CRON_RETRY   = 'wp_blogger_retry_failed';

    /** Jobs per cron batch */
    const BATCH_SIZE = 5;

    /**
     * Retry backoff in seconds:
     * attempt 1 -> 5min, attempt 2 -> 15min, attempt 3 -> 60min
     */
    private static $retry_backoff = array(300, 900, 3600);

    /** @var WP_Blogger_API */
    private $api;

    /** @var WP_Blogger_Sync */
    private $sync;

    /**
     * Constructor
     */
    public function __construct(WP_Blogger_API $api, WP_Blogger_Sync $sync) {
        $this->api  = $api;
        $this->sync = $sync;
        $this->init_hooks();
    }

    /**
     * Register WP Cron hooks & Auto-scheduling
     */
    private function init_hooks() {
        add_filter('cron_schedules',   array($this, 'register_cron_intervals'));
        add_action(self::CRON_PROCESS, array($this, 'process_queue'));
        add_action(self::CRON_RETRY,   array($this, 'retry_stuck_jobs'));
        add_action('init',             array($this, 'ensure_cron_scheduled'));
        add_action('admin_init',       array($this, 'auto_process_due_jobs'));
    }

    /**
     * Register custom cron intervals
     */
    public function register_cron_intervals($schedules) {
        if (!isset($schedules['wp_blogger_1min'])) {
            $schedules['wp_blogger_1min'] = array(
                'interval' => 60,
                'display'  => __('Mỗi 1 phút (WP Blogger Queue)', 'wp-blogger-manager'),
            );
        }
        return $schedules;
    }

    /**
     * Self-healing: Ensure cron is actively scheduled whenever Queue mode is on or pending jobs exist
     */
    public function ensure_cron_scheduled() {
        $settings = get_option('wp_blogger_settings', array());
        $has_queue_mode = !empty($settings['queue_mode']);

        if ($has_queue_mode || $this->has_active_jobs()) {
            if (!wp_next_scheduled(self::CRON_PROCESS)) {
                self::schedule_cron();
            }
        }
    }

    /**
     * Check if queue table has any pending or scheduled jobs
     */
    public function has_active_jobs() {
        global $wpdb;
        $table = $this->get_table();
        $count = $wpdb->get_var("SELECT COUNT(id) FROM {$table} WHERE status IN ('pending','scheduled','processing')");
        return intval($count) > 0;
    }

    /**
     * Auto-process due jobs on admin requests (guarantees execution even if Virtual Cron has no web traffic)
     */
    public function auto_process_due_jobs() {
        $this->process_queue();
    }

    /**
     * Schedule cron jobs — call from activator or when queue mode enabled
     */
    public static function schedule_cron() {
        // Ensure interval is registered before scheduling
        add_filter('cron_schedules', function ($schedules) {
            if (!isset($schedules['wp_blogger_1min'])) {
                $schedules['wp_blogger_1min'] = array(
                    'interval' => 60,
                    'display'  => __('Mỗi 1 phút (WP Blogger Queue)', 'wp-blogger-manager'),
                );
            }
            return $schedules;
        });

        if (!wp_next_scheduled(self::CRON_PROCESS)) {
            wp_schedule_event(time(), 'wp_blogger_1min', self::CRON_PROCESS);
        }
        if (!wp_next_scheduled(self::CRON_RETRY)) {
            wp_schedule_event(time(), 'hourly', self::CRON_RETRY);
        }
    }

    /**
     * Clear cron jobs — call from deactivator
     */
    public static function unschedule_cron() {
        wp_clear_scheduled_hook(self::CRON_PROCESS);
        wp_clear_scheduled_hook(self::CRON_RETRY);
    }

    /**
     * Get the full queue table name
     */
    public function get_table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_SUFFIX;
    }

    /**
     * Add an immediate sync job to the queue
     *
     * @param int        $post_id
     * @param array|null $target_blogs  Blog IDs, null = use post/settings default
     * @param string     $action        'sync' | 'delete'
     * @return int|false Job ID or false
     */
    public function enqueue_sync($post_id, $target_blogs = null, $action = 'sync') {
        return $this->insert_job(array(
            'post_id'      => intval($post_id),
            'target_blogs' => !empty($target_blogs) ? wp_json_encode($target_blogs) : null,
            'action'       => sanitize_text_field($action),
            'status'       => 'pending',
            'retry_count'  => 0,
            'scheduled_at' => current_time('mysql'),
            'created_at'   => current_time('mysql'),
        ));
    }

    /**
     * Add a scheduled sync job (runs at future datetime)
     *
     * @param int        $post_id
     * @param string     $scheduled_at  MySQL datetime (local time)
     * @param array|null $target_blogs
     * @return int|false Job ID or false
     */
    public function enqueue_scheduled($post_id, $scheduled_at, $target_blogs = null) {
        return $this->insert_job(array(
            'post_id'      => intval($post_id),
            'target_blogs' => !empty($target_blogs) ? wp_json_encode($target_blogs) : null,
            'action'       => 'sync',
            'status'       => 'scheduled',
            'retry_count'  => 0,
            'scheduled_at' => $scheduled_at,
            'created_at'   => current_time('mysql'),
        ));
    }

    /**
     * Insert a job row, deduplicating pending/scheduled for same post
     */
    private function insert_job($data) {
        global $wpdb;
        $table = $this->get_table();

        // Check for existing active job for this post
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id, status FROM {$table}
             WHERE post_id = %d AND status IN ('pending','scheduled','processing')
             LIMIT 1",
            $data['post_id']
        ));

        if ($existing) {
            // Update scheduled_at for a re-schedule request
            if (isset($data['scheduled_at']) && $existing->status !== 'processing') {
                $wpdb->update(
                    $table,
                    array('scheduled_at' => $data['scheduled_at'], 'status' => $data['status']),
                    array('id' => $existing->id)
                );
            }
            return intval($existing->id);
        }

        $result = $wpdb->insert($table, $data, array('%d', '%s', '%s', '%s', '%d', '%s', '%s'));
        return $result ? $wpdb->insert_id : false;
    }

    /**
     * WP Cron handler: process a batch of due queue items
     */
    public function process_queue() {
        global $wpdb;
        $table    = $this->get_table();
        $settings = get_option('wp_blogger_settings', array());

        if (empty($settings['queue_mode'])) {
            return;
        }

        $now  = current_time('mysql');
        $jobs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table}
             WHERE status IN ('pending','scheduled')
               AND scheduled_at <= %s
             ORDER BY scheduled_at ASC
             LIMIT %d",
            $now,
            self::BATCH_SIZE
        ));

        if (empty($jobs)) {
            return;
        }

        foreach ($jobs as $job) {
            // Mark as processing to prevent duplicate execution
            $wpdb->update(
                $table,
                array('status' => 'processing', 'started_at' => $now),
                array('id' => $job->id)
            );

            $target_blogs = !empty($job->target_blogs) ? json_decode($job->target_blogs, true) : null;
            $is_success   = false;
            $error_msg    = '';

            if ($job->action === 'delete') {
                $result     = $this->sync->delete_blogger_posts($job->post_id);
                $is_success = is_array($result) && $result['error_count'] === 0;
                if (!$is_success) {
                    $error_msg = is_array($result) ? $result['message'] : __('Khong co blog nao de xoa.', 'wp-blogger-manager');
                }
            } else {
                $result     = $this->sync->sync_post($job->post_id, $target_blogs, true);
                $is_success = !is_wp_error($result) && isset($result['success_count']) && $result['success_count'] > 0;
                if (!$is_success) {
                    $error_msg = is_wp_error($result) ? $result->get_error_message() : (isset($result['message']) ? $result['message'] : __('Dong bo that bai.', 'wp-blogger-manager'));
                }
            }

            if ($is_success) {
                $wpdb->update(
                    $table,
                    array('status' => 'done', 'completed_at' => current_time('mysql'), 'last_error' => ''),
                    array('id' => $job->id)
                );
            } else {
                $this->handle_job_failure($job, $error_msg);
            }
        }
    }

    /**
     * Schedule retry or mark job as permanently failed
     *
     * @param object $job
     * @param string $error_msg
     */
    private function handle_job_failure($job, $error_msg) {
        global $wpdb;
        $table = $this->get_table();

        $settings    = get_option('wp_blogger_settings', array());
        $max_retries = isset($settings['max_retries']) ? intval($settings['max_retries']) : 3;
        $retry_count = intval($job->retry_count) + 1;

        if ($retry_count <= $max_retries) {
            $idx      = min($retry_count - 1, count(self::$retry_backoff) - 1);
            $delay    = self::$retry_backoff[$idx];
            $next_run = gmdate('Y-m-d H:i:s', time() + $delay);

            $wpdb->update(
                $table,
                array(
                    'status'       => 'scheduled',
                    'retry_count'  => $retry_count,
                    'scheduled_at' => $next_run,
                    'started_at'   => null,
                    'last_error'   => substr($error_msg, 0, 500),
                ),
                array('id' => $job->id)
            );
        } else {
            $wpdb->update(
                $table,
                array(
                    'status'       => 'failed',
                    'last_error'   => substr($error_msg, 0, 500),
                    'completed_at' => current_time('mysql'),
                ),
                array('id' => $job->id)
            );
        }
    }

    /**
     * WP Cron (hourly): recover stuck 'processing' jobs older than 10 minutes
     */
    public function retry_stuck_jobs() {
        global $wpdb;
        $table    = $this->get_table();
        $settings = get_option('wp_blogger_settings', array());

        if (empty($settings['queue_mode'])) {
            return;
        }

        $stuck_cutoff = gmdate('Y-m-d H:i:s', time() - 600);
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table}
             SET status = 'pending', scheduled_at = %s, started_at = NULL
             WHERE status = 'processing' AND started_at <= %s",
            current_time('mysql'),
            $stuck_cutoff
        ));
    }

    /**
     * Cancel a pending or scheduled job
     *
     * @param int $job_id
     * @return bool
     */
    public function cancel_job($job_id) {
        global $wpdb;
        $table = $this->get_table();

        $rows = $wpdb->query($wpdb->prepare(
            "UPDATE {$table}
             SET status = 'cancelled', completed_at = %s
             WHERE id = %d AND status IN ('pending','scheduled')",
            current_time('mysql'),
            intval($job_id)
        ));

        return $rows > 0;
    }

    /**
     * Get queue stats grouped by status
     *
     * @return array
     */
    public function get_queue_status() {
        global $wpdb;
        $table = $this->get_table();

        $rows = $wpdb->get_results(
            "SELECT status, COUNT(*) as cnt FROM {$table} GROUP BY status"
        );

        $counts = array(
            'pending'    => 0,
            'processing' => 0,
            'scheduled'  => 0,
            'done'       => 0,
            'failed'     => 0,
            'cancelled'  => 0,
        );

        foreach ($rows as $row) {
            if (array_key_exists($row->status, $counts)) {
                $counts[$row->status] = intval($row->cnt);
            }
        }

        return $counts;
    }

    /**
     * Get queue items for admin display
     *
     * @param int    $limit
     * @param string $status  '' for all statuses
     * @return array
     */
    public function get_queue_items($limit = 50, $status = '') {
        global $wpdb;
        $table = $this->get_table();

        if (!empty($status)) {
            return $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$table} WHERE status = %s ORDER BY scheduled_at DESC LIMIT %d",
                sanitize_text_field($status),
                intval($limit)
            ));
        }

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} ORDER BY scheduled_at DESC LIMIT %d",
            intval($limit)
        ));
    }

    /**
     * Delete done/cancelled jobs immediately (manual cleanup)
     */
    public function clear_done_jobs() {
        global $wpdb;
        return $wpdb->query(
            "DELETE FROM {$this->get_table()} WHERE status IN ('done','cancelled')"
        );
    }

    /**
     * Force run queue processing now (for manual trigger button)
     */
    public function trigger_now() {
        do_action(self::CRON_PROCESS);
    }

    /**
     * Create the queue DB table — called from WP_Blogger_Activator
     */
    public static function create_table() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        $table_name      = $wpdb->prefix . self::TABLE_SUFFIX;

        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL DEFAULT 0,
            target_blogs longtext NULL,
            action varchar(20) NOT NULL DEFAULT 'sync',
            status varchar(20) NOT NULL DEFAULT 'pending',
            retry_count tinyint(3) NOT NULL DEFAULT 0,
            last_error text NULL,
            scheduled_at datetime NOT NULL,
            started_at datetime NULL,
            completed_at datetime NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY post_id (post_id),
            KEY status (status),
            KEY scheduled_at (scheduled_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }
}
