<?php
/**
 * Fired during plugin activation
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WP_Blogger_Queue')) {
    require_once dirname(__FILE__) . '/class-blogger-queue.php';
}

class WP_Blogger_Activator {

    /**
     * Run activation tasks
     */
    public static function activate() {
        self::create_tables();
        self::init_default_options();
        WP_Blogger_Queue::schedule_cron();
        flush_rewrite_rules();
    }

    /**
     * Create custom tables for sync logs
     */
    private static function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'blogger_sync_logs';

        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL DEFAULT 0,
            blog_id varchar(100) NOT NULL DEFAULT '',
            blogger_post_id varchar(100) NOT NULL DEFAULT '',
            action varchar(50) NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'success',
            message text NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY post_id (post_id),
            KEY blog_id (blog_id),
            KEY status (status)
        ) {$charset_collate};";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Create background sync queue table
        WP_Blogger_Queue::create_table();

        // Create import staging table (Blogger → WP)
        self::create_import_staging_table();
    }

    /**
     * Create import staging table for Blogger → WP import workflow
     */
    public static function create_import_staging_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table_name      = $wpdb->prefix . 'blogger_import_staging';

        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            blogger_post_id varchar(100) NOT NULL DEFAULT '',
            blog_id varchar(100) NOT NULL DEFAULT '',
            blog_name varchar(255) NOT NULL DEFAULT '',
            title text NOT NULL,
            content longtext NOT NULL,
            excerpt text NOT NULL DEFAULT '',
            url varchar(500) NOT NULL DEFAULT '',
            thumbnail varchar(500) NOT NULL DEFAULT '',
            labels text NOT NULL DEFAULT '',
            author varchar(255) NOT NULL DEFAULT '',
            published_at datetime NULL,
            fetched_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            imported_wp_id bigint(20) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY blogger_post_unique (blogger_post_id, blog_id),
            KEY blog_id (blog_id),
            KEY imported_wp_id (imported_wp_id)
        ) {$charset_collate};";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Set default plugin options
     */
    private static function init_default_options() {
        if (false === get_option('wp_blogger_settings')) {
            $default_settings = array(
                'client_id'             => '',
                'client_secret'         => '',
                'default_blog_id'       => '',
                'auto_sync_on_publish'  => 1,
                'auto_sync_on_update'   => 1,
                'auto_delete_on_trash'  => 1,
                'enable_wp_post_sync'   => 1,
                'cdn_url'               => '',
                'sideload_external_img' => 1,
                'auto_featured_image'   => 1,
                'featured_img_position' => 'top',
                'default_post_status'   => 'LIVE',
                'queue_mode'            => 0,
                'max_retries'           => 3,
            );
            add_option('wp_blogger_settings', $default_settings);
        }

        if (false === get_option('wp_blogger_blogs')) {
            add_option('wp_blogger_blogs', array());
        }

        if (false === get_option('wp_blogger_auth')) {
            add_option('wp_blogger_auth', array(
                'access_token'  => '',
                'refresh_token' => '',
                'expires_at'    => 0,
                'user_email'    => '',
                'connected'     => false,
            ));
        }
    }
}
