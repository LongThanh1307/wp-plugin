<?php
/**
 * Chạy khi plugin bị xoá hoàn toàn khỏi WordPress.
 * Xóa tất cả options và post meta của plugin.
 *
 * @package Images_Watermark
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Xoá options
delete_option( 'images_watermark_settings' );

// Xoá post meta khỏi tất cả bài viết
global $wpdb;

$wpdb->delete( $wpdb->postmeta, [ 'meta_key' => '_iw_watermarked' ],       [ '%s' ] );
$wpdb->delete( $wpdb->postmeta, [ 'meta_key' => '_iw_watermarked_count' ], [ '%s' ] );

// Tuỳ chọn: xoá thư mục backup ảnh gốc
// (Bỏ comment nếu muốn xoá backup khi gỡ plugin)
// $upload_dir = wp_upload_dir();
// $backup_dir = $upload_dir['basedir'] . '/iw-originals';
// if ( is_dir( $backup_dir ) ) {
//     $files = new RecursiveIteratorIterator(
//         new RecursiveDirectoryIterator( $backup_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
//         RecursiveIteratorIterator::CHILD_FIRST
//     );
//     foreach ( $files as $file ) {
//         $file->isDir() ? rmdir( $file->getRealPath() ) : unlink( $file->getRealPath() );
//     }
//     rmdir( $backup_dir );
// }
