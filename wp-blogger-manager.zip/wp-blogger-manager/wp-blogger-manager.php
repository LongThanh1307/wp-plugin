<?php
/**
 * Plugin Name: WP Blogger Manager & Sync Hub
 * Plugin URI: https://github.com/wp-blogger-manager
 * Description: Quản lý hệ thống bài viết Blogger (Blogspot) toàn diện từ WordPress: Kết nối nhiều Blog, Tự động đồng bộ bài viết (Thêm/Sửa/Xoá) sang Blogger API v3, và xử lý hình ảnh tối ưu lưu trữ qua WP Media / CDN.
 * Version: 1.0.0
 * Author: Antigravity AI
 * Author URI: https://google.com
 * Text Domain: wp-blogger-manager
 * Domain Path: /languages
 * License: GPL v2 or later
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Plugin constants
define('WP_BLOGGER_VERSION', '1.0.0');
define('WP_BLOGGER_PLUGIN_FILE', __FILE__);
define('WP_BLOGGER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_BLOGGER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WP_BLOGGER_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Load all required class files upfront
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-queue.php';
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-activator.php';
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-deactivator.php';
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-auth.php';
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-api.php';
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-media.php';
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-sync.php';
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-cpt.php';
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-ajax.php';
require_once WP_BLOGGER_PLUGIN_DIR . 'includes/class-blogger-admin.php';

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
final class WP_Blogger_Manager {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Modules
     */
    public $auth;
    public $api;
    public $media;
    public $sync;
    public $queue;
    public $cpt;
    public $ajax;
    public $admin;

    /**
     * Main Instance
     */
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_components();
        $this->init_hooks();
    }

    /**
     * Initialize components
     */
    private function init_components() {
        $this->auth  = new WP_Blogger_Auth();
        $this->api   = new WP_Blogger_API($this->auth);
        $this->media = new WP_Blogger_Media();
        $this->sync  = new WP_Blogger_Sync($this->api, $this->media);
        $this->queue = new WP_Blogger_Queue($this->api, $this->sync);
        $this->cpt   = new WP_Blogger_CPT();
        $this->ajax  = new WP_Blogger_AJAX($this->api, $this->sync, $this->media, $this->auth, $this->queue);
        $this->admin = new WP_Blogger_Admin($this->auth, $this->api, $this->sync, $this->queue);
    }

    /**
     * Register hooks
     */
    private function init_hooks() {
        add_action('plugins_loaded', array($this, 'init_textdomain'));
    }

    /**
     * Internationalization
     */
    public function init_textdomain() {
        load_plugin_textdomain(
            'wp-blogger-manager',
            false,
            dirname(WP_BLOGGER_PLUGIN_BASENAME) . '/languages'
        );
    }
}

/**
 * Plugin activation hook
 */
function activate_wp_blogger_manager() {
    WP_Blogger_Activator::activate();
}
register_activation_hook(__FILE__, 'activate_wp_blogger_manager');

/**
 * Plugin deactivation hook
 */
function deactivate_wp_blogger_manager() {
    WP_Blogger_Deactivator::deactivate();
}
register_deactivation_hook(__FILE__, 'deactivate_wp_blogger_manager');

/**
 * Begins execution of the plugin.
 */
function wp_blogger_manager_init() {
    return WP_Blogger_Manager::instance();
}
add_action('plugins_loaded', 'wp_blogger_manager_init', 5);

