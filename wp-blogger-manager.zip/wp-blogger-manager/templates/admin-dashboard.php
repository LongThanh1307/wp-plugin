<?php
/**
 * Admin Dashboard Template (Multi-Account & Multi-Blogger Support)
 */

if (!defined('ABSPATH')) {
    exit;
}

$accounts_count = is_array($accounts) ? count($accounts) : 0;
$total_blogs    = is_array($blogs) ? count($blogs) : 0;

// Quota data (injected by render_dashboard_page)
if (!isset($quota_data)) {
    $quota_data = array('total' => 0, 'get' => 0, 'write' => 0, 'errors' => 0, 'limit' => 10000, 'remaining' => 10000, 'percent' => 0, 'status' => 'safe', 'last_call' => '');
}
if (!isset($quota_history)) {
    $quota_history = array();
}

// Status color/label mapping
$quota_status_map = array(
    'safe'    => array('color' => '#10b981', 'bg' => '#ecfdf5', 'border' => '#6ee7b7', 'label' => 'An toàn',   'icon' => 'yes-alt'),
    'warning' => array('color' => '#f59e0b', 'bg' => '#fffbeb', 'border' => '#fcd34d', 'label' => 'Cảnh báo', 'icon' => 'warning'),
    'danger'  => array('color' => '#ef4444', 'bg' => '#fef2f2', 'border' => '#fca5a5', 'label' => 'Nguy hiểm','icon' => 'dismiss'),
);
$q_status  = isset($quota_status_map[$quota_data['status']]) ? $quota_status_map[$quota_data['status']] : $quota_status_map['safe'];
$q_percent = min(100, $quota_data['percent']);

global $wpdb;
$table_logs = $wpdb->prefix . 'blogger_sync_logs';
$total_synced_posts  = $wpdb->get_var("SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = '_blogger_sync_status' AND meta_value IN ('synced', 'partial')");
$recent_errors_count = $wpdb->get_var("SELECT COUNT(*) FROM {$table_logs} WHERE status = 'error' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
?>

<div class="wrap wp-blogger-wrap">

    <!-- Header Banner -->
    <div class="wp-blogger-header">
        <div class="wp-blogger-title-group">
            <h1><span class="dashicons dashicons-cloud"></span> <?php esc_html_e('Blogger Manager & Sync Hub', 'wp-blogger-manager'); ?></h1>
            <p><?php esc_html_e('Hệ thống quản lý, phân phối bài viết đa blog Blogger (Blogspot) và tối ưu hóa hình ảnh CDN qua WordPress.', 'wp-blogger-manager'); ?></p>
        </div>
        <div class="wp-blogger-header-actions">
            <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-blogs')); ?>" class="wp-blogger-btn wp-blogger-btn-primary" style="background: #ffffff; color: #ea4335 !important; font-weight: 700;">
                <span class="dashicons dashicons-plus-alt"></span> <?php esc_html_e('Quản lý Tài khoản & Blogs', 'wp-blogger-manager'); ?>
            </a>
        </div>
    </div>

    <!-- Stat Cards Grid -->
    <div class="wp-blogger-grid-4">

        <!-- Stat 1: Connected Google Accounts -->
        <div class="wp-blogger-stat-card">
            <div class="wp-blogger-stat-icon <?php echo $accounts_count > 0 ? 'success' : 'warning'; ?>">
                <span class="dashicons dashicons-google"></span>
            </div>
            <div class="wp-blogger-stat-info">
                <h3><?php echo intval($accounts_count); ?></h3>
                <span><?php esc_html_e('Tài khoản Google kết nối', 'wp-blogger-manager'); ?></span>
            </div>
        </div>

        <!-- Stat 2: Total Connected Blogs -->
        <div class="wp-blogger-stat-card">
            <div class="wp-blogger-stat-icon primary">
                <span class="dashicons dashicons-admin-site-alt3"></span>
            </div>
            <div class="wp-blogger-stat-info">
                <h3><?php echo intval($total_blogs); ?></h3>
                <span><?php esc_html_e('Blogger Blogspot quản lý', 'wp-blogger-manager'); ?></span>
            </div>
        </div>

        <!-- Stat 3: Total Synced Posts -->
        <div class="wp-blogger-stat-card">
            <div class="wp-blogger-stat-icon info">
                <span class="dashicons dashicons-cloud-upload"></span>
            </div>
            <div class="wp-blogger-stat-info">
                <h3><?php echo intval($total_synced_posts); ?></h3>
                <span><?php esc_html_e('Bài viết đã đồng bộ', 'wp-blogger-manager'); ?></span>
            </div>
        </div>

        <!-- Stat 4: Recent Errors -->
        <div class="wp-blogger-stat-card">
            <div class="wp-blogger-stat-icon <?php echo $recent_errors_count > 0 ? 'danger' : 'success'; ?>">
                <span class="dashicons dashicons-warning"></span>
            </div>
            <div class="wp-blogger-stat-info">
                <h3><?php echo intval($recent_errors_count); ?></h3>
                <span><?php esc_html_e('Lỗi trong 7 ngày qua', 'wp-blogger-manager'); ?></span>
            </div>
        </div>

    </div>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">

        <!-- Left Column: Quick Actions & Blogs Overview -->
        <div>

            <!-- Connected Accounts Summary -->
            <div class="wp-blogger-card">
                <div class="wp-blogger-card-header">
                    <h2><span class="dashicons dashicons-admin-users"></span> <?php esc_html_e('Tài khoản Google đã đăng nhập', 'wp-blogger-manager'); ?> (<?php echo intval($accounts_count); ?>)</h2>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-blogs')); ?>" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm">
                        <?php esc_html_e('+ Thêm tài khoản', 'wp-blogger-manager'); ?>
                    </a>
                </div>
                <div class="wp-blogger-card-body">
                    <?php if (!empty($accounts)) : ?>
                        <div style="display: flex; flex-wrap: wrap; gap: 12px;">
                            <?php foreach ($accounts as $acc) : ?>
                                <div style="display: flex; align-items: center; gap: 10px; padding: 8px 14px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 20px;">
                                    <?php if (!empty($acc['user_avatar'])) : ?>
                                        <img src="<?php echo esc_url($acc['user_avatar']); ?>" alt="" style="width: 24px; height: 24px; border-radius: 50%;">
                                    <?php else : ?>
                                        <span class="dashicons dashicons-google" style="color: #ff5722;"></span>
                                    <?php endif; ?>
                                    <span style="font-size: 13px; font-weight: 500;"><?php echo esc_html($acc['user_email']); ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <p style="color: #64748b; margin: 0;"><?php esc_html_e('Chưa có tài khoản nào được kết nối.', 'wp-blogger-manager'); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recent Sync Activity -->
            <div class="wp-blogger-card">
                <div class="wp-blogger-card-header">
                    <h2><span class="dashicons dashicons-list-view"></span> <?php esc_html_e('Nhật ký đồng bộ gần nhất', 'wp-blogger-manager'); ?></h2>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-logs')); ?>" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm">
                        <?php esc_html_e('Xem toàn bộ Logs', 'wp-blogger-manager'); ?> &rarr;
                    </a>
                </div>
                <div class="wp-blogger-card-body" style="padding: 0;">
                    <?php if (!empty($logs)) : ?>
                        <table class="wp-blogger-table">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Thời gian', 'wp-blogger-manager'); ?></th>
                                    <th><?php esc_html_e('Bài viết WP', 'wp-blogger-manager'); ?></th>
                                    <th><?php esc_html_e('Hành động', 'wp-blogger-manager'); ?></th>
                                    <th><?php esc_html_e('Trạng thái', 'wp-blogger-manager'); ?></th>
                                    <th><?php esc_html_e('Nội dung', 'wp-blogger-manager'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($logs as $l) : ?>
                                    <tr>
                                        <td><small style="color: #64748b;"><?php echo esc_html(date_i18n('d/m H:i:s', strtotime($l->created_at))); ?></small></td>
                                        <td>
                                            <?php if ($l->post_id > 0) : ?>
                                                <a href="<?php echo esc_url(get_edit_post_link($l->post_id)); ?>">#<?php echo intval($l->post_id); ?> - <?php echo esc_html(wp_trim_words(get_the_title($l->post_id), 4)); ?></a>
                                            <?php else : ?>
                                                <em>N/A</em>
                                            <?php endif; ?>
                                        </td>
                                        <td><code><?php echo esc_html(strtoupper($l->action)); ?></code></td>
                                        <td>
                                            <span class="wp-blogger-badge <?php echo $l->status === 'success' ? 'success' : 'danger'; ?>">
                                                <?php echo $l->status === 'success' ? esc_html__('Thành công', 'wp-blogger-manager') : esc_html__('Thất bại', 'wp-blogger-manager'); ?>
                                            </span>
                                        </td>
                                        <td><small><?php echo esc_html($l->message); ?></small></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else : ?>
                        <div style="padding: 24px; text-align: center; color: #64748b;">
                            <?php esc_html_e('Chưa có hoạt động đồng bộ nào được ghi nhận.', 'wp-blogger-manager'); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Right Column: Shortcuts & CDN Status -->
        <div>

            <!-- Shortcuts Card -->
            <div class="wp-blogger-card">
                <div class="wp-blogger-card-header">
                    <h2><span class="dashicons dashicons-controls-play"></span> <?php esc_html_e('Phím tắt thao tác', 'wp-blogger-manager'); ?></h2>
                </div>
                <div class="wp-blogger-card-body" style="display: flex; flex-direction: column; gap: 10px;">
                    <a href="<?php echo esc_url(admin_url('post-new.php')); ?>" class="wp-blogger-btn wp-blogger-btn-primary" style="justify-content: flex-start;">
                        <span class="dashicons dashicons-plus-alt"></span> <?php esc_html_e('Đăng bài & Broadcast Blogger', 'wp-blogger-manager'); ?>
                    </a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-sync-hub')); ?>" class="wp-blogger-btn wp-blogger-btn-secondary" style="justify-content: flex-start;">
                        <span class="dashicons dashicons-update"></span> <?php esc_html_e('Trung tâm Đồng bộ bài viết', 'wp-blogger-manager'); ?>
                    </a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-blogs')); ?>" class="wp-blogger-btn wp-blogger-btn-secondary" style="justify-content: flex-start;">
                        <span class="dashicons dashicons-admin-users"></span> <?php esc_html_e('Quản lý Tài khoản & Blogs', 'wp-blogger-manager'); ?>
                    </a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-settings')); ?>" class="wp-blogger-btn wp-blogger-btn-secondary" style="justify-content: flex-start;">
                        <span class="dashicons dashicons-admin-settings"></span> <?php esc_html_e('Cấu hình CDN & Google Client', 'wp-blogger-manager'); ?>
                    </a>
                </div>
            </div>

            <!-- CDN & Media Processing Info -->
            <div class="wp-blogger-card">
                <div class="wp-blogger-card-header">
                    <h2><span class="dashicons dashicons-format-image"></span> <?php esc_html_e('Trạng thái Media & CDN', 'wp-blogger-manager'); ?></h2>
                </div>
                <div class="wp-blogger-card-body">
                    <p style="font-size: 13px; margin: 0 0 12px 0;">
                        <strong><?php esc_html_e('CDN URL:', 'wp-blogger-manager'); ?></strong><br>
                        <?php if (!empty($settings['cdn_url'])) : ?>
                            <code style="color: #10b981; font-weight: 600;"><?php echo esc_html($settings['cdn_url']); ?></code>
                        <?php else : ?>
                            <span style="color: #f59e0b;"><?php esc_html_e('Đang dùng URL gốc WP Media (chưa bật custom CDN)', 'wp-blogger-manager'); ?></span>
                        <?php endif; ?>
                    </p>

                    <p style="font-size: 13px; margin: 0 0 12px 0;">
                        <strong><?php esc_html_e('Tự động tải ảnh ngoại vi (Sideload):', 'wp-blogger-manager'); ?></strong><br>
                        <?php if (!empty($settings['sideload_external_img'])) : ?>
                            <span class="wp-blogger-badge success"><?php esc_html_e('Đang Bật (Tự kéo về WP Media)', 'wp-blogger-manager'); ?></span>
                        <?php else : ?>
                            <span class="wp-blogger-badge muted"><?php esc_html_e('Đang Tắt', 'wp-blogger-manager'); ?></span>
                        <?php endif; ?>
                    </p>

                    <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-settings#media-cdn')); ?>" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm" style="width: 100%;">
                        <span class="dashicons dashicons-edit"></span> <?php esc_html_e('Điều chỉnh thiết lập CDN', 'wp-blogger-manager'); ?>
                    </a>
                </div>
            </div>

            <!-- API Quota Usage Card -->
            <div class="wp-blogger-card" id="wp-blogger-quota-card" style="margin-top: 20px;">
                <div class="wp-blogger-card-header">
                    <h2><span class="dashicons dashicons-chart-bar"></span> <?php esc_html_e('Quota API hôm nay', 'wp-blogger-manager'); ?></h2>
                    <button type="button" id="wp-blogger-refresh-quota" class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm" title="Làm mới">
                        <span class="dashicons dashicons-update" style="margin:0;"></span>
                    </button>
                </div>
                <div class="wp-blogger-card-body" id="wp-blogger-quota-body">

                    <?php
                    // Status banner
                    $q_icon_cls = 'dashicons-' . $q_status['icon'];
                    ?>
                    <!-- Status badge -->
                    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;">
                        <span style="display:inline-flex; align-items:center; gap:5px; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:700;
                                    background:<?php echo esc_attr($q_status['bg']); ?>; color:<?php echo esc_attr($q_status['color']); ?>; border:1px solid <?php echo esc_attr($q_status['border']); ?>;">
                            <span class="dashicons <?php echo esc_attr($q_icon_cls); ?>" style="font-size:14px;width:14px;height:14px;"></span>
                            <?php echo esc_html($q_status['label']); ?>
                        </span>
                        <small style="color:#94a3b8; font-size:11px;" id="wp-blogger-quota-updated">
                            <?php
                            if (!empty($quota_data['last_call'])) {
                                echo esc_html__('Cập nhật:', 'wp-blogger-manager') . ' ' . esc_html(date_i18n('H:i:s', strtotime($quota_data['last_call'])));
                            } else {
                                esc_html_e('Chưa có call nào hôm nay', 'wp-blogger-manager');
                            }
                            ?>
                        </small>
                    </div>

                    <!-- Main numbers -->
                    <div style="text-align:center; margin-bottom:10px;">
                        <div id="wp-blogger-quota-total" style="font-size:32px; font-weight:800; color:<?php echo esc_attr($q_status['color']); ?>; line-height:1;">
                            <?php echo number_format($quota_data['total']); ?>
                        </div>
                        <div style="font-size:12px; color:#64748b; margin-top:2px;">
                            <?php echo esc_html__('/', 'wp-blogger-manager'); ?>
                            <strong id="wp-blogger-quota-limit"><?php echo number_format($quota_data['limit']); ?></strong>
                            <?php esc_html_e('requests/ngày', 'wp-blogger-manager'); ?>
                        </div>
                    </div>

                    <!-- Progress bar -->
                    <div style="background:#e2e8f0; border-radius:999px; height:10px; margin-bottom:6px; overflow:hidden;">
                        <div id="wp-blogger-quota-bar"
                             style="height:100%; border-radius:999px; transition: width 0.6s ease;
                                    width:<?php echo esc_attr($q_percent); ?>%;
                                    background:<?php echo esc_attr($q_status['color']); ?>;">
                        </div>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-size:11px; color:#94a3b8; margin-bottom:14px;">
                        <span id="wp-blogger-quota-percent"><?php echo esc_html($quota_data['percent']); ?>%</span>
                        <span><?php esc_html_e('Còn lại:', 'wp-blogger-manager'); ?> <strong id="wp-blogger-quota-remain" style="color:#1e293b;"><?php echo number_format($quota_data['remaining']); ?></strong></span>
                    </div>

                    <!-- Breakdown mini stats -->
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px; margin-bottom:14px;">
                        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:8px; text-align:center;">
                            <div id="wp-blogger-quota-get" style="font-size:18px; font-weight:700; color:#3b82f6;"><?php echo intval($quota_data['get']); ?></div>
                            <div style="font-size:10px; color:#64748b;">GET</div>
                        </div>
                        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:8px; text-align:center;">
                            <div id="wp-blogger-quota-write" style="font-size:18px; font-weight:700; color:#8b5cf6;"><?php echo intval($quota_data['write']); ?></div>
                            <div style="font-size:10px; color:#64748b;">WRITE</div>
                        </div>
                        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:8px; text-align:center;">
                            <div id="wp-blogger-quota-errors" style="font-size:18px; font-weight:700; color:<?php echo intval($quota_data['errors']) > 0 ? '#ef4444' : '#10b981'; ?>;"><?php echo intval($quota_data['errors']); ?></div>
                            <div style="font-size:10px; color:#64748b;">ERRORS</div>
                        </div>
                    </div>

                    <!-- Rate limit note -->
                    <div style="background:#f1f5f9; border-radius:6px; padding:8px 10px; font-size:11px; color:#64748b; margin-bottom:12px;">
                        ⚡ <?php esc_html_e('Giới hạn tốc độ: 100 requests / 100 giây / IP', 'wp-blogger-manager'); ?><br>
                        🏗️ <?php esc_html_e('Quota tính chung cho toàn bộ Cloud Project (không phân chia theo account)', 'wp-blogger-manager'); ?>
                    </div>

                    <?php if (!empty($quota_history)) : ?>
                    <!-- History table 7 days -->
                    <strong style="display:block; font-size:12px; color:#475569; margin-bottom:6px;">📅 <?php esc_html_e('7 ngày gần nhất:', 'wp-blogger-manager'); ?></strong>
                    <table style="width:100%; border-collapse:collapse; font-size:11px;">
                        <thead>
                            <tr style="background:#f8fafc;">
                                <th style="padding:4px 8px; border:1px solid #e2e8f0; color:#475569; text-align:left;"><?php esc_html_e('Ngày', 'wp-blogger-manager'); ?></th>
                                <th style="padding:4px 8px; border:1px solid #e2e8f0; color:#475569; text-align:center;">Total</th>
                                <th style="padding:4px 8px; border:1px solid #e2e8f0; color:#475569; text-align:center;">GET</th>
                                <th style="padding:4px 8px; border:1px solid #e2e8f0; color:#475569; text-align:center;">Write</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($quota_history as $i => $qh) : ?>
                            <tr style="<?php echo $i === 0 ? 'background:#eff6ff; font-weight:600;' : ($i % 2 === 0 ? '' : 'background:#f8fafc;'); ?>">
                                <td style="padding:4px 8px; border:1px solid #e2e8f0;">
                                    <?php echo esc_html(date_i18n('d/m', strtotime($qh['date']))); ?>
                                    <?php if ($i === 0) : ?><small style="color:#3b82f6;"> (hôm nay)</small><?php endif; ?>
                                </td>
                                <td style="padding:4px 8px; border:1px solid #e2e8f0; text-align:center;">
                                    <?php echo number_format($qh['total']); ?>
                                </td>
                                <td style="padding:4px 8px; border:1px solid #e2e8f0; text-align:center; color:#3b82f6;"><?php echo number_format($qh['get']); ?></td>
                                <td style="padding:4px 8px; border:1px solid #e2e8f0; text-align:center; color:#8b5cf6;"><?php echo number_format($qh['write']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>

                    <a href="https://console.cloud.google.com/apis/api/blogger.googleapis.com/quotas" target="_blank"
                       class="wp-blogger-btn wp-blogger-btn-secondary wp-blogger-btn-sm" style="margin-top:12px; display:inline-flex; align-items:center; gap:5px; font-size:11px; text-decoration:none; width:100%; justify-content:center;">
                        <span class="dashicons dashicons-external" style="font-size:13px;width:13px;height:13px;"></span>
                        <?php esc_html_e('Xem & Tăng Quota — Google Cloud', 'wp-blogger-manager'); ?>
                    </a>

                </div>
            </div>

        </div>

    </div>

</div>

<script>
(function($) {
    'use strict';

    var QUOTA_LIMIT = <?php echo intval(WP_Blogger_API::QUOTA_DAILY_MAX); ?>;
    var statusMap   = {
        safe:    { color: '#10b981', label: 'An toàn',    icon: 'dashicons-yes-alt',  bg: '#ecfdf5', border: '#6ee7b7' },
        warning: { color: '#f59e0b', label: 'Cảnh báo',  icon: 'dashicons-warning',  bg: '#fffbeb', border: '#fcd34d' },
        danger:  { color: '#ef4444', label: 'Nguy hiểm', icon: 'dashicons-dismiss',  bg: '#fef2f2', border: '#fca5a5' },
    };

    function refreshQuota() {
        var $btn = $('#wp-blogger-refresh-quota .dashicons');
        $btn.css({ animation: 'spin 1s linear infinite' });

        $.post(wpBloggerData.ajaxUrl, {
            action: 'wp_blogger_get_quota',
            nonce:  wpBloggerData.nonce,
        }, function(res) {
            if (!res.success) return;
            var q = res.data.quota;
            var s = statusMap[q.status] || statusMap['safe'];

            // Update numbers
            $('#wp-blogger-quota-total').text(q.total.toLocaleString()).css('color', s.color);
            $('#wp-blogger-quota-limit').text(QUOTA_LIMIT.toLocaleString());
            $('#wp-blogger-quota-percent').text(q.percent + '%');
            $('#wp-blogger-quota-remain').text(q.remaining.toLocaleString());
            $('#wp-blogger-quota-get').text(q.get);
            $('#wp-blogger-quota-write').text(q.write);
            $('#wp-blogger-quota-errors').text(q.errors).css('color', q.errors > 0 ? '#ef4444' : '#10b981');

            // Progress bar
            var pct = Math.min(100, q.percent);
            $('#wp-blogger-quota-bar').css({ width: pct + '%', background: s.color });

            // Timestamp
            var ts = q.last_call ? ('Cập nhật: ' + q.last_call.substr(11, 8)) : 'Chưa có call nào hôm nay';
            $('#wp-blogger-quota-updated').text(ts);
        }).always(function() {
            $btn.css({ animation: '' });
        });
    }

    // Button click
    $('#wp-blogger-refresh-quota').on('click', refreshQuota);

    // Auto-refresh every 60 seconds
    setInterval(refreshQuota, 60000);

})(jQuery);
</script>
