<?php
/**
 * Handles Multiple Google Accounts OAuth 2.0 & Token Lifecycles
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Blogger_Auth {

    const AUTH_URL     = 'https://accounts.google.com/o/oauth2/v2/auth';
    const TOKEN_URL    = 'https://oauth2.googleapis.com/token';
    const USERINFO_URL = 'https://www.googleapis.com/oauth2/v2/userinfo';
    const SCOPES       = 'https://www.googleapis.com/auth/blogger https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile';

    /**
     * Get OAuth Redirect URI
     */
    public function get_redirect_uri() {
        return admin_url('admin.php?page=wp-blogger-blogs&action=oauth_callback');
    }

    /**
     * Get all connected Google accounts
     * @return array [ account_id => account_data, ... ]
     */
    public function get_accounts() {
        $accounts = get_option('wp_blogger_accounts', array());

        // Migrate legacy single-account data if exists
        if (empty($accounts)) {
            $legacy = get_option('wp_blogger_auth', array());
            if (!empty($legacy['connected']) && !empty($legacy['refresh_token'])) {
                $acc_id = !empty($legacy['user_email']) ? sanitize_key($legacy['user_email']) : 'default_account';
                $accounts[$acc_id] = array(
                    'account_id'    => $acc_id,
                    'user_email'    => isset($legacy['user_email']) ? $legacy['user_email'] : '',
                    'user_name'     => isset($legacy['user_name']) ? $legacy['user_name'] : $legacy['user_email'],
                    'user_avatar'   => isset($legacy['user_avatar']) ? $legacy['user_avatar'] : '',
                    'access_token'  => $legacy['access_token'],
                    'refresh_token' => $legacy['refresh_token'],
                    'expires_at'    => $legacy['expires_at'],
                    'connected_at'  => isset($legacy['connected_at']) ? $legacy['connected_at'] : current_time('mysql'),
                );
                update_option('wp_blogger_accounts', $accounts);
            }
        }

        return is_array($accounts) ? $accounts : array();
    }

    /**
     * Get specific Google account by ID or email
     */
    public function get_account($account_id) {
        $accounts = $this->get_accounts();
        if (isset($accounts[$account_id])) {
            return $accounts[$account_id];
        }

        // Search by email
        foreach ($accounts as $acc) {
            if (!empty($acc['user_email']) && strcasecmp($acc['user_email'], $account_id) === 0) {
                return $acc;
            }
        }

        // Return first account if only 1 exists and account_id is empty
        if (empty($account_id) && count($accounts) === 1) {
            return reset($accounts);
        }

        return false;
    }

    /**
     * Check if at least one Google account is connected
     */
    public function is_connected() {
        $accounts = $this->get_accounts();
        return !empty($accounts);
    }

    /**
     * Generate Google OAuth Authorization URL
     */
    public function get_auth_url() {
        $settings  = get_option('wp_blogger_settings', array());
        $client_id = !empty($settings['client_id']) ? trim($settings['client_id']) : '';

        if (empty($client_id)) {
            return false;
        }

        $state = wp_create_nonce('wp_blogger_oauth_state');

        $params = array(
            'client_id'             => $client_id,
            'redirect_uri'          => $this->get_redirect_uri(),
            'response_type'         => 'code',
            'scope'                 => self::SCOPES,
            'access_type'           => 'offline',
            'prompt'                => 'consent select_account', // Allow switching/selecting accounts
            'include_granted_scopes'=> 'true',
            'state'                 => $state,
        );

        return self::AUTH_URL . '?' . http_build_query($params);
    }

    /**
     * Handle OAuth Callback and exchange Code for Tokens
     */
    public function handle_callback($code, $state) {
        if (!wp_verify_nonce($state, 'wp_blogger_oauth_state')) {
            return new WP_Error('invalid_state', __('Xác thực bảo mật nonce thất bại. Vui lòng thử kết nối lại.', 'wp-blogger-manager'));
        }

        $settings      = get_option('wp_blogger_settings', array());
        $client_id     = !empty($settings['client_id']) ? trim($settings['client_id']) : '';
        $client_secret = !empty($settings['client_secret']) ? trim($settings['client_secret']) : '';

        if (empty($client_id) || empty($client_secret)) {
            return new WP_Error('missing_keys', __('Vui lòng nhập Client ID và Client Secret trước khi kết nối.', 'wp-blogger-manager'));
        }

        $body = array(
            'code'          => $code,
            'client_id'     => $client_id,
            'client_secret' => $client_secret,
            'redirect_uri'  => $this->get_redirect_uri(),
            'grant_type'    => 'authorization_code',
        );

        $response = wp_remote_post(self::TOKEN_URL, array(
            'timeout'   => 30,
            'sslverify' => true,
            'body'      => $body,
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $response_body = wp_remote_retrieve_body($response);
        $data = json_decode($response_body, true);

        if (!empty($data['error'])) {
            $desc = !empty($data['error_description']) ? $data['error_description'] : $data['error'];
            return new WP_Error('oauth_error', sprintf(__('Lỗi Google OAuth: %s', 'wp-blogger-manager'), $desc));
        }

        if (empty($data['access_token'])) {
            return new WP_Error('no_access_token', __('Không nhận được Access Token từ Google.', 'wp-blogger-manager'));
        }

        // Fetch User Info (Email, ID, Name, Avatar)
        $user_info = $this->fetch_user_info($data['access_token']);
        $email     = !empty($user_info['email']) ? $user_info['email'] : '';
        $acc_id    = !empty($user_info['id']) ? sanitize_key($user_info['id']) : sanitize_key($email);

        if (empty($acc_id)) {
            $acc_id = 'account_' . time();
        }

        $accounts = $this->get_accounts();
        $refresh_token = !empty($data['refresh_token']) ? $data['refresh_token'] : (isset($accounts[$acc_id]['refresh_token']) ? $accounts[$acc_id]['refresh_token'] : '');

        if (empty($refresh_token)) {
            return new WP_Error('no_refresh_token', __('Không nhận được Refresh Token. Vui lòng ngắt kết nối và cấp quyền lại.', 'wp-blogger-manager'));
        }

        $expires_in = isset($data['expires_in']) ? intval($data['expires_in']) : 3600;
        $expires_at = time() + $expires_in - 60;

        $accounts[$acc_id] = array(
            'account_id'    => $acc_id,
            'user_email'    => sanitize_email($email),
            'user_name'     => isset($user_info['name']) ? sanitize_text_field($user_info['name']) : $email,
            'user_avatar'   => isset($user_info['picture']) ? esc_url_raw($user_info['picture']) : '',
            'access_token'  => sanitize_text_field($data['access_token']),
            'refresh_token' => sanitize_text_field($refresh_token),
            'expires_at'    => $expires_at,
            'connected_at'  => current_time('mysql'),
        );

        update_option('wp_blogger_accounts', $accounts);

        return $acc_id;
    }

    /**
     * Fetch user profile info from Google
     */
    private function fetch_user_info($access_token) {
        $response = wp_remote_get(self::USERINFO_URL, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $access_token,
            ),
            'timeout' => 15,
        ));

        if (!is_wp_error($response)) {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            if (is_array($data)) {
                return $data;
            }
        }
        return array();
    }

    /**
     * Get a valid Access Token for a specific account (or first available)
     */
    public function get_valid_access_token($account_id = '') {
        $account = $this->get_account($account_id);

        if (!$account || empty($account['refresh_token'])) {
            return new WP_Error('not_connected', sprintf(__('Tài khoản Google (%s) chưa được kết nối hoặc thiếu token.', 'wp-blogger-manager'), $account_id));
        }

        // Check if access token is still valid
        if (!empty($account['access_token']) && !empty($account['expires_at']) && time() < $account['expires_at']) {
            return $account['access_token'];
        }

        // Refresh token
        return $this->refresh_access_token($account['account_id']);
    }

    /**
     * Refresh Access Token for specific account
     */
    public function refresh_access_token($account_id) {
        $accounts = $this->get_accounts();
        $account  = isset($accounts[$account_id]) ? $accounts[$account_id] : false;
        $settings = get_option('wp_blogger_settings', array());

        $client_id     = !empty($settings['client_id']) ? trim($settings['client_id']) : '';
        $client_secret = !empty($settings['client_secret']) ? trim($settings['client_secret']) : '';

        if (!$account || empty($account['refresh_token'])) {
            return new WP_Error('missing_account', __('Không tìm thấy thông tin tài khoản Google để làm mới Token.', 'wp-blogger-manager'));
        }

        if (empty($client_id) || empty($client_secret)) {
            return new WP_Error('missing_credentials', __('Thiếu Google Client ID hoặc Client Secret.', 'wp-blogger-manager'));
        }

        $body = array(
            'client_id'     => $client_id,
            'client_secret' => $client_secret,
            'refresh_token' => $account['refresh_token'],
            'grant_type'    => 'refresh_token',
        );

        $response = wp_remote_post(self::TOKEN_URL, array(
            'timeout'   => 30,
            'sslverify' => true,
            'body'      => $body,
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $response_body = wp_remote_retrieve_body($response);
        $data = json_decode($response_body, true);

        if (!empty($data['error'])) {
            $desc = !empty($data['error_description']) ? $data['error_description'] : $data['error'];
            return new WP_Error('refresh_error', sprintf(__('Lỗi làm mới Token (%s): %s', 'wp-blogger-manager'), $account['user_email'], $desc));
        }

        if (empty($data['access_token'])) {
            return new WP_Error('no_new_token', __('Không nhận được Access Token mới từ Google.', 'wp-blogger-manager'));
        }

        $expires_in = isset($data['expires_in']) ? intval($data['expires_in']) : 3600;
        $accounts[$account_id]['access_token'] = sanitize_text_field($data['access_token']);
        $accounts[$account_id]['expires_at']   = time() + $expires_in - 60;

        if (!empty($data['refresh_token'])) {
            $accounts[$account_id]['refresh_token'] = sanitize_text_field($data['refresh_token']);
        }

        update_option('wp_blogger_accounts', $accounts);

        return $accounts[$account_id]['access_token'];
    }

    /**
     * Remove / Disconnect a single Google Account
     */
    public function remove_account($account_id) {
        $accounts = $this->get_accounts();
        if (isset($accounts[$account_id])) {
            unset($accounts[$account_id]);
            update_option('wp_blogger_accounts', $accounts);

            // Also clean blogs belonging to this account
            $blogs = get_option('wp_blogger_blogs', array());
            $new_blogs = array();
            foreach ($blogs as $b_id => $b_data) {
                if (isset($b_data['account_id']) && $b_data['account_id'] === $account_id) {
                    continue;
                }
                $new_blogs[$b_id] = $b_data;
            }
            update_option('wp_blogger_blogs', $new_blogs);
            return true;
        }
        return false;
    }
}
