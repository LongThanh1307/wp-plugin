# WP Blogger Manager & Sync Hub

> **Plugin WordPress** chuyên dụng để quản lý và đồng bộ bài viết lên hệ thống Blogger (Blogspot) thông qua **Google Blogger API v3**.  
> Phiên bản: **1.0.0** | Requires WP: **5.8+** | Requires PHP: **7.4+**

---

## Triết lý thiết kế

Plugin hoạt động hoàn toàn **độc lập với bài viết WordPress thông thường (post type: post)**.  
Không có metabox, không có cột sync, không có hook nào được thêm vào WP Posts gốc.  
Tất cả nội dung dành cho Blogger được quản lý riêng qua **Custom Post Type `blogger_post`**.

```
WP Posts (post)          ←  KHÔNG bị đụng chạm
Blogger Posts (blogger_post)  ←  Quản lý bởi plugin, đồng bộ lên Blogspot
```

---

## Tính năng chính

### 1. Kết nối Nhiều Tài khoản Google (Multi-Account)
- Đăng nhập **không giới hạn** tài khoản Google qua OAuth 2.0
- Mỗi tài khoản quản lý độc lập danh sách Blog Blogger của nó
- **Auto Refresh Token** — không bao giờ mất kết nối
- Ngắt kết nối từng tài khoản linh hoạt, làm mới danh sách blog 1-click

### 2. Quản lý Blogger Posts — Hoàn toàn tách biệt WP Posts
- Custom Post Type riêng: `blogger_post` (hiển thị trong menu "Blogger Posts")
- Editor đầy đủ: tiêu đề, nội dung, ảnh đại diện, excerpt, custom fields
- Taxonomy riêng: `blogger_label` (Nhãn Blogger) — chỉ dùng cho blogger_post
- **Cột danh sách trực quan:** "Blogger đã đăng" (tên blog kèm link xem trực tiếp trên Blogger), "Trạng thái Sync", "Nhãn Blogger"
- **Bộ lọc mạnh mẽ:** Lọc theo từng Blogger (Blogspot) cụ thể, lọc bài đã đăng hoặc chưa đăng, lọc theo trạng thái sync (hỗ trợ cả màn hình `edit.php?post_type=blogger_post` và Trung tâm Đồng bộ Sync Hub)
- Metabox "Đồng bộ Google Blogger" chỉ xuất hiện trên blogger_post editor

### 3. Đồng bộ Linh hoạt (Push to Blogger)
Mỗi bài Blogger có thể được cấu hình 3 chế độ sync:

| Chế độ | Hành vi |
|---|---|
| `none` | Không đồng bộ — mặc định cho bài mới |
| `selected` | Chỉ đồng bộ lên các Blog đã tick chọn |
| `all` | Broadcast đến TẤT CẢ Blog đang active |

**Thao tác tự động (có thể bật/tắt trong Settings):**
- Publish bài → Tự động đẩy lên Blogger
- Update bài → Tự động cập nhật trên Blogger
- Trash bài → Tự động xóa trên Blogger

**Fallback an toàn:** Nếu bài bị xóa thủ công trên Blogger (trả về 404), hệ thống tự tạo lại thay vì báo lỗi.

### 4. Copy từ WP Posts sang Blogger Posts
Workflow một chiều: WP Post → Blogger Post (không có chiều ngược lại)

**Các field được copy:**
| Field | Nguồn |
|---|---|
| Tiêu đề | `post_title` |
| Nội dung | `post_content` (raw) |
| Ảnh đại diện | `featured image` (attachment ID) |
| SEO Title | `rank_math_title` → `_yoast_wpseo_title` |
| SEO Description | `rank_math_description` → `_yoast_wpseo_metadesc` |
| Slug | `post_name` + suffix `-blogger` |
| Excerpt | `post_excerpt` |

**Các field KHÔNG được copy:** Categories, Tags, Author, Custom Fields khác

Bài sau khi copy: `post_type = blogger_post`, `post_status = draft`, `sync_mode = none`  
Bài WP gốc **không bị thay đổi gì**.

### 5. Xử lý Hình ảnh & CDN
- Rewrite tất cả URL ảnh trong nội dung sang CDN domain (Cloudflare R2, BunnyCDN, S3...)
- Auto-sideload ảnh hotlink từ domain ngoài → lưu vào WP Media Library
- Tự động đặt ảnh đại diện đầu bài

### 6. Theo dõi Quota API
- Tự động đếm số API request mỗi ngày (GET / WRITE / Errors)
- Lưu lịch sử 7 ngày vào wp_options
- Dashboard card hiển thị progress bar, cảnh báo khi gần giới hạn
- **Giới hạn:** 10,000 requests/ngày và 100 requests/100 giây (tính theo Google Cloud Project)
- Auto-refresh mỗi 60 giây qua AJAX

### 7. Queue & Retry Engine
- Đồng bộ hàng loạt không block giao diện
- Tự động retry khi gặp lỗi tạm thời (tối đa N lần, cấu hình được)
- Theo dõi trạng thái queue realtime

---

## Cấu trúc File

```
wp-blogger-manager/
├── wp-blogger-manager.php          # Entry point, singleton loader
├── includes/
│   ├── class-blogger-activator.php # Tạo bảng DB khi kích hoạt plugin
│   ├── class-blogger-deactivator.php
│   ├── class-blogger-auth.php      # OAuth 2.0, quản lý token đa tài khoản
│   ├── class-blogger-api.php       # Blogger API v3 client + quota tracking
│   ├── class-blogger-media.php     # Xử lý ảnh, CDN rewrite, sideload
│   ├── class-blogger-sync.php      # Engine đồng bộ + copy WP→CPT
│   ├── class-blogger-cpt.php       # Đăng ký blogger_post CPT + blogger_label taxonomy
│   ├── class-blogger-ajax.php      # Tất cả AJAX handlers
│   ├── class-blogger-admin.php     # Render trang admin, save settings
│   └── class-blogger-queue.php     # Queue & retry engine
├── templates/
│   ├── admin-dashboard.php         # Tổng quan + Quota card
│   ├── admin-sync-hub.php          # Tab 1: Blogger Posts | Tab 2: Copy từ WP
│   ├── admin-accounts.php          # Quản lý tài khoản Google
│   ├── admin-settings.php          # Cấu hình plugin
│   ├── admin-logs.php              # Nhật ký đồng bộ
│   └── metabox-sync.php            # Metabox trên blogger_post editor
└── assets/
    ├── css/admin-style.css
    └── js/admin-script.js
```

---

## Database

### `{prefix}_blogger_sync_logs`
Ghi lại mọi thao tác sync:

| Cột | Kiểu | Mô tả |
|---|---|---|
| `post_id` | INT | WP Post ID |
| `blog_id` | VARCHAR | Blogger Blog ID |
| `blogger_post_id` | VARCHAR | ID bài trên Blogger |
| `action` | VARCHAR | create / update / delete / preview |
| `status` | VARCHAR | success / error |
| `message` | TEXT | Chi tiết |
| `created_at` | DATETIME | Thời điểm |

### wp_options (Quota tracking)
- `wp_blogger_quota_YYYY-MM-DD` — Dữ liệu quota ngày hiện tại (tự xóa sau 8 ngày)
- `wp_blogger_accounts` — Danh sách tài khoản Google đã kết nối
- `wp_blogger_blogs` — Danh sách Blog Blogger đã đăng ký
- `wp_blogger_settings` — Cấu hình plugin

### Post Meta (trên `blogger_post`)
| Meta Key | Mô tả |
|---|---|
| `_blogger_sync_mode` | `none` / `selected` / `all` |
| `_blogger_selected_blogs` | Array blog IDs được chọn |
| `_blogger_synced_blogs` | Map blog_id → { blogger_post_id, url, status, synced_at } |
| `_blogger_synced_blog_id` | Từng blog_id đã sync thành công (lưu theo từng row để đánh index lọc nhanh) |
| `_blogger_sync_status` | `synced` / `partial` / `error` / `deleted` / `` |
| `_blogger_sync_error` | Thông báo lỗi cuối |
| `_blogger_synced_at` | Thời điểm sync gần nhất |
| `_blogger_post_id` | Primary Blogger post ID |
| `_blogger_url` | URL bài trên Blogger |
| `_blogger_seo_title` | SEO title (copy từ WP) |
| `_blogger_seo_desc` | SEO description (copy từ WP) |
| `_blogger_copied_from_wp_id` | WP post ID nguồn (nếu bài được copy) |
| `_blogger_copied_at` | Thời điểm copy |

---

## Luồng đồng bộ

### Blogger Post → Blogger (Push)
```
Save blogger_post (Publish/Update)
  ↓ save_post_blogger_post hook
  ↓ resolve_target_blogs() → xác định blog nào nhận bài
  ↓ media->process_content_for_blogger() → rewrite ảnh sang CDN
  ↓ get_post_labels() → blogger_label taxonomy → Blogger Labels
  ↓ foreach blog:
      has _blogger_synced_blogs[blog_id]?
        YES → api->update_post()
          404? → fallback: api->insert_post()
        NO  → api->insert_post()
  ↓ Lưu _blogger_synced_blogs, _blogger_sync_status
```

### WP Post → Blogger Post (Copy)
```
User chọn WP posts trong Sync Hub Tab 2
  ↓ AJAX: wp_blogger_copy_to_cpt
  ↓ sync->copy_wp_posts_to_cpt([post_ids])
  ↓ foreach post_id:
      Đọc: title, content, excerpt, slug
      Đọc SEO: rank_math_title / _yoast_wpseo_title
      Đọc: featured image attachment ID
      wp_insert_post(post_type=blogger_post, status=draft)
      set_post_thumbnail()
      Lưu SEO meta, sync_mode=none, sync_status=''
  ↓ Trả về { copied, skipped, ids }
```

### Xóa trên Blogger
```
Trash/Delete blogger_post (hoặc AJAX thủ công)
  ↓ delete_blogger_posts(post_id)
  ↓ Đọc _blogger_synced_blogs
  ↓ foreach synced_blog: api->delete_post()
  ↓ Xóa meta, cập nhật _blogger_sync_status = deleted
```

---

## AJAX Actions

| Action | Mô tả |
|---|---|
| `wp_blogger_sync_post` | Đồng bộ 1 bài lên Blogger |
| `wp_blogger_bulk_sync` | Đồng bộ nhiều bài cùng lúc |
| `wp_blogger_copy_to_cpt` | Copy WP posts sang blogger_post CPT |
| `wp_blogger_delete_from_blogger` | Xóa bài khỏi Blogger |
| `wp_blogger_get_quota` | Lấy dữ liệu quota realtime |
| `wp_blogger_get_accounts` | Lấy danh sách tài khoản |
| `wp_blogger_disconnect_account` | Ngắt kết nối 1 tài khoản |
| `wp_blogger_fetch_blogs` | Làm mới danh sách blog |
| `wp_blogger_save_blogs_config` | Lưu cấu hình blog |
| `wp_blogger_clear_logs` | Xóa nhật ký |
| `wp_blogger_schedule_broadcast` | Lên lịch broadcast |
| `wp_blogger_queue_status` | Trạng thái queue |

---

## Giới hạn Blogger API

| Loại giới hạn | Giá trị |
|---|---|
| Requests/ngày | 10,000 (tính theo Cloud Project) |
| Requests/100 giây | 100 (tính theo IP) |
| Phạm vi tính | Toàn bộ Cloud Project — không phân chia theo account hay blog |

> **Lưu ý:** Quota tracking trong plugin là ước tính dựa trên số lần gọi hàm `request()` nội bộ. Google không cung cấp API để truy vấn quota thực tế đã dùng theo thời gian thực.

---

## Cài đặt

### Yêu cầu
- WordPress 5.8+
- PHP 7.4+
- Google Cloud Project với Blogger API v3 được bật
- OAuth 2.0 Client ID & Secret

### Cấu hình Google Cloud
1. Vào [Google Cloud Console](https://console.cloud.google.com/)
2. Tạo Project → Bật **Blogger API v3**
3. Tạo **OAuth 2.0 Client ID** (loại: Web application)
4. Thêm Authorized redirect URI: `https://your-domain.com/wp-admin/admin.php?page=wp-blogger-accounts`
5. Sao chép **Client ID** và **Client Secret**

### Cài Plugin
1. Upload thư mục `wp-blogger-manager` vào `/wp-content/plugins/`
2. Kích hoạt plugin trong WordPress Admin → Plugins
3. Vào **Blogger Manager → Cài đặt** → Điền Client ID & Secret
4. Vào **Blogger Manager → Tài khoản** → Kết nối tài khoản Google

---

## Changelog

### v1.0.0
- Kiến trúc hoàn toàn tách biệt: Blogger Posts độc lập khỏi WP Posts
- Xóa tính năng Pull/Import từ Blogger về WP
- Thêm workflow Copy WP Posts → Blogger Posts CPT (1 chiều, độc lập)
- Dashboard Quota card với realtime tracking
- Multi-account OAuth với auto-refresh token
- Queue & retry engine cho bulk sync
- CDN rewrite engine cho hình ảnh
- Taxonomy `blogger_label` riêng cho `blogger_post`
