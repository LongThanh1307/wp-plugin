/**
 * WP Blogger Manager - Admin JavaScript (Multi-Account & Multi-Blogger Broadcast Support)
 */

(function ($) {
    'use strict';

    $(document).ready(function () {

        // 1. Copy Redirect URI to Clipboard
        $('#wp-blogger-copy-btn').on('click', function (e) {
            e.preventDefault();
            var copyText = document.getElementById('wp-blogger-redirect-uri');
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand('copy');

            var $btn = $(this);
            var originalHtml = $btn.html();
            $btn.html('<span class="dashicons dashicons-yes"></span> ' + (wpBloggerData.strings.copied || 'Đã chép!'));
            setTimeout(function () {
                $btn.html(originalHtml);
            }, 2000);
        });

        // 2. Test API Connection
        $('#wp-blogger-test-api-btn').on('click', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var $status = $('#wp-blogger-api-test-status');

            $btn.prop('disabled', true).addClass('loading');
            $status.html('<span class="spinner is-active" style="float:none; margin:0 5px 0 0;"></span> ' + wpBloggerData.strings.testing).show();

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_test_api',
                nonce: wpBloggerData.nonce
            }, function (response) {
                $btn.prop('disabled', false).removeClass('loading');
                if (response.success) {
                    $status.html('<div class="wp-blogger-alert success" style="margin-top:10px;"><span class="dashicons dashicons-yes-alt"></span> ' + response.data.message + '</div>');
                } else {
                    $status.html('<div class="wp-blogger-alert error" style="margin-top:10px;"><span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi kết nối') + '</div>');
                }
            }).fail(function () {
                $btn.prop('disabled', false).removeClass('loading');
                $status.html('<div class="wp-blogger-alert error" style="margin-top:10px;"><span class="dashicons dashicons-warning"></span> Lỗi máy chủ kết nối AJAX.</div>');
            });
        });

        // 3. Refresh Blogs from Google across all accounts
        $('#wp-blogger-refresh-blogs-btn').on('click', function (e) {
            e.preventDefault();
            var $btn = $(this);
            $btn.prop('disabled', true);

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_fetch_blogs',
                nonce: wpBloggerData.nonce
            }, function (response) {
                if (response.success) {
                    alert(response.data.message);
                    window.location.reload();
                } else {
                    alert(response.data.message || 'Lỗi làm mới danh sách blog.');
                    $btn.prop('disabled', false);
                }
            }).fail(function () {
                alert('Lỗi kết nối máy chủ.');
                $btn.prop('disabled', false);
            });
        });

        // 4. Disconnect a single Google Account
        $(document).on('click', '.wp-blogger-disconnect-acc-btn', function (e) {
            e.preventDefault();
            if (!confirm(wpBloggerData.strings.confirmDisconnectAccount || 'Bạn có chắc muốn ngắt kết nối tài khoản Google này?')) {
                return;
            }

            var $btn = $(this);
            var accId = $btn.data('account-id');
            $btn.prop('disabled', true);

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_disconnect_account',
                account_id: accId,
                nonce: wpBloggerData.nonce
            }, function (response) {
                if (response.success) {
                    window.location.reload();
                } else {
                    alert(response.data.message || 'Không thể ngắt kết nối tài khoản.');
                    $btn.prop('disabled', false);
                }
            });
        });

        // 5. Toggle Blog Active in Broadcast Pool
        $(document).on('change', '.wp-blogger-toggle-active-btn', function () {
            var $checkbox = $(this);
            var blogId = $checkbox.data('blog-id');
            var isActive = $checkbox.is(':checked') ? 1 : 0;

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_toggle_blog_active',
                blog_id: blogId,
                is_active: isActive,
                nonce: wpBloggerData.nonce
            });
        });

        // 6. Metabox Sync Mode Radio Switcher
        $('.wp-blogger-sync-mode-radio').on('change', function () {
            var mode = $('input[name="wp_blogger_sync_mode"]:checked').val();
            if (mode === 'selected') {
                $('#wp-blogger-specific-blogs-wrap').slideDown(200);
            } else {
                $('#wp-blogger-specific-blogs-wrap').slideUp(200);
            }
        });

        // 7. 1-Click Sync in Metabox (Post Edit Screen)
        $('#wp-blogger-metabox-sync-btn').on('click', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var postId = $btn.data('post-id');
            var syncMode = $('input[name="wp_blogger_sync_mode"]:checked').val() || 'all';

            var selectedBlogs = [];
            $('input[name="wp_blogger_selected_blogs[]"]:checked').each(function () {
                selectedBlogs.push($(this).val());
            });

            var $statusBox = $('#wp-blogger-metabox-status');

            $btn.prop('disabled', true);
            $statusBox.html('<div class="wp-blogger-badge warning"><span class="spinner is-active" style="float:none; margin:0 4px 0 0;"></span> ' + wpBloggerData.strings.syncing + '</div>');

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_sync_single',
                post_id: postId,
                sync_mode: syncMode,
                selected_blogs: selectedBlogs,
                nonce: wpBloggerData.nonce
            }, function (response) {
                $btn.prop('disabled', false);
                if (response.success) {
                    var html = '<div class="wp-blogger-alert success" style="margin-top:6px; font-size:12px; padding:8px 10px;"><span class="dashicons dashicons-yes-alt"></span> ' + (response.data.message || 'Đồng bộ hoàn tất') + '</div>';
                    $statusBox.html(html);
                    setTimeout(function() {
                        window.location.reload();
                    }, 1500);
                } else {
                    $statusBox.html('<div class="wp-blogger-alert error" style="margin-top:6px; font-size:12px; padding:8px 10px;"><span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi đồng bộ') + '</div>');
                }
            }).fail(function () {
                $btn.prop('disabled', false);
                $statusBox.html('<div class="wp-blogger-alert error" style="margin-top:6px; font-size:12px; padding:8px 10px;"><span class="dashicons dashicons-warning"></span> Lỗi AJAX máy chủ.</div>');
            });
        });

        // 8. Quick Sync from Posts List Table
        $(document).on('click', '.wp-blogger-quick-sync-btn', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var postId = $btn.data('post-id');
            var $parent = $btn.closest('td');

            $btn.text(wpBloggerData.strings.syncing).css('opacity', '0.6');

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_sync_single',
                post_id: postId,
                nonce: wpBloggerData.nonce
            }, function (response) {
                if (response.success) {
                    $parent.html('<div class="wp-blogger-col-status synced"><span class="wp-blogger-badge success"><span class="dashicons dashicons-yes-alt"></span> ' + (response.data.message || 'Đã đồng bộ') + '</span></div>');
                } else {
                    alert(response.data.message || 'Lỗi đồng bộ bài viết.');
                    $btn.html('<span class="dashicons dashicons-update"></span> Thử lại').css('opacity', '1');
                }
            });
        });

        // 9. Bulk Sync Posts in Sync Hub
        $('#wp-blogger-bulk-sync-btn').on('click', function (e) {
            e.preventDefault();
            var selectedPosts = [];
            $('.wp-blogger-post-checkbox:checked').each(function () {
                selectedPosts.push($(this).val());
            });

            if (selectedPosts.length === 0) {
                alert('Vui lòng tích chọn ít nhất 1 bài viết để đồng bộ.');
                return;
            }

            var $btn = $(this);
            var $progress = $('#wp-blogger-sync-progress');
            var $progressBar = $progress.find('.wp-blogger-progress-bar');
            var $resultBox = $('#wp-blogger-bulk-result');

            $btn.prop('disabled', true);
            $progress.show();
            $progressBar.css('width', '50%');
            $resultBox.html('<div class="wp-blogger-alert info">' + wpBloggerData.strings.syncing + ' (' + selectedPosts.length + ' bài viết)</div>');

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_bulk_sync',
                post_ids: selectedPosts,
                nonce: wpBloggerData.nonce
            }, function (response) {
                $progressBar.css('width', '100%');
                $btn.prop('disabled', false);

                if (response.success) {
                    var html = '<div class="wp-blogger-alert success"><span class="dashicons dashicons-yes-alt"></span> ' + response.data.message + '</div>';
                    if (response.data.errors && response.data.errors.length > 0) {
                        html += '<div class="wp-blogger-alert error"><strong>Chi tiết lỗi:</strong><br>' + response.data.errors.join('<br>') + '</div>';
                    }
                    $resultBox.html(html);
                } else {
                    $resultBox.html('<div class="wp-blogger-alert error"><span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi đồng bộ.') + '</div>');
                }
            }).fail(function () {
                $btn.prop('disabled', false);
                $resultBox.html('<div class="wp-blogger-alert error"><span class="dashicons dashicons-warning"></span> Lỗi kết nối AJAX.</div>');
            });
        });

        // 10. Select All Checkbox in Table
        $('#wp-blogger-select-all').on('change', function () {
            $('.wp-blogger-post-checkbox').prop('checked', $(this).is(':checked'));
        });

        // 11. Pull/Import Posts Modal
        $('#wp-blogger-open-pull-modal-btn').on('click', function (e) {
            e.preventDefault();
            $('#wp-blogger-pull-modal').css('display', 'flex');
        });

        $('.wp-blogger-modal-close, #wp-blogger-cancel-pull-btn').on('click', function (e) {
            e.preventDefault();
            $('#wp-blogger-pull-modal').hide();
        });

        // 12. Execute Pull/Import Posts
        $('#wp-blogger-exec-pull-btn').on('click', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var blogId = $('#wp-blogger-pull-blog-id').val();
            var maxResults = $('#wp-blogger-pull-count').val();
            var status = $('#wp-blogger-pull-status').val();
            var $statusBox = $('#wp-blogger-pull-result');

            if (!blogId) {
                alert('Vui lòng chọn Blog cần kéo bài.');
                return;
            }

            $btn.prop('disabled', true);
            $statusBox.html('<div class="wp-blogger-alert info"><span class="spinner is-active" style="float:none; margin:0 5px 0 0;"></span> ' + wpBloggerData.strings.importing + '</div>');

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_pull_posts',
                blog_id: blogId,
                max_results: maxResults,
                status: status,
                nonce: wpBloggerData.nonce
            }, function (response) {
                $btn.prop('disabled', false);
                if (response.success) {
                    $statusBox.html('<div class="wp-blogger-alert success"><span class="dashicons dashicons-yes-alt"></span> ' + response.data.message + '</div>');
                    setTimeout(function () {
                        window.location.reload();
                    }, 2000);
                } else {
                    $statusBox.html('<div class="wp-blogger-alert error"><span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi kéo bài.') + '</div>');
                }
            }).fail(function () {
                $btn.prop('disabled', false);
                $statusBox.html('<div class="wp-blogger-alert error"><span class="dashicons dashicons-warning"></span> Lỗi kết nối AJAX.</div>');
            });
        });

        // 13. Clear Logs
        $('#wp-blogger-clear-logs-btn').on('click', function (e) {
            e.preventDefault();
            if (!confirm(wpBloggerData.strings.confirmClearLogs)) {
                return;
            }

            var $btn = $(this);
            $btn.prop('disabled', true);

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_clear_logs',
                nonce: wpBloggerData.nonce
            }, function (response) {
                if (response.success) {
                    window.location.reload();
                } else {
                    alert(response.data.message || 'Lỗi xoá log.');
                    $btn.prop('disabled', false);
                }
            });
        });

        // 14. Single Delete from Blogger (Sync Hub table row button)
        $(document).on('click', '.wp-blogger-delete-blogger-btn', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var postId = $btn.data('post-id');

            // Populate & show confirm modal
            var $modal = $('#wp-blogger-delete-confirm-modal');
            $('#wp-blogger-delete-confirm-msg').text('Bài viết #' + postId + ' sẽ bị xóa khỏi tất cả trang Blogger đã đồng bộ.');
            $('#wp-blogger-delete-confirm-result').html('');
            $('#wp-blogger-confirm-delete-btn')
                .data('post-id', postId)
                .data('post-ids', null)
                .prop('disabled', false)
                .html('<span class="dashicons dashicons-trash"></span> Xác nhận Xóa');
            $modal.css('display', 'flex');
        });

        // 15. Bulk Delete from Blogger (toolbar button)
        $('#wp-blogger-bulk-delete-btn').on('click', function (e) {
            e.preventDefault();
            var selectedPosts = [];
            $('.wp-blogger-post-checkbox:checked').each(function () {
                selectedPosts.push($(this).val());
            });

            if (selectedPosts.length === 0) {
                alert('Vui lòng tích chọn ít nhất 1 bài viết để xóa.');
                return;
            }

            // Populate & show confirm modal
            var $modal = $('#wp-blogger-delete-confirm-modal');
            var confirmMsg = (wpBloggerData.strings.confirmDeleteBloggerBulk || 'Bạn có chắc muốn xóa {count} bài đã chọn khỏi Blogger?')
                .replace('{count}', selectedPosts.length);
            $('#wp-blogger-delete-confirm-msg').text(confirmMsg);
            $('#wp-blogger-delete-confirm-result').html('');
            $('#wp-blogger-confirm-delete-btn')
                .data('post-id', null)
                .data('post-ids', selectedPosts)
                .prop('disabled', false)
                .html('<span class="dashicons dashicons-trash"></span> Xác nhận Xóa ' + selectedPosts.length + ' bài');
            $modal.css('display', 'flex');
        });

        // 16. Confirm Delete Modal — execute deletion
        $('#wp-blogger-confirm-delete-btn').on('click', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var postId = $btn.data('post-id');
            var postIds = $btn.data('post-ids');
            var $resultBox = $('#wp-blogger-delete-confirm-result');

            var payload = {
                action: 'wp_blogger_delete_from_blogger',
                nonce: wpBloggerData.nonce
            };

            var isBulk = (postIds && postIds.length > 0);
            if (isBulk) {
                payload.post_ids = postIds;
            } else {
                payload.post_id = postId;
            }

            $btn.prop('disabled', true).html('<span class="spinner is-active" style="float:none; margin:0 5px 0 0;"></span> ' + (wpBloggerData.strings.deleting || 'Đang xóa...'));
            $resultBox.html('');

            $.post(wpBloggerData.ajaxUrl, payload, function (response) {
                if (response.success) {
                    var html = '<div class="wp-blogger-alert" style="background:#f0fdf4; border-left:4px solid #16a34a; color:#15803d; padding:10px 14px; border-radius:6px; margin-top:10px;">' +
                        '<span class="dashicons dashicons-yes-alt"></span> ' + response.data.message + '</div>';
                    $resultBox.html(html);

                    // Update row UI if single delete
                    if (!isBulk && postId) {
                        var $row = $('.wp-blogger-delete-blogger-btn[data-post-id="' + postId + '"]').closest('tr');
                        $row.find('.wp-blogger-col-status').html('<span class="wp-blogger-badge muted"><span class="dashicons dashicons-trash"></span> Đã xóa Blogger</span>');
                        $row.find('.wp-blogger-delete-blogger-btn').remove();
                    }

                    // Close modal and reload after a short delay
                    setTimeout(function () {
                        $('#wp-blogger-delete-confirm-modal').hide();
                        if (isBulk) {
                            window.location.reload();
                        }
                    }, 2000);
                } else {
                    $resultBox.html('<div class="wp-blogger-alert" style="background:#fef2f2; border-left:4px solid #dc2626; color:#991b1b; padding:10px 14px; border-radius:6px; margin-top:10px;">' +
                        '<span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi xóa bài viết.') + '</div>');
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-trash"></span> Xác nhận Xóa');
                }
            }).fail(function () {
                $resultBox.html('<div class="wp-blogger-alert" style="background:#fef2f2; border-left:4px solid #dc2626; color:#991b1b; padding:10px 14px; border-radius:6px; margin-top:10px;">' +
                    '<span class="dashicons dashicons-warning"></span> Lỗi kết nối AJAX.</div>');
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-trash"></span> Xác nhận Xóa');
            });
        });

        // 17. Cancel Delete Modal
        $('#wp-blogger-cancel-delete-btn').on('click', function (e) {
            e.preventDefault();
            $('#wp-blogger-delete-confirm-modal').hide();
        });

        // Close delete modal on overlay click or X button with data-target
        $(document).on('click', '.wp-blogger-modal-close[data-target]', function (e) {
            e.preventDefault();
            var target = $(this).data('target');
            $('#' + target).hide();
        });

        // 18. Delete from Blogger in Metabox (Post Edit Screen)
        $(document).on('click', '#wp-blogger-metabox-delete-btn', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var postId = $btn.data('post-id');
            var $statusBox = $('#wp-blogger-metabox-status');

            var confirmMsg = wpBloggerData.strings.confirmDeleteBlogger ||
                'Bạn có chắc chắn muốn XOÁ bài viết này khỏi tất cả các trang Blogger đã đồng bộ? Bài trên WordPress vẫn còn.';

            if (!confirm(confirmMsg)) {
                return;
            }

            $btn.prop('disabled', true);
            $statusBox.html('<div class="wp-blogger-badge warning"><span class="spinner is-active" style="float:none; margin:0 4px 0 0;"></span> ' +
                (wpBloggerData.strings.deleting || 'Đang xóa trên Blogger...') + '</div>');

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_delete_from_blogger',
                post_id: postId,
                nonce: wpBloggerData.nonce
            }, function (response) {
                $btn.prop('disabled', false);
                if (response.success) {
                    $statusBox.html('<div class="wp-blogger-alert success" style="margin-top:6px; font-size:12px; padding:8px 10px;">' +
                        '<span class="dashicons dashicons-yes-alt"></span> ' + (response.data.message || 'Đã xóa khỏi Blogger') + '</div>');
                    // Hide delete button since no longer synced
                    $btn.hide();
                } else {
                    $statusBox.html('<div class="wp-blogger-alert error" style="margin-top:6px; font-size:12px; padding:8px 10px;">' +
                        '<span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi xóa bài viết.') + '</div>');
                }
            }).fail(function () {
                $btn.prop('disabled', false);
                $statusBox.html('<div class="wp-blogger-alert error" style="margin-top:6px; font-size:12px; padding:8px 10px;">' +
                    '<span class="dashicons dashicons-warning"></span> Lỗi AJAX máy chủ.</div>');
            });
        });

        // =====================================================================
        // 19. Preview on Blogger (Metabox)
        // =====================================================================
        $(document).on('click', '#wp-blogger-metabox-preview-btn', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var postId = $btn.data('post-id');
            var blogId = $('#wp-blogger-preview-blog-select').val();
            var $status = $('#wp-blogger-metabox-preview-status');

            if (!blogId) {
                $status.html('<small style="color:#dc2626;"><span class="dashicons dashicons-warning"></span> Vui lòng chọn Blog để xem trước.</small>');
                return;
            }

            $btn.prop('disabled', true);
            $status.html('<small><span class="spinner is-active" style="float:none;margin:0 4px 0 0;"></span> ' +
                (wpBloggerData.strings.previewing || 'Đang tạo bản xem trước...') + '</small>');

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_preview_on_blogger',
                post_id: postId,
                blog_id: blogId,
                nonce: wpBloggerData.nonce
            }, function (response) {
                $btn.prop('disabled', false);
                if (response.success && response.data.preview_url) {
                    $status.html('<div style="margin-top:4px; padding:8px 10px; background:#f0fdf4; border-left:3px solid #16a34a; border-radius:4px; font-size:11px;">' +
                        '<span class="dashicons dashicons-yes-alt" style="color:#16a34a;"></span> ' + response.data.message +
                        '<br><a href="' + response.data.preview_url + '" target="_blank" style="color:#2563eb; font-weight:600;">' +
                        '<span class="dashicons dashicons-external" style="font-size:12px;width:12px;height:12px;"></span> Mở xem trước</a></div>');
                } else if (response.success) {
                    $status.html('<div style="margin-top:4px; padding:8px 10px; background:#fff7ed; border-left:3px solid #f59e0b; border-radius:4px; font-size:11px;">' +
                        '<span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Đã tạo draft nhưng không có URL preview.') + '</div>');
                } else {
                    $status.html('<div style="margin-top:4px; padding:8px 10px; background:#fef2f2; border-left:3px solid #dc2626; border-radius:4px; font-size:11px;">' +
                        '<span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi tạo bản xem trước.') + '</div>');
                }
            }).fail(function () {
                $btn.prop('disabled', false);
                $status.html('<small style="color:#dc2626;"><span class="dashicons dashicons-warning"></span> Lỗi AJAX.</small>');
            });
        });

        // =====================================================================
        // 20. Schedule Broadcast (Metabox → Queue)
        // =====================================================================
        $(document).on('click', '#wp-blogger-metabox-schedule-btn', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var postId = $btn.data('post-id');
            var scheduledAt = $('#wp-blogger-schedule-datetime').val();
            var $status = $('#wp-blogger-metabox-schedule-status');

            if (!scheduledAt) {
                $status.html('<small style="color:#dc2626;"><span class="dashicons dashicons-warning"></span> Vui lòng chọn ngày giờ.</small>');
                return;
            }

            // Validate: must be in future (at least 1 minute)
            var selectedTime = new Date(scheduledAt).getTime();
            if (selectedTime <= Date.now() + 60000) {
                $status.html('<small style="color:#dc2626;"><span class="dashicons dashicons-warning"></span> Thời gian phải ở trong tương lai (ít nhất 1 phút).</small>');
                return;
            }

            $btn.prop('disabled', true);
            $status.html('<small><span class="spinner is-active" style="float:none;margin:0 4px 0 0;"></span> ' +
                (wpBloggerData.strings.scheduling || 'Đang lên lịch...') + '</small>');

            // Collect selected blogs if "selected" mode is active
            var targetBlogs = [];
            if ($('input[name="wp_blogger_sync_mode"]:checked').val() === 'selected') {
                $('input[name="wp_blogger_selected_blogs[]"]:checked').each(function () {
                    targetBlogs.push($(this).val());
                });
            }

            var payload = {
                action: 'wp_blogger_schedule_broadcast',
                post_id: postId,
                scheduled_at: scheduledAt,
                nonce: wpBloggerData.nonce
            };
            if (targetBlogs.length > 0) {
                payload.target_blogs = targetBlogs;
            }

            $.post(wpBloggerData.ajaxUrl, payload, function (response) {
                $btn.prop('disabled', false);
                if (response.success) {
                    $status.html('<div style="margin-top:4px; padding:8px 10px; background:#f5f3ff; border-left:3px solid #7c3aed; border-radius:4px; font-size:11px;">' +
                        '<span class="dashicons dashicons-clock" style="color:#7c3aed;"></span> ' + response.data.message + '</div>');
                    $('#wp-blogger-schedule-datetime').val('');
                } else {
                    $status.html('<div style="margin-top:4px; padding:8px 10px; background:#fef2f2; border-left:3px solid #dc2626; border-radius:4px; font-size:11px;">' +
                        '<span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi đặt lịch.') + '</div>');
                }
            }).fail(function () {
                $btn.prop('disabled', false);
                $status.html('<small style="color:#dc2626;"><span class="dashicons dashicons-warning"></span> Lỗi AJAX.</small>');
            });
        });

        // =====================================================================
        // 21. Queue Monitor: Process Queue Now
        // =====================================================================
        $('#wp-blogger-process-now-btn').on('click', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var $result = $('#wp-blogger-queue-result');

            $btn.prop('disabled', true).html('<span class="spinner is-active" style="float:none;margin:0 5px 0 0;"></span> Đang xử lý...');

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_process_queue_now',
                nonce: wpBloggerData.nonce
            }, function (response) {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-controls-play"></span> Chạy Queue ngay');
                if (response.success) {
                    $result.html('<div class="wp-blogger-alert success" style="margin-bottom:14px;"><span class="dashicons dashicons-yes-alt"></span> ' + response.data.message + '</div>');
                    // Update stat counts
                    if (response.data.counts) {
                        $.each(response.data.counts, function (key, val) {
                            $('#wp-blogger-stat-' + key).text(val);
                        });
                    }
                    setTimeout(function () { window.location.reload(); }, 2500);
                } else {
                    $result.html('<div class="wp-blogger-alert error"><span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi.') + '</div>');
                }
            }).fail(function () {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-controls-play"></span> Chạy Queue ngay');
                $result.html('<div class="wp-blogger-alert error"><span class="dashicons dashicons-warning"></span> Lỗi AJAX.</div>');
            });
        });

        // =====================================================================
        // 22. Queue Monitor: Clear Done Jobs
        // =====================================================================
        $('#wp-blogger-clear-done-btn').on('click', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var $result = $('#wp-blogger-queue-result');

            if (!confirm('Xóa tất cả jobs đã Hoàn tất và Đã hủy khỏi hàng đợi?')) return;

            $btn.prop('disabled', true);

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_clear_done_jobs',
                nonce: wpBloggerData.nonce
            }, function (response) {
                $btn.prop('disabled', false);
                if (response.success) {
                    $result.html('<div class="wp-blogger-alert success" style="margin-bottom:14px;"><span class="dashicons dashicons-yes-alt"></span> ' + response.data.message + '</div>');
                    setTimeout(function () { window.location.reload(); }, 1500);
                }
            });
        });

        // =====================================================================
        // 23. Queue Monitor: Cancel Job
        // =====================================================================
        $(document).on('click', '.wp-blogger-cancel-job-btn', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var jobId = $btn.data('job-id');
            var $result = $('#wp-blogger-queue-result');

            if (!confirm('Hủy công việc #' + jobId + ' trong hàng đợi?')) return;

            $btn.prop('disabled', true).html('<span class="spinner is-active" style="float:none;margin:0 3px 0 0;"></span>');

            $.post(wpBloggerData.ajaxUrl, {
                action: 'wp_blogger_cancel_queue_job',
                job_id: jobId,
                nonce: wpBloggerData.nonce
            }, function (response) {
                if (response.success) {
                    $result.html('<div class="wp-blogger-alert success" style="margin-bottom:14px;"><span class="dashicons dashicons-yes-alt"></span> ' + response.data.message + '</div>');
                    $('#wp-blogger-job-' + jobId).css('opacity', '0.4').find('td:last').html('<span style="color:#64748b;font-size:12px;">Đã hủy</span>');
                } else {
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-no-alt"></span> Hủy');
                    $result.html('<div class="wp-blogger-alert error"><span class="dashicons dashicons-warning"></span> ' + (response.data.message || 'Lỗi.') + '</div>');
                }
            });
        });

        // =====================================================================
        // 24. Queue Monitor: Auto-refresh stats every 30 seconds
        // =====================================================================
        if ($('#wp-blogger-queue-result').length) {
            setInterval(function () {
                $.post(wpBloggerData.ajaxUrl, {
                    action: 'wp_blogger_queue_status',
                    nonce: wpBloggerData.nonce
                }, function (response) {
                    if (response.success && response.data.counts) {
                        $.each(response.data.counts, function (key, val) {
                            $('#wp-blogger-stat-' + key).text(val);
                        });
                    }
                });
            }, 30000);
        }

    });

})(jQuery);

