<?php
/**
 * IW_Settings – Quản lý tất cả cài đặt của plugin Images Watermark.
 *
 * @package Images_Watermark
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IW_Settings {

    /** Option key lưu trong wp_options */
    const OPTION_KEY = 'images_watermark_settings';

    /** Giá trị mặc định */
    const DEFAULTS = [
        // ---------- Chung ----------
        'enabled'               => true,
        'watermark_on_upload'   => false,
        'post_types'            => [ 'post', 'page' ],
        'apply_to_featured'     => true,
        'apply_to_content'      => true,
        'backup_original'       => true,

        // ---------- Kiểu watermark ----------
        'watermark_type'        => 'text', // 'text' | 'image'

        // ---------- Text watermark ----------
        'text'                  => '© YourSite.com',
        'font_size'             => 24,
        'font_color'            => '#ffffff',
        'font_color_opacity'    => 80,
        'font_family'           => 'OpenSans',   // tên file TTF (không có .ttf)
        'text_angle'            => 0,

        // ---------- Image watermark ----------
        'image_id'              => 0,  // attachment ID của logo watermark
        'image_width_percent'   => 20, // % chiều rộng ảnh gốc

        // ---------- Vị trí ----------
        'position'              => 'bottom-right', // xem POSITIONS
        'offset_x'              => 10, // px tính từ cạnh
        'offset_y'              => 10,

        // ---------- Opacity tổng ----------
        'opacity'               => 80, // 0-100

        // ---------- Filter ảnh nhỏ ----------
        'min_width'             => 200,  // px – bỏ qua ảnh nhỏ hơn
        'min_height'            => 200,
    ];

    /** Các vị trí hợp lệ */
    const POSITIONS = [
        'top-left',
        'top-center',
        'top-right',
        'middle-left',
        'middle-center',
        'middle-right',
        'bottom-left',
        'bottom-center',
        'bottom-right',
    ];

    /** @var array<string, mixed> */
    private array $data = [];

    // ------------------------------------------------------------------ //

    public function __construct() {
        $saved = get_option( self::OPTION_KEY, [] );
        $this->data = wp_parse_args( $saved, self::DEFAULTS );
    }

    // ------------------------------------------------------------------ //

    public function get( string $key, mixed $default = null ): mixed {
        return $this->data[ $key ] ?? $default;
    }

    public function all(): array {
        return $this->data;
    }

    public function save( array $new_data ): bool {
        $this->data = $this->sanitize( $new_data );
        return update_option( self::OPTION_KEY, $this->data );
    }

    public function set_defaults(): void {
        if ( false === get_option( self::OPTION_KEY ) ) {
            update_option( self::OPTION_KEY, self::DEFAULTS );
            $this->data = self::DEFAULTS;
        }
    }

    // ------------------------------------------------------------------ //
    // Sanitize

    public function sanitize( array $raw ): array {
        $clean = [];

        $clean['enabled']             = ! empty( $raw['enabled'] );
        $clean['watermark_on_upload'] = ! empty( $raw['watermark_on_upload'] );
        $clean['backup_original']     = ! empty( $raw['backup_original'] );
        $clean['apply_to_featured']   = ! empty( $raw['apply_to_featured'] );
        $clean['apply_to_content']    = ! empty( $raw['apply_to_content'] );

        // post_types
        $all_types = get_post_types( [ 'public' => true ], 'names' );
        $raw_types = (array) ( $raw['post_types'] ?? [] );
        $clean['post_types'] = array_values( array_intersect( $raw_types, $all_types ) );

        // watermark_type
        $clean['watermark_type'] = in_array( $raw['watermark_type'] ?? '', [ 'text', 'image' ], true )
            ? $raw['watermark_type']
            : 'text';

        // text watermark
        $clean['text']               = sanitize_text_field( $raw['text'] ?? '© YourSite.com' );
        $clean['font_size']          = max( 8, min( 200, (int) ( $raw['font_size'] ?? 24 ) ) );
        $clean['font_color']         = sanitize_hex_color( $raw['font_color'] ?? '#ffffff' ) ?: '#ffffff';
        $clean['font_color_opacity'] = max( 0, min( 100, (int) ( $raw['font_color_opacity'] ?? 80 ) ) );
        $clean['font_family']        = sanitize_key( $raw['font_family'] ?? 'OpenSans' );
        $clean['text_angle']         = max( -90, min( 90, (int) ( $raw['text_angle'] ?? 0 ) ) );

        // image watermark
        $clean['image_id']           = absint( $raw['image_id'] ?? 0 );
        $clean['image_width_percent']= max( 5, min( 100, (int) ( $raw['image_width_percent'] ?? 20 ) ) );

        // position
        $clean['position'] = in_array( $raw['position'] ?? '', self::POSITIONS, true )
            ? $raw['position']
            : 'bottom-right';
        $clean['offset_x'] = max( 0, (int) ( $raw['offset_x'] ?? 10 ) );
        $clean['offset_y'] = max( 0, (int) ( $raw['offset_y'] ?? 10 ) );

        // opacity
        $clean['opacity'] = max( 0, min( 100, (int) ( $raw['opacity'] ?? 80 ) ) );

        // min dimensions
        $clean['min_width']  = max( 0, (int) ( $raw['min_width']  ?? 200 ) );
        $clean['min_height'] = max( 0, (int) ( $raw['min_height'] ?? 200 ) );

        return $clean;
    }
}
