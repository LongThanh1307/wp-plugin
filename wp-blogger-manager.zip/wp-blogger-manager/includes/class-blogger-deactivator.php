<?php
/**
 * Fired during plugin deactivation
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WP_Blogger_Queue')) {
    require_once dirname(__FILE__) . '/class-blogger-queue.php';
}

class WP_Blogger_Deactivator {

    /**
     * Run deactivation tasks
     */
    public static function deactivate() {
        WP_Blogger_Queue::unschedule_cron();
        // Flush rewrite rules
        flush_rewrite_rules();
    }
}
