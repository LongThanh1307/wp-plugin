<?php
/**
 * Admin Sync Logs & Diagnostics Template
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap wp-blogger-wrap">

    <div class="wp-blogger-header">
        <div class="wp-blogger-title-group">
            <h1><span class="dashicons dashicons-list-view"></span> <?php esc_html_e('Nhật ký Đồng bộ & Báo cáo Lỗi (Sync Logs)', 'wp-blogger-manager'); ?></h1>
            <p><?php esc_html_e('Theo dõi toàn bộ lịch sử đồng bộ hóa bài viết giữa WordPress và Blogger để dễ dàng kiểm tra sự cố.', 'wp-blogger-manager'); ?></p>
        </div>
        <div class="wp-blogger-header-actions">
            <?php if (!empty($logs)) : ?>
                <button type="button" id="wp-blogger-clear-logs-btn" class="wp-blogger-btn wp-blogger-btn-danger">
                    <span class="dashicons dashicons-trash"></span> <?php esc_html_e('Xoá sạch nhật ký', 'wp-blogger-manager'); ?>
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Filters -->
    <div class="wp-blogger-card" style="margin-bottom: 16px;">
        <div class="wp-blogger-card-body" style="padding: 14px 20px;">
            <div style="display: flex; gap: 12px; align-items: center;">
                <label style="font-weight: 600; font-size: 13px;"><?php esc_html_e('Lọc theo trạng thái:', 'wp-blogger-manager'); ?></label>
                <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-logs')); ?>" class="wp-blogger-btn <?php echo empty($filter_status) ? 'wp-blogger-btn-primary' : 'wp-blogger-btn-secondary'; ?> wp-blogger-btn-sm">
                    <?php esc_html_e('Tất cả', 'wp-blogger-manager'); ?>
                </a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-logs&log_status=success')); ?>" class="wp-blogger-btn <?php echo $filter_status === 'success' ? 'wp-blogger-btn-primary' : 'wp-blogger-btn-secondary'; ?> wp-blogger-btn-sm">
                    <span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Chỉ Thành công', 'wp-blogger-manager'); ?>
                </a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=wp-blogger-logs&log_status=error')); ?>" class="wp-blogger-btn <?php echo $filter_status === 'error' ? 'wp-blogger-btn-danger' : 'wp-blogger-btn-secondary'; ?> wp-blogger-btn-sm">
                    <span class="dashicons dashicons-warning"></span> <?php esc_html_e('Chỉ Thất bại / Lỗi', 'wp-blogger-manager'); ?>
                </a>
            </div>
        </div>
    </div>

    <!-- Logs Table -->
    <div class="wp-blogger-card">
        <div class="wp-blogger-card-body" style="padding: 0;">
            <?php if (!empty($logs)) : ?>
                <table class="wp-blogger-table">
                    <thead>
                        <tr>
                            <th style="width: 70px;">#ID</th>
                            <th style="width: 150px;"><?php esc_html_e('Thời gian', 'wp-blogger-manager'); ?></th>
                            <th><?php esc_html_e('Bài viết WP', 'wp-blogger-manager'); ?></th>
                            <th><?php esc_html_e('Blog ID', 'wp-blogger-manager'); ?></th>
                            <th><?php esc_html_e('Hành động', 'wp-blogger-manager'); ?></th>
                            <th><?php esc_html_e('Trạng thái', 'wp-blogger-manager'); ?></th>
                            <th><?php esc_html_e('Thông điệp / Chi tiết', 'wp-blogger-manager'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $l) : ?>
                            <tr>
                                <td><code>#<?php echo intval($l->id); ?></code></td>
                                <td>
                                    <small style="color: #64748b; font-weight: 500;">
                                        <?php echo esc_html(date_i18n('d/m/Y H:i:s', strtotime($l->created_at))); ?>
                                    </small>
                                </td>
                                <td>
                                    <?php if ($l->post_id > 0) : ?>
                                        <strong>
                                            <a href="<?php echo esc_url(get_edit_post_link($l->post_id)); ?>">
                                                #<?php echo intval($l->post_id); ?> - <?php echo esc_html(wp_trim_words(get_the_title($l->post_id), 6)); ?>
                                            </a>
                                        </strong>
                                    <?php else : ?>
                                        <em style="color: #94a3b8;">N/A</em>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($l->blog_id)) : ?>
                                        <code><?php echo esc_html($l->blog_id); ?></code>
                                    <?php else : ?>
                                        <em style="color: #94a3b8;">N/A</em>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <code><?php echo esc_html(strtoupper($l->action)); ?></code>
                                </td>
                                <td>
                                    <span class="wp-blogger-badge <?php echo $l->status === 'success' ? 'success' : 'danger'; ?>">
                                        <span class="dashicons <?php echo $l->status === 'success' ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>"></span>
                                        <?php echo $l->status === 'success' ? esc_html__('Thành công', 'wp-blogger-manager') : esc_html__('Lỗi', 'wp-blogger-manager'); ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="font-size: 13px; <?php echo $l->status === 'error' ? 'color: #dc2626;' : ''; ?>">
                                        <?php echo esc_html($l->message); ?>
                                    </div>
                                    <?php if (!empty($l->blogger_post_id)) : ?>
                                        <div style="font-size: 11px; color: #64748b; margin-top: 2px;">
                                            Blogger Post ID: <code><?php echo esc_html($l->blogger_post_id); ?></code>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <div style="padding: 40px; text-align: center; color: #64748b;">
                    <span class="dashicons dashicons-yes-alt" style="font-size: 36px; width: 36px; height: 36px; color: #10b981; margin-bottom: 8px;"></span>
                    <p style="margin: 0; font-size: 15px;"><?php esc_html_e('Chưa có dữ liệu nhật ký nào hoặc đã được làm sạch.', 'wp-blogger-manager'); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>
