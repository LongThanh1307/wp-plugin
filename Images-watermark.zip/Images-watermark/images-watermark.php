<?php
/**
 * Plugin Name:       Images Watermark
 * Plugin URI:        https://example.com/images-watermark
 * Description:       Tự động đóng watermark cho hình ảnh khi đăng bài viết trên WordPress. Hỗ trợ watermark dạng văn bản và logo/hình ảnh.
 * Version:           1.0.0
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            Your Name
 * Author URI:        https://example.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       images-watermark
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// ── Plugin constants ──────────────────────────────────────────────────────────
define( 'IW_VERSION',     '1.0.0' );
define( 'IW_PLUGIN_FILE', __FILE__ );
define( 'IW_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'IW_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'IW_PLUGIN_BASE', plugin_basename( __FILE__ ) );

// ── Autoload includes ─────────────────────────────────────────────────────────
$includes = [
    'includes/class-watermark-settings.php',
    'includes/class-watermark-processor.php',
    'includes/class-watermark-admin.php',
];
foreach ( $includes as $file ) {
    $path = IW_PLUGIN_DIR . $file;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// ── Bootstrap ─────────────────────────────────────────────────────────────────
if ( ! class_exists( 'Images_Watermark' ) ) :

final class Images_Watermark {

    /** @var Images_Watermark|null */
    private static ?Images_Watermark $instance = null;

    /** @var IW_Settings */
    public IW_Settings $settings;

    /** @var IW_Processor */
    public IW_Processor $processor;

    /** @var IW_Admin|null */
    public ?IW_Admin $admin = null;

    // --------------------------------------------------------------------- //

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->settings  = new IW_Settings();
        $this->processor = new IW_Processor( $this->settings );

        if ( is_admin() ) {
            $this->admin = new IW_Admin( $this->settings );
        }

        $this->register_hooks();
    }

    // --------------------------------------------------------------------- //

    private function register_hooks(): void {
        // i18n
        add_action( 'init', [ $this, 'load_textdomain' ] );

        // Kích hoạt watermark khi bài viết được publish
        add_action( 'transition_post_status', [ $this, 'on_post_status_change' ], 10, 3 );

        // Watermark khi upload ảnh (tuỳ chọn)
        add_filter( 'wp_handle_upload', [ $this, 'on_upload' ] );

        // Plugin action links
        add_filter( 'plugin_action_links_' . IW_PLUGIN_BASE, [ $this, 'add_action_links' ] );
    }

    // --------------------------------------------------------------------- //

    /**
     * Fired when a post status transitions.
     * Áp dụng watermark lần đầu khi bài chuyển sang "publish".
     */
    public function on_post_status_change( string $new_status, string $old_status, WP_Post $post ): void {
        // Chỉ xử lý khi post chuyển sang "publish" lần đầu hoặc khi update
        if ( 'publish' !== $new_status ) {
            return;
        }

        // Bỏ qua các post type không cần xử lý
        $allowed_types = (array) $this->settings->get( 'post_types', [ 'post', 'page' ] );
        if ( ! in_array( $post->post_type, $allowed_types, true ) ) {
            return;
        }

        // Tránh chạy lại nếu đã được watermark
        if ( get_post_meta( $post->ID, '_iw_watermarked', true ) ) {
            return;
        }

        $this->processor->process_post( $post->ID );
    }

    /**
     * Watermark ngay khi upload (nếu bật tuỳ chọn).
     */
    public function on_upload( array $upload ): array {
        if ( ! $this->settings->get( 'watermark_on_upload', false ) ) {
            return $upload;
        }

        $mime = $upload['type'] ?? '';
        if ( ! in_array( $mime, [ 'image/jpeg', 'image/png', 'image/gif', 'image/webp' ], true ) ) {
            return $upload;
        }

        $this->processor->apply_watermark_to_file( $upload['file'] );
        return $upload;
    }

    // --------------------------------------------------------------------- //

    public function load_textdomain(): void {
        load_plugin_textdomain(
            'images-watermark',
            false,
            dirname( IW_PLUGIN_BASE ) . '/languages'
        );
    }

    public function add_action_links( array $links ): array {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url( admin_url( 'options-general.php?page=images-watermark' ) ),
            __( 'Cài đặt', 'images-watermark' )
        );
        array_unshift( $links, $settings_link );
        return $links;
    }

    // --------------------------------------------------------------------- //

    /** Chạy khi kích hoạt plugin */
    public static function activate(): void {
        $settings = new IW_Settings();
        $settings->set_defaults();

        // Tạo thư mục backup nếu cần
        $upload_dir = wp_upload_dir();
        $backup_dir = $upload_dir['basedir'] . '/iw-originals';
        if ( ! is_dir( $backup_dir ) ) {
            wp_mkdir_p( $backup_dir );
            // Bảo vệ thư mục backup
            file_put_contents( $backup_dir . '/.htaccess', 'deny from all' );
            file_put_contents( $backup_dir . '/index.php', '<?php // Silence is golden.' );
        }

        flush_rewrite_rules();
    }

    /** Chạy khi huỷ kích hoạt plugin */
    public static function deactivate(): void {
        flush_rewrite_rules();
    }
}

endif; // class_exists

// ── Activation / Deactivation hooks ──────────────────────────────────────────
register_activation_hook(   __FILE__, [ 'Images_Watermark', 'activate'   ] );
register_deactivation_hook( __FILE__, [ 'Images_Watermark', 'deactivate' ] );

// ── Start plugin ──────────────────────────────────────────────────────────────
function images_watermark(): Images_Watermark {
    return Images_Watermark::instance();
}
add_action( 'plugins_loaded', 'images_watermark' );
