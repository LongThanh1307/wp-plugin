<?php
/**
 * Admin Menu, Pages, Settings & Multi-Account OAuth Controller
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Blogger_Admin {

    private $auth;
    private $api;
    private $sync;
    private $queue;

    /**
     * Constructor
     */
    public function __construct(WP_Blogger_Auth $auth, WP_Blogger_API $api, WP_Blogger_Sync $sync, WP_Blogger_Queue $queue) {
        $this->auth  = $auth;
        $this->api   = $api;
        $this->sync  = $sync;
        $this->queue = $queue;

        $this->init_hooks();
    }

    /**
     * Register admin hooks
     */
    private function init_hooks() {
        add_action('admin_menu', array($this, 'register_admin_menus'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_init', array($this, 'handle_oauth_callback'));
        add_action('admin_init', array($this, 'save_settings'));
    }

    /**
     * Register Admin Menus
     */
    public function register_admin_menus() {
        $main_slug = 'wp-blogger-dashboard';

        add_menu_page(
            __('Blogger Manager', 'wp-blogger-manager'),
            __('Blogger Manager', 'wp-blogger-manager'),
            'manage_options',
            $main_slug,
            array($this, 'render_dashboard_page'),
            'dashicons-cloud',
            30
        );

        add_submenu_page(
            $main_slug,
            __('Tổng quan Dashboard', 'wp-blogger-manager'),
            __('Tổng quan', 'wp-blogger-manager'),
            'manage_options',
            $main_slug,
            array($this, 'render_dashboard_page')
        );

        add_submenu_page(
            $main_slug,
            __('Tài khoản Google & Blog Blogger', 'wp-blogger-manager'),
            __('Tài khoản & Blogs', 'wp-blogger-manager'),
            'manage_options',
            'wp-blogger-blogs',
            array($this, 'render_blogs_page')
        );

        add_submenu_page(
            $main_slug,
            __('Bài viết WordPress', 'wp-blogger-manager'),
            __('📝 Bài viết', 'wp-blogger-manager'),
            'manage_options',
            'edit.php',
            null
        );

        add_submenu_page(
            $main_slug,
            __('Trung tâm Đồng bộ bài viết', 'wp-blogger-manager'),
            __('Đồng bộ bài viết', 'wp-blogger-manager'),
            'manage_options',
            'wp-blogger-sync-hub',
            array($this, 'render_sync_hub_page')
        );

        add_submenu_page(
            $main_slug,
            __('Cài đặt API & CDN Hình ảnh', 'wp-blogger-manager'),
            __('Cài đặt & CDN', 'wp-blogger-manager'),
            'manage_options',
            'wp-blogger-settings',
            array($this, 'render_settings_page')
        );

        add_submenu_page(
            $main_slug,
            __('Nhật ký Đồng bộ (Logs)', 'wp-blogger-manager'),
            __('Nhật ký (Logs)', 'wp-blogger-manager'),
            'manage_options',
            'wp-blogger-logs',
            array($this, 'render_logs_page')
        );

        add_submenu_page(
            $main_slug,
            __('Hàng đợi Đồng bộ nền (Queue)', 'wp-blogger-manager'),
            __('⏳ Hàng đợi', 'wp-blogger-manager'),
            'manage_options',
            'wp-blogger-queue',
            array($this, 'render_queue_page')
        );
    }

    /**
     * Enqueue CSS & JS Assets for Admin
     */
    public function enqueue_assets($hook) {
        $is_plugin_page = (strpos($hook, 'wp-blogger') !== false);
        $is_post_screen = in_array($hook, array('post.php', 'post-new.php', 'edit.php'));

        if (!$is_plugin_page && !$is_post_screen) {
            return;
        }

        wp_enqueue_style(
            'wp-blogger-admin-style',
            WP_BLOGGER_PLUGIN_URL . 'assets/css/admin-style.css',
            array(),
            WP_BLOGGER_VERSION
        );

        wp_enqueue_script(
            'wp-blogger-admin-script',
            WP_BLOGGER_PLUGIN_URL . 'assets/js/admin-script.js',
            array('jquery'),
            WP_BLOGGER_VERSION,
            true
        );

        $accounts = $this->auth->get_accounts();

        wp_localize_script('wp-blogger-admin-script', 'wpBloggerData', array(
            'ajaxUrl'        => admin_url('admin-ajax.php'),
            'nonce'          => wp_create_nonce('wp_blogger_admin_nonce'),
            'accountsCount'  => count($accounts),
            'strings'        => array(
                'confirmDisconnect'        => __('Bạn có chắc chắn muốn ngắt kết nối TẤT CẢ tài khoản Google không?', 'wp-blogger-manager'),
                'confirmDisconnectAccount' => __('Bạn có chắc chắn muốn ngắt kết nối tài khoản Google này không?', 'wp-blogger-manager'),
                'confirmClearLogs'         => __('Bạn có chắc chắn muốn xoá toàn bộ lịch sử nhật ký không?', 'wp-blogger-manager'),
                'confirmDeleteBlogger'     => __('Bạn có chắc chắn muốn XOÁ bài viết này khỏi tất cả các trang Blogger đã đồng bộ? Hành động này không thể hoàn tác.', 'wp-blogger-manager'),
                'confirmDeleteBloggerBulk' => __('Bạn có chắc chắn muốn XOÁ {count} bài viết đã chọn khỏi tất cả các trang Blogger đã đồng bộ? Hành động này không thể hoàn tác.', 'wp-blogger-manager'),
                'syncing'                  => __('Đang đồng bộ...', 'wp-blogger-manager'),
                'deleting'                 => __('Đang xoá trên Blogger...', 'wp-blogger-manager'),
                'previewing'               => __('Đang tạo bản xem trước...', 'wp-blogger-manager'),
                'scheduling'               => __('Đang lên lịch...', 'wp-blogger-manager'),
                'queueAdded'               => __('Đã thêm vào hàng đợi!', 'wp-blogger-manager'),
                'testing'                  => __('Đang kiểm tra...', 'wp-blogger-manager'),
                'importing'                => __('Đang kéo bài viết từ Blogger...', 'wp-blogger-manager'),
                'success'                  => __('Thành công', 'wp-blogger-manager'),
                'error'                    => __('Lỗi', 'wp-blogger-manager'),
                'copied'                   => __('Đã sao chép vào bộ nhớ tạm!', 'wp-blogger-manager'),
            ),
        ));
    }

    /**
     * Handle OAuth Callback Redirect for Adding Google Accounts
     */
    public function handle_oauth_callback() {
        if (!isset($_GET['page']) || !in_array($_GET['page'], array('wp-blogger-settings', 'wp-blogger-blogs'), true)) {
            return;
        }

        if (!isset($_GET['action']) || $_GET['action'] !== 'oauth_callback') {
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_die(__('Bạn không có quyền truy cập trang này.', 'wp-blogger-manager'));
        }

        if (!empty($_GET['error'])) {
            $error = sanitize_text_field($_GET['error']);
            wp_redirect(admin_url('admin.php?page=wp-blogger-blogs&auth_error=' . urlencode($error)));
            exit;
        }

        if (empty($_GET['code']) || empty($_GET['state'])) {
            wp_redirect(admin_url('admin.php?page=wp-blogger-blogs&auth_error=missing_code'));
            exit;
        }

        $code  = sanitize_text_field($_GET['code']);
        $state = sanitize_text_field($_GET['state']);

        $account_id = $this->auth->handle_callback($code, $state);

        if (is_wp_error($account_id)) {
            wp_redirect(admin_url('admin.php?page=wp-blogger-blogs&auth_error=' . urlencode($account_id->get_error_message())));
            exit;
        }

        // Fetch blogs for all accounts immediately
        $all_blogs = $this->api->fetch_all_accounts_blogs();

        // Set default blog if not set
        $settings = get_option('wp_blogger_settings', array());
        if (empty($settings['default_blog_id']) && !empty($all_blogs)) {
            $first_id = key($all_blogs);
            $settings['default_blog_id'] = $first_id;
            update_option('wp_blogger_settings', $settings);
        }

        wp_redirect(admin_url('admin.php?page=wp-blogger-blogs&auth_success=1'));
        exit;
    }

    /**
     * Handle saving settings form
     */
    public function save_settings() {
        if (!isset($_POST['wp_blogger_save_settings_nonce']) || !wp_verify_nonce($_POST['wp_blogger_save_settings_nonce'], 'wp_blogger_save_settings')) {
            return;
        }

        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = get_option('wp_blogger_settings', array());

        // API credentials
        if (isset($_POST['client_id'])) {
            $settings['client_id'] = trim(sanitize_text_field($_POST['client_id']));
        }
        if (isset($_POST['client_secret'])) {
            $settings['client_secret'] = trim(sanitize_text_field($_POST['client_secret']));
        }

        // Sync preferences
        $settings['auto_sync_on_publish']  = isset($_POST['auto_sync_on_publish']) ? 1 : 0;
        $settings['auto_sync_on_update']   = isset($_POST['auto_sync_on_update']) ? 1 : 0;
        $settings['auto_delete_on_trash']  = isset($_POST['auto_delete_on_trash']) ? 1 : 0;
        $settings['enable_wp_post_sync']   = 1; // Always enabled since CPT was removed
        // Queue & Retry settings
        $settings['queue_mode']  = isset($_POST['queue_mode']) ? 1 : 0;
        $settings['max_retries'] = isset($_POST['max_retries']) ? max(1, min(5, intval($_POST['max_retries']))) : 3;

        if (!empty($settings['queue_mode'])) {
            WP_Blogger_Queue::schedule_cron();
        } else {
            WP_Blogger_Queue::unschedule_cron();
        }

        // Image & CDN Settings
        if (isset($_POST['cdn_url'])) {
            $settings['cdn_url'] = trim(esc_url_raw($_POST['cdn_url']));
        }
        $settings['sideload_external_img'] = isset($_POST['sideload_external_img']) ? 1 : 0;
        $settings['auto_featured_image']   = isset($_POST['auto_featured_image']) ? 1 : 0;
        if (isset($_POST['featured_img_position'])) {
            $settings['featured_img_position'] = sanitize_text_field($_POST['featured_img_position']);
        }
        // Default featured image URL (fallback when post has no thumbnail)
        if (isset($_POST['default_featured_image_url'])) {
            $settings['default_featured_image_url'] = esc_url_raw(trim($_POST['default_featured_image_url']));
        }
        if (isset($_POST['default_blog_id'])) {
            $settings['default_blog_id'] = sanitize_text_field($_POST['default_blog_id']);
        }

        update_option('wp_blogger_settings', $settings);

        wp_redirect(admin_url('admin.php?page=wp-blogger-settings&settings_saved=1'));
        exit;
    }


    /**
     * Render Dashboard
     */
    public function render_dashboard_page() {
        $accounts      = $this->auth->get_accounts();
        $blogs         = get_option('wp_blogger_blogs', array());
        $settings      = get_option('wp_blogger_settings', array());
        $logs          = $this->sync->get_logs(10);
        $quota_data    = $this->api->get_quota_today();
        $quota_history = $this->api->get_quota_history(7);

        include WP_BLOGGER_PLUGIN_DIR . 'templates/admin-dashboard.php';
    }

    /**
     * Render Accounts & Blogs Management
     */
    public function render_blogs_page() {
        $accounts  = $this->auth->get_accounts();
        $blogs     = get_option('wp_blogger_blogs', array());
        $settings  = get_option('wp_blogger_settings', array());
        $auth_url  = $this->auth->get_auth_url();

        include WP_BLOGGER_PLUGIN_DIR . 'templates/admin-blogs.php';
    }

    /**
     * Render Sync Hub Page
     */
    public function render_sync_hub_page() {
        global $wpdb;

        $accounts  = $this->auth->get_accounts();
        $blogs     = get_option('wp_blogger_blogs', array());
        $settings  = get_option('wp_blogger_settings', array());

        // Filters for staging table
        $filter_blog  = isset($_GET['filter_blog'])  ? sanitize_text_field($_GET['filter_blog'])  : '';
        $filter_label = isset($_GET['filter_label']) ? sanitize_text_field($_GET['filter_label']) : '';
        $filter_status = isset($_GET['filter_status']) ? sanitize_text_field($_GET['filter_status']) : '';
        $paged         = max(1, isset($_GET['paged']) ? intval($_GET['paged']) : 1);
        $per_page      = 20;
        $offset        = ($paged - 1) * $per_page;

        // Build staging query
        $table = $wpdb->prefix . 'blogger_import_staging';

        // Ensure table exists
        WP_Blogger_Activator::create_import_staging_table();

        $where_clauses = array('1=1');
        $where_values  = array();

        if (!empty($filter_blog)) {
            $where_clauses[] = 'blog_id = %s';
            $where_values[]  = $filter_blog;
        }
        if (!empty($filter_label)) {
            $where_clauses[] = 'labels LIKE %s';
            $where_values[]  = '%' . $wpdb->esc_like('"' . $filter_label . '"') . '%';
        }
        if ($filter_status === 'imported') {
            $where_clauses[] = 'imported_wp_id > 0';
        } elseif ($filter_status === 'pending') {
            $where_clauses[] = 'imported_wp_id = 0';
        }

        $where_sql = implode(' AND ', $where_clauses);

        $total_items    = 0;
        $staging_posts  = array();
        $all_labels_for_filter = array();

        // Only query if table has data
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if ($table_exists) {
            if (!empty($where_values)) {
                $total_items   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE {$where_sql}", ...$where_values));
                $staging_posts = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY fetched_at DESC LIMIT %d OFFSET %d",
                    ...array_merge($where_values, array($per_page, $offset))
                ));
            } else {
                $total_items   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
                $staging_posts = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM {$table} ORDER BY fetched_at DESC LIMIT %d OFFSET %d",
                    $per_page, $offset
                ));
            }

            // Get all unique labels for filter dropdown
            $all_labels_raw = $wpdb->get_col("SELECT DISTINCT labels FROM {$table} WHERE labels != '' AND labels != '[]'");
            foreach ($all_labels_raw as $labels_json) {
                $decoded = json_decode($labels_json, true);
                if (is_array($decoded)) {
                    foreach ($decoded as $l) {
                        if ($l !== '' && !in_array($l, $all_labels_for_filter, true)) {
                            $all_labels_for_filter[] = $l;
                        }
                    }
                }
            }
            sort($all_labels_for_filter);
        }

        $total_pages = $per_page > 0 ? ceil($total_items / $per_page) : 1;

        include WP_BLOGGER_PLUGIN_DIR . 'templates/admin-sync-hub.php';
    }

    /**
     * Render Settings Page
     */
    public function render_settings_page() {
        $accounts     = $this->auth->get_accounts();
        $settings     = get_option('wp_blogger_settings', array());
        $redirect_uri = $this->auth->get_redirect_uri();
        $auth_url     = $this->auth->get_auth_url();

        include WP_BLOGGER_PLUGIN_DIR . 'templates/admin-settings.php';
    }

    /**
     * Render Logs Page
     */
    public function render_logs_page() {
        $filter_status = isset($_GET['log_status']) ? sanitize_text_field($_GET['log_status']) : '';
        $logs          = $this->sync->get_logs(100, $filter_status);

        include WP_BLOGGER_PLUGIN_DIR . 'templates/admin-logs.php';
    }

    /**
     * Render Queue Monitor Page
     */
    public function render_queue_page() {
        // Auto-heal cron and process any due jobs
        $this->queue->ensure_cron_scheduled();
        $this->queue->process_queue();

        $filter_status = isset($_GET['queue_status']) ? sanitize_text_field($_GET['queue_status']) : '';
        $queue_items   = $this->queue->get_queue_items(100, $filter_status);
        $queue_counts  = $this->queue->get_queue_status();
        $settings      = get_option('wp_blogger_settings', array());
        $blogs         = get_option('wp_blogger_blogs', array());

        include WP_BLOGGER_PLUGIN_DIR . 'templates/admin-queue.php';
    }
}

