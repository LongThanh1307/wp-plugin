<?php
/**
 * Handles Image Processing, CDN URL rewriting, and External Media Sideloading
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Blogger_Media {

    /**
     * Process post HTML content for Blogger
     * - Rewrites local WP upload URLs to configured CDN URL
     * - Downloads external images to WP Media Library (if enabled)
     * - Injects Featured Image if configured
     *
     * @param string $content
     * @param int $post_id
     * @return string Processed HTML content ready for Blogger
     */
    public function process_content_for_blogger($content, $post_id = 0) {
        $settings = get_option('wp_blogger_settings', array());

        // 1. Process external images (sideload to WP Media) if enabled
        if (!empty($settings['sideload_external_img'])) {
            $content = $this->sideload_external_images($content, $post_id);
        }

        // 2. Rewrite WP Uploads URLs to CDN URL if configured
        if (!empty($settings['cdn_url'])) {
            $content = $this->apply_cdn_url($content, $settings['cdn_url']);
        }

        // 3. Inject Featured Image if enabled and not already in content
        if (!empty($settings['auto_featured_image']) && $post_id > 0) {
            $position = !empty($settings['featured_img_position']) ? $settings['featured_img_position'] : 'top';
            if ($position !== 'none') {
                $content = $this->inject_featured_image($content, $post_id, $position, !empty($settings['cdn_url']) ? $settings['cdn_url'] : '');
            }
        }

        // 4. Sanitize and clean Gutenberg block comments & HTML for Blogger
        $content = $this->clean_gutenberg_comments($content);

        return $content;
    }

    /**
     * Rewrite standard WordPress upload URLs with CDN URL
     *
     * @param string $content
     * @param string $cdn_base_url (e.g., https://cdn.domain.com)
     * @return string
     */
    public function apply_cdn_url($content, $cdn_base_url) {
        $cdn_base_url = rtrim(trim($cdn_base_url), '/');
        if (empty($cdn_base_url)) {
            return $content;
        }

        $upload_dir = wp_upload_dir();
        $base_upload_url = rtrim($upload_dir['baseurl'], '/');
        $site_url = rtrim(site_url(), '/');

        // Case A: CDN URL includes path or is full CDN prefix
        // If user entered e.g. https://cdn.example.com
        $parsed_cdn = parse_url($cdn_base_url);
        $cdn_scheme_host = (isset($parsed_cdn['scheme']) ? $parsed_cdn['scheme'] . '://' : 'https://') . (isset($parsed_cdn['host']) ? $parsed_cdn['host'] : '');
        $cdn_path = isset($parsed_cdn['path']) ? trim($parsed_cdn['path'], '/') : '';

        // Replace upload URL directly
        if (!empty($cdn_path)) {
            $target_upload_cdn = $cdn_base_url;
            $content = str_replace($base_upload_url, $target_upload_cdn, $content);
        } else {
            // Replace site domain with CDN domain for upload paths
            $target_upload_cdn = str_replace($site_url, $cdn_scheme_host, $base_upload_url);
            $content = str_replace($base_upload_url, $target_upload_cdn, $content);
        }

        return $content;
    }

    /**
     * Download external images found in post content to WP Media Library
     * and replace their src URLs with the new WP Media / CDN URLs.
     *
     * @param string $content
     * @param int $post_id
     * @return string
     */
    public function sideload_external_images($content, $post_id = 0) {
        if (empty($content)) {
            return $content;
        }

        // Get site host to compare
        $site_host = parse_url(site_url(), PHP_URL_HOST);

        // Find all img tags with src
        preg_match_all('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $content, $matches, PREG_SET_ORDER);

        if (empty($matches)) {
            return $content;
        }

        // Include WordPress media admin functions if not loaded
        if (!function_exists('media_sideload_image')) {
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
        }

        $replaced_urls = array();

        foreach ($matches as $match) {
            $img_tag = $match[0];
            $src = $match[1];

            // Skip data URLs, relative paths or already processed
            if (strpos($src, 'data:') === 0 || empty($src) || isset($replaced_urls[$src])) {
                continue;
            }

            // Check if external domain
            $img_host = parse_url($src, PHP_URL_HOST);
            if (!empty($img_host) && strcasecmp($img_host, $site_host) !== 0) {
                // Sideload to WP Media
                $attachment_id = media_sideload_image($src, $post_id, '', 'id');

                if (!is_wp_error($attachment_id)) {
                    $new_url = wp_get_attachment_url($attachment_id);
                    if ($new_url) {
                        $replaced_urls[$src] = $new_url;
                        $content = str_replace($src, $new_url, $content);
                    }
                }
            }
        }

        return $content;
    }

    /**
     * Inject Featured Image into post content formatted for Blogger thumbnails
     *
     * @param string $content
     * @param int $post_id
     * @param string $position 'top' | 'bottom'
     * @param string $cdn_url
     * @return string
     */
    public function inject_featured_image($content, $post_id, $position = 'top', $cdn_url = '') {
        $settings = get_option('wp_blogger_settings', array());
        $img_src  = '';
        $img_alt  = get_the_title($post_id);

        if (has_post_thumbnail($post_id)) {
            // Use post's own featured image
            $thumb_id = get_post_thumbnail_id($post_id);
            $img_src  = wp_get_attachment_image_url($thumb_id, 'full');
            $thumb_alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
            if (!empty($thumb_alt)) {
                $img_alt = $thumb_alt;
            }
        } elseif (!empty($settings['default_featured_image_url'])) {
            // Fallback: use the global default featured image configured in plugin settings
            $img_src = esc_url_raw($settings['default_featured_image_url']);
        }

        if (empty($img_src)) {
            return $content;
        }

        // Apply CDN to featured image if configured
        if (!empty($cdn_url)) {
            $img_src = $this->apply_cdn_url($img_src, $cdn_url);
        }

        // If the image URL is already in the content, don't duplicate
        if (strpos($content, $img_src) !== false) {
            return $content;
        }

        // Blogger-friendly container markup with thumbnail hidden div for Blogger to detect
        $featured_html = sprintf(
            '<div class="separator wp-blogger-featured-img" style="clear: both; text-align: center; margin-bottom: 20px;">' .
            '<a href="%s" style="margin-left: 1em; margin-right: 1em;" target="_blank">' .
            '<img border="0" src="%s" alt="%s" style="max-width: 100%%; height: auto; border-radius: 8px;" />' .
            '</a>' .
            '</div>',
            esc_url($img_src),
            esc_url($img_src),
            esc_attr($img_alt)
        );

        if ($position === 'bottom') {
            return $content . "\n" . $featured_html;
        }

        return $featured_html . "\n" . $content;
    }

    /**
     * Strip Gutenberg block comments to ensure clean HTML on Blogger
     *
     * @param string $content
     * @return string
     */
    public function clean_gutenberg_comments($content) {
        // Strip <!-- wp:... --> comments
        $content = preg_replace('/<!--\s*\/?wp:[^\>]*-->/', '', $content);
        return trim($content);
    }

    /**
     * Extract all image URLs from a post content
     */
    public function get_content_images($content) {
        $images = array();
        preg_match_all('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $content, $matches);
        if (!empty($matches[1])) {
            $images = array_unique($matches[1]);
        }
        return $images;
    }
}
